# WebestenHeater_24

Bu sürüm _23 tabanından hazırlanmıştır.

## _24 değişiklikleri
- **Gerçek cihaz kontrolü açıldı.** _23 ve öncesinde BAŞLAT/DURDUR, hedef sıcaklık ve fan
  düğmeleri sadece uygulamanın iç durumunu değiştiriyordu; BLE üzerinden hiçbir komut
  gönderilmiyordu (protokol fonksiyonları vardı ama hiçbir yerden çağrılmıyordu).
- `HeatGenieBleManager`: `sendPower`, `sendTargetTemperature`, `sendTargetGear`, `isCommandChannelReady` eklendi.
- `HeaterViewModel`: güç / hedef sıcaklık / fan artık BLE komutu gönderir. Bağlantı yoksa
  güç durumu yerel olarak değiştirilmez.
- Arayüzdeki "komutlar kilitli" yazıları güncellendi.
- Güç çerçeveleri için birim testi eklendi.
- Soğutma sayacı ve diğer _23 özellikleri korunur.

## _28 değişiklikleri
- 1 dk sonra kapanma: elle BAŞLAT ile başlatılan ısıtıcı, canlı durum etiketi "OTOMATİK" olunca "otomasyon bitti" sanılıp
  durduruluyordu. Artık otomasyonun başlattığı çalışma açıkça takip edilir (autoOwner); elle başlatılana dokunulmaz.
- OTOMATİK/GÜNLÜK etiket titremesi ve ÜFLEME 3/10<->4/10 titremesi giderildi (iki yazar aynı değeri eziyordu).
  Program üfleme/hedef değeri ısıtıcıya değişiklik başına bir kez gönderilir.
- Program saatleri 5 dk adımla ayarlanır (eskiden 15).
- Soğutma sayacı sayfa değişince sıfırlanmaz (başlangıç zamanı ViewModel'de).
- Ana ekran ÇIKIŞ kutusu: bu ısıtıcıda çıkış sensörü yok -> GİRİŞ varsa o, yoksa "SENSÖR YOK".
- Bluetooth: MAC benzeri kod yerine "KLON Dizel Isıtıcı" adı gösterilir.

## _27 değişiklikleri
- Termostat: ölçülen sıcaklık BAŞLAT eşiğine eşit veya altındaysa ısıtıcı başlatılır (20 eşik, 18 ölçüm -> başlar).
  Durdurma kararı artık "activeController" etiketine bağlı değil; başlat komutu en fazla 8 sn'de bir tekrarlanır.
  Termostat kartı canlı gerekçeyi gösterir (ölçülen sıcaklık, eşik, bekleme/bağlantı durumu).
- Rakım: telefonun GPS rakımı (Android 14+ deniz seviyesi) ısıtıcının kendi sensörüne tercih edilir; ısıtıcı 800 m raporluyordu.
  Kaynak ana ekranda "Rakım • GPS" / "Rakım • ısıtıcı" olarak yazar.
- Çıkış sıcaklığı: ham 32760 (0x7FF8) "sensör desteklenmiyor" demektir; artık 3276°C yerine "--" gösterilir.
- Ana ekran sağ alt kutu FAN yerine KASA sıcaklığı gösterir.

## _26 değişiklikleri (HeatGenie 1.1.1 APK analizine göre)
- Komut kanalı seçimi orijinal uygulamayla aynı yapıldı: 181A servisindeki yazılabilir
  karakteristiklerin SONUNCUSU kullanılır (eskiden ilki seçiliyordu).
- Yazma türü orijinal gibi "yanıtsız yazma" (write without response).
- GATT işlemleri sıraya alındı (bildirim -> MTU -> durum isteği); meşgul yazmalar 3 kez tekrar denenir.
- Bluetooth ekranında son TX baytları, gönderim sonucu ve karakteristik listesi gösterilir.
- Güç çerçevesi (AA 00 61 01 <rastgele> 00 CRC) orijinalle birebir aynı olduğu doğrulandı.

## _29 değişiklikleri
- Ana ekrandaki ÇIKIŞ kutusu DIŞ SICAKLIK oldu (konumunuzdaki hava, Open-Meteo; dokununca hava sayfası açılır).
- Akü kritik seviyede (12 V: <11.0 V, 24 V: <22.0 V) kırmızı yanıp sönen yazı; düşük seviyede turuncu.
- Düşük voltajda "bip bip" sesli uyarı (Ayarlar'dan kapatılabilir, "SESİ DENE" düğmesi var).
- Yeni sayfalar (Ayarlar içinden): HAVA DURUMU (don, ani soğuma, fırtına, şiddetli yağış uyarıları; 6 saat ve 5 gün;
  bulut katmanları ve yağış ayrıntısı), GÜNEŞ PANELİ (yalnızca gün doğumu-batımı arası), HATA KODLARI VE ÇÖZÜMLER.
- ÖZEL MODLAR sayfasında FAN MODU (havalandırma): yakıt yakmadan yalnızca fan çalışır. Komut 0x61 / 0x09 olarak
  orijinal HeatGenie çözümlemesinden alındı; gerçek cihazda henüz denenmedi.
- Uyarılar yalnızca uygulama açıkken hesaplanır. INTERNET izni eklendi.

## _29.1 değişiklikleri
- Ana sayfada İÇ ORTAM SICAKLIĞI çerçevesinin arkasında, yalnızca gün doğumu-batımı arasında konumunuzun güneş,
  bulut, yağmur ve kar durumu animasyonla gösterilir; köşede "Güneş: Güçlü/Orta/Zayıf • bulut %" etiketi (akü şarjı için ipucu).

## _29.3 değişiklikleri
- Güneş etiketi HEDEF SICAKLIK başlığının üstüne alındı.
- Hava animasyonu yenilendi: gün doğumundan batımına yay çizen güneş (ufukta sıcak tonlar), hacimli yumuşak bulutlar
  (alçak/yüksek bulut oranına göre, derinlik katmanlı), ışık huzmeleri, yağmur/kar katmanları ve su halkaları.

## Güvenlik
İlk denemeyi cihazın başındayken yapın. Güç komutundaki `token` alanı HeatGenie 1.1.1
analizinden alınmıştır ve gerçek cihazda henüz doğrulanmamıştır.

Sürüm: `29.3` — versionCode: `293`
