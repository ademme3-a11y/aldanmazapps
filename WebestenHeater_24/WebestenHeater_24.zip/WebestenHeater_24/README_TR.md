# WebestenHeater_24

Bu sürüm _23 tabanından hazırlanmıştır.

## _24 değişiklikleri
- **Gerçek cihaz kontrolü açıldı.** _23 ve öncesinde BAŞLAT/DURDUR, hedef sıcaklık ve fan
  düğmeleri sadece uygulamanın iç durumunu değiştiriyordu; BLE üzerinden hiçbir komut
  gönderilmiyordu (protokol fonksiyonları vardı ama hiçbir yerden çağrılmıyordu).
- `HeatGenieBleManager`: `sendPower`, `sendTargetTemperature`, `sendTargetGear`, `isCommandChannelReady` eklendi.
- `HeaterViewModel`: güç / hedef sıcaklık / fan artık BLE komutu gönderir. Bağlantı yoksa
  güç durumu yerel olarak değiştirilmez.
- Arayüzdeki "komutlar kilitli" yazıları güncellendi.
- Güç çerçeveleri için birim testi eklendi.
- Soğutma sayacı ve diğer _23 özellikleri korunur.

## _27 değişiklikleri
- Termostat: ölçülen sıcaklık BAŞLAT eşiğine eşit veya altındaysa ısıtıcı başlatılır (20 eşik, 18 ölçüm -> başlar).
  Durdurma kararı artık "activeController" etiketine bağlı değil; başlat komutu en fazla 8 sn'de bir tekrarlanır.
  Termostat kartı canlı gerekçeyi gösterir (ölçülen sıcaklık, eşik, bekleme/bağlantı durumu).
- Rakım: telefonun GPS rakımı (Android 14+ deniz seviyesi) ısıtıcının kendi sensörüne tercih edilir; ısıtıcı 800 m raporluyordu.
  Kaynak ana ekranda "Rakım • GPS" / "Rakım • ısıtıcı" olarak yazar.
- Çıkış sıcaklığı: ham 32760 (0x7FF8) "sensör desteklenmiyor" demektir; artık 3276°C yerine "--" gösterilir.
- Ana ekran sağ alt kutu FAN yerine KASA sıcaklığı gösterir.

## _26 değişiklikleri (HeatGenie 1.1.1 APK analizine göre)
- Komut kanalı seçimi orijinal uygulamayla aynı yapıldı: 181A servisindeki yazılabilir
  karakteristiklerin SONUNCUSU kullanılır (eskiden ilki seçiliyordu).
- Yazma türü orijinal gibi "yanıtsız yazma" (write without response).
- GATT işlemleri sıraya alındı (bildirim -> MTU -> durum isteği); meşgul yazmalar 3 kez tekrar denenir.
- Bluetooth ekranında son TX baytları, gönderim sonucu ve karakteristik listesi gösterilir.
- Güç çerçevesi (AA 00 61 01 <rastgele> 00 CRC) orijinalle birebir aynı olduğu doğrulandı.

## Güvenlik
İlk denemeyi cihazın başındayken yapın. Güç komutundaki `token` alanı HeatGenie 1.1.1
analizinden alınmıştır ve gerçek cihazda henüz doğrulanmamıştır.

Sürüm: `27` — versionCode: `270`
