package com.aldanmaz.webestenheater

/**
 * HeatGenie / Webesten controller faults. The controller reports a bit mask (register "errorCode") and,
 * for some faults, a sub code ("errorPlus", e.g. E-03 -> 1 = short circuit, 2 = open circuit).
 * Fault names and meanings come from the original HeatGenie app; the remedies are practical service advice.
 */
data class FaultInfo(
    val code: String,
    val bit: Int,
    val plus: Int,
    val title: String,
    val meaning: String,
    val solutions: List<String>
)

object ErrorCatalog {

    val all: List<FaultInfo> = listOf(
        FaultInfo(
            "E-01", 1, 0, "Düşük voltaj",
            "Besleme gerilimi çok düşük: 12 V sistemde 10 V'un, 24 V sistemde 18 V'un altına indi.",
            listOf(
                "Aküyü şarj edin; akü ömrünü doldurmuşsa değiştirin.",
                "Akü kutup başlarını ve ısıtıcı kablo bağlantılarını kontrol edin, oksitlenme varsa temizleyin.",
                "Kablo kesitinin yeterli olduğunu ve sigorta yuvasının ısınıp gevşemediğini kontrol edin.",
                "Isıtıcıyı marş sonrası veya şarj varken çalıştırın; ateşleme anında gerilim çok düşmemeli."
            )
        ),
        FaultInfo(
            "E-02", 2, 0, "Yüksek voltaj",
            "Besleme gerilimi çok yüksek: 12 V sistemde 17 V'un, 24 V sistemde 32 V'un üzerine çıktı.",
            listOf(
                "Aracın şarj sistemini (alternatör/regülatör) ölçtürün.",
                "12 V ısıtıcıya yanlışlıkla 24 V verilmediğinden emin olun.",
                "Güneş paneli şarj regülatörü kullanıyorsanız çıkış ayarını kontrol edin."
            )
        ),
        FaultInfo(
            "E-03-1", 4, 1, "Ateşleme bujisi: kısa devre",
            "Bujinin kablosu veya soketi toprağa kısa devre yapıyor.",
            listOf(
                "Isıtıcıyı durdurup soğumasını bekleyin, aküyü ayırın.",
                "Buji soket ve kablosunda ezilme, yanık veya yağ izi var mı bakın.",
                "Buji direncini ölçün (genellikle birkaç ohm); kısa devre görüyorsanız bujiyi değiştirin."
            )
        ),
        FaultInfo(
            "E-03-2", 4, 2, "Ateşleme bujisi: açık devre",
            "Buji bağlantısı kopuk veya buji yanmış.",
            listOf(
                "Buji soketinin tam oturduğunu kontrol edin.",
                "Kablo kopukluğu için süreklilik ölçün; buji açık devreyse değiştirin.",
                "Buji yuvasındaki karbon ve is birikimini temizleyin."
            )
        ),
        FaultInfo(
            "E-04-1", 8, 1, "Yağ (yakıt) pompası: kısa devre",
            "Pompa bobini veya kablosu kısa devre yapıyor.",
            listOf(
                "Aküyü ayırıp pompa soketini ve kablosunu kontrol edin.",
                "Pompa bobin direncini ölçün; çok düşükse pompayı değiştirin."
            )
        ),
        FaultInfo(
            "E-04-2", 8, 2, "Yağ (yakıt) pompası: açık devre",
            "Pompa bağlantısı kopuk veya bobin yanmış.",
            listOf(
                "Pompa soketinin takılı ve temiz olduğunu kontrol edin.",
                "Kablo sürekliliğini ölçün; bobin açık devreyse pompayı değiştirin."
            )
        ),
        FaultInfo(
            "E-05", 16, 0, "Aşırı ısınma (mahfaza 260°C üzeri)",
            "Gövde sıcaklığı 260°C'yi aştı. Genellikle hava giriş veya çıkışı tıkalıdır.",
            listOf(
                "Isıtıcıyı durdurun, tamamen soğumasını bekleyin.",
                "Sıcak hava çıkışı ve yanma havası girişi önünde kumaş, eşya veya kar olmadığını kontrol edin.",
                "Hava hortumlarında ezilme, tıkanma veya çökme olup olmadığına bakın.",
                "Isıtıcı içindeki toz ve kurum birikimini temizletin."
            )
        ),
        FaultInfo(
            "E-06-1", 32, 1, "Fan motoru: kısa devre",
            "Fan motoru veya kablosu kısa devre yapıyor.",
            listOf(
                "Aküyü ayırın, fan soketini ve kablosunu kontrol edin.",
                "Motor yanık kokuyorsa veya ısınıyorsa fan grubunu değiştirin."
            )
        ),
        FaultInfo(
            "E-06-2", 32, 2, "Fan motoru: açık devre",
            "Fan motoru bağlantısı kopuk.",
            listOf(
                "Fan soketinin tam oturduğunu kontrol edin.",
                "Kablo sürekliliğini ölçün; motor sargısı açıksa fan grubunu değiştirin."
            )
        ),
        FaultInfo(
            "E-06-3", 32, 3, "Fan hız sensörü (Hall) okuma yok",
            "Fan dönerken hız sinyali alınamıyor. Fan sıkışmış veya Hall sensörü arızalı olabilir.",
            listOf(
                "Fanın elle serbest dönüp dönmediğini kontrol edin; sıkışma veya yabancı cisim var mı bakın.",
                "Hall sensör kablosu ve soketini kontrol edin.",
                "Sorun sürerse fan grubunu değiştirin."
            )
        ),
        FaultInfo(
            "E-07", 64, 0, "İletişim hatası (anahtar–kontrolör)",
            "Anahtar/kumanda ile kontrolör arasındaki iletişim hattında açık devre veya gevşek bağlantı var.",
            listOf(
                "Kumanda/anahtar kablosunu ve fişlerini kontrol edin; sıkıca takılı olsun.",
                "Kablo ezilme veya kopukluk için gözden geçirin, gerekirse değiştirin."
            )
        ),
        FaultInfo(
            "E-08", 128, 0, "Alev sönmesi",
            "Çalışma sırasında alev söndü. Yakıt hattında hava, mum/parafin tıkanması veya yakıt kesilmesi olabilir.",
            listOf(
                "Depoda yeterli ve temiz yakıt olduğunu kontrol edin.",
                "Yakıt hattında hava kabarcığı, kırık veya gevşek bağlantı var mı bakın.",
                "Yakıt filtresi ve emiş borusu tıkalıysa temizleyin veya değiştirin.",
                "Soğukta kış motorinine geçin; yaz yakıtı donarak (mumlaşarak) hattı tıkayabilir.",
                "Fan modu (havalandırma) bu hatada kullanılabilir."
            )
        ),
        FaultInfo(
            "E-09-1", 256, 1, "Gövde sıcaklık sensörü: kısa devre",
            "Mahfaza sıcaklık sensörü kısa devre.",
            listOf(
                "Sensör soketini ve kablosunu kontrol edin.",
                "Sensör değerini ölçtürün; arızalıysa sensörü değiştirin."
            )
        ),
        FaultInfo(
            "E-09-2", 256, 2, "Gövde sıcaklık sensörü: açık devre",
            "Mahfaza sıcaklık sensörü bağlantısı kopuk.",
            listOf(
                "Sensör soketinin takılı olduğunu kontrol edin.",
                "Kablo kopukluğunu ölçün; sensör açık devreyse değiştirin."
            )
        ),
        FaultInfo(
            "E-10", 512, 0, "Ateşleme hatası",
            "Ateşleme iki kez başarısız oldu. Yakıt gelmiyor, yakıt pompası sıkışmış veya yakıt kalitesiz olabilir. Yanma odası da kurumla tıkanmış olabilir.",
            listOf(
                "Depoda yeterli ve kaliteli yakıt olduğunu kontrol edin; hattaki havayı pompayla atın (yakıt pompası/manuel pompalama).",
                "Yakıt emiş borusunun ve filtrenin tıkalı olmadığına bakın.",
                "Pompanın tık sesi yaptığını doğrulayın; sıkışmışsa değiştirin.",
                "Yanma odasındaki kurum ve karbon birikimini, ısıtıcı soğukken temizleyin.",
                "Buji (ateşleme bujisi) çalışıyor mu kontrol edin.",
                "Fan modu (havalandırma) bu hatada kullanılabilir."
            )
        ),
        FaultInfo(
            "E-11", 1024, 0, "Ortam sıcaklık sensörü hatası",
            "Ortam sıcaklık sensörü kısa veya açık devre.",
            listOf(
                "Sensör kablosunu ve soketini kontrol edin.",
                "Sorun sürerse sensörü veya kumandayı değiştirin."
            )
        ),
        FaultInfo(
            "E-12", 2048, 0, "Aşırı sıcaklık hatası",
            "Isıtıcı çalışma sırasında aşırı ısındı ve güvenlik için kapandı.",
            listOf(
                "Isıtıcıyı durdurup tamamen soğumasını bekleyin.",
                "Hava giriş ve çıkışlarının açık olduğunu, hortumların ezilmediğini kontrol edin.",
                "Fanın normal dönüp dönmediğine bakın.",
                "Isıtıcı içini kurumdan temizletin."
            )
        ),
        FaultInfo(
            "E-13", 4096, 0, "Hava girişi yüksek sıcaklık koruması",
            "Giriş havası aşırı sıcak. Kısa süre sonra kendiliğinden düzelir.",
            listOf(
                "Isıtıcının yanma havası girişini ısı kaynaklarından uzak tutun.",
                "Giriş ağzının tıkalı olmadığını kontrol edin; birkaç dakika bekleyin."
            )
        ),
        FaultInfo(
            "E-14", 8192, 0, "Hava çıkışı yüksek sıcaklık koruması",
            "Çıkış havası aşırı sıcak. Kısa süre sonra kendiliğinden düzelir.",
            listOf(
                "Sıcak hava çıkışının önünün açık olduğunu kontrol edin.",
                "Çıkış hortumunda ezilme veya tıkanma olmadığına bakın; birkaç dakika bekleyin."
            )
        ),
        FaultInfo(
            "E-15", 16384, 0, "Hava girişi sıcaklık sensörü hatası",
            "Giriş sıcaklık sensörü okunamıyor.",
            listOf(
                "Sensör kablosunu ve soketini kontrol edin.",
                "Bu ısıtıcı modelinde giriş sensörü yoksa ana ekranda “--” görünmesi hata değildir."
            )
        ),
        FaultInfo(
            "E-16", 32768, 0, "Hava çıkışı sıcaklık sensörü hatası",
            "Çıkış sıcaklık sensörü okunamıyor.",
            listOf(
                "Sensör kablosunu ve soketini kontrol edin.",
                "Bu ısıtıcı modelinde çıkış sensörü yoksa değer “desteklenmiyor” olarak bildirilir; bu bir hata değildir."
            )
        )
    )

    val generalTips: List<String> = listOf(
        "Hata görürseniz ısıtıcıyı durdurun, soğumasını bekleyin; bakım yapmadan önce aküyü ayırın.",
        "Hatayı giderdikten sonra ısıtıcıyı bir kez kapatıp açın; hata kodu yeniden gelirse sorun sürüyordur.",
        "Kaliteli ve temiz yakıt kullanın; soğukta kış motorini tercih edin.",
        "Yaz boyunca kullanmasanız bile ayda bir kez yüksek kademede 15 dakika çalıştırmak kurumu temizler.",
        "Yakıt hattı bağlantılarını ve filtreyi düzenli kontrol edin; hat içinde hava kalmamalı."
    )

    /** Faults that match the reported mask and sub code. A sub code the catalog does not know lists all variants. */
    fun active(mask: Int, plus: Int): List<FaultInfo> {
        if (mask == 0) return emptyList()
        val result = mutableListOf<FaultInfo>()
        for (bit in 0..15) {
            val value = 1 shl bit
            if (mask and value == 0) continue
            val candidates = all.filter { it.bit == value }
            val exact = candidates.filter { it.plus != 0 && it.plus == plus }
            val generic = candidates.filter { it.plus == 0 }
            result += when {
                exact.isNotEmpty() -> exact
                generic.isNotEmpty() -> generic
                else -> candidates
            }
        }
        return result
    }
}
