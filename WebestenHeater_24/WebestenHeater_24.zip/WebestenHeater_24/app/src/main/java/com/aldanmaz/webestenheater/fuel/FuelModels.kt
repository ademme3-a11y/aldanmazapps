package com.aldanmaz.webestenheater.fuel

import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

data class DayFuel(val date: String, val runSeconds: Long, val liters: Float)

data class FuelState(
    val tankL: Float = 6f,
    /** Fuel burned since the tank was last filled. */
    val usedL: Float = 0f,
    val manualPriceTl: Float = 0f,
    val autoPriceEnabled: Boolean = true,
    val autoPriceTl: Float? = null,
    val priceStatus: String = "Fiyat henüz alınmadı",
    /** Millilitres delivered by one pump stroke; 0.022 is typical for 2 kW class pumps. */
    val mlPerStroke: Float = 0.022f,
    /** Rated heater power in kW (used for the power estimate and calibration). */
    val ratedKw: Float = 8f,
    val todayDate: String = "",
    val todayRunSeconds: Long = 0,
    val todayL: Float = 0f,
    val totalRunSeconds: Long = 0,
    val totalL: Float = 0f,
    val history: List<DayFuel> = emptyList()
) {
    val remainingL: Float get() = (tankL - usedL).coerceIn(0f, tankL.coerceAtLeast(0f))
    val priceTl: Float get() = if (autoPriceEnabled && autoPriceTl != null) autoPriceTl else manualPriceTl
    val priceKnown: Boolean get() = priceTl > 0f
    fun cost(liters: Float): Float = liters * priceTl
    /** Fuel flow in L/h at the given pump frequency. */
    fun litersPerHour(pumpHz: Float): Float = pumpHz * mlPerStroke * 3.6f
    /** Estimated heat output in kW (diesel 9.94 kWh/L, ~87 % efficiency). */
    fun heatKw(pumpHz: Float): Float = litersPerHour(pumpHz) * 9.94f * 0.87f
    val avgLitersPerHour: Float get() = if (totalRunSeconds > 600) totalL / (totalRunSeconds / 3600f) else 0f
}

fun formatRun(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    return if (h > 0) "%d sa %02d dk".format(h, m) else "%d dk".format(m)
}

fun formatTl(v: Float, known: Boolean): String = if (known) "%.0f TL".format(v) else "-- TL"

/** Diesel price lookup (Opet public price endpoint, per province) with a tolerant parser. */
object FuelPrice {
    private data class City(val plate: Int, val lat: Double, val lon: Double)

    // Nearest-city lookup is enough: diesel prices differ only slightly between provinces.
    private val cities = listOf(
        City(34, 41.01, 28.98), City(6, 39.93, 32.86), City(35, 38.42, 27.14), City(16, 40.19, 29.06),
        City(7, 36.90, 30.69), City(1, 37.00, 35.32), City(27, 37.07, 37.38), City(42, 37.87, 32.48),
        City(61, 41.00, 39.72), City(25, 39.90, 41.27), City(21, 37.91, 40.24), City(44, 38.35, 38.31),
        City(65, 38.50, 43.38), City(55, 41.29, 36.33), City(38, 38.72, 35.49), City(26, 39.77, 30.52),
        City(48, 37.21, 28.36), City(9, 37.85, 27.85), City(33, 36.80, 34.64), City(31, 36.20, 36.16),
        City(63, 37.16, 38.79), City(20, 37.78, 29.09), City(10, 39.65, 27.89), City(59, 40.98, 27.51),
        City(22, 41.68, 26.56), City(41, 40.77, 29.94), City(54, 40.77, 30.40), City(14, 40.73, 31.61),
        City(67, 41.45, 31.79), City(57, 42.03, 35.15), City(60, 40.31, 36.55), City(58, 39.75, 37.02),
        City(23, 38.68, 39.22), City(46, 37.58, 36.94), City(79, 36.72, 37.12), City(30, 37.57, 43.74),
        City(47, 37.31, 40.74), City(72, 37.88, 41.13), City(2, 37.76, 38.28), City(64, 38.68, 29.41),
        City(3, 38.75, 30.54), City(32, 37.76, 30.55), City(15, 37.72, 30.29), City(45, 38.62, 27.43),
        City(17, 40.15, 26.41), City(11, 40.15, 29.98), City(70, 37.18, 33.22), City(51, 37.97, 34.68),
        City(50, 38.62, 34.71), City(40, 39.15, 34.16), City(71, 39.85, 33.50), City(18, 40.60, 33.62),
        City(37, 41.37, 33.78), City(8, 41.18, 41.82), City(53, 41.02, 40.52), City(28, 40.91, 38.39),
        City(52, 40.98, 37.88), City(29, 40.46, 39.48), City(69, 40.26, 40.23), City(24, 39.75, 39.49),
        City(12, 38.88, 40.50), City(13, 38.40, 42.12), City(49, 38.74, 41.49), City(56, 37.93, 41.94),
        City(62, 39.11, 39.55), City(78, 41.20, 32.62), City(74, 41.63, 32.34), City(81, 40.84, 31.16),
        City(68, 38.37, 34.03), City(66, 39.82, 34.80), City(19, 40.55, 34.96), City(5, 40.65, 35.83),
        City(36, 40.60, 43.10), City(75, 41.11, 42.70), City(76, 39.92, 44.05), City(4, 39.72, 43.05),
        City(77, 40.65, 29.27), City(80, 37.07, 36.25), City(73, 37.42, 42.46), City(43, 39.42, 29.98),
        City(39, 41.74, 27.22), City(45, 38.62, 27.43), City(33, 36.80, 34.64), City(72, 37.88, 41.13)
    )

    fun insideTurkey(lat: Double, lon: Double) = lat in 35.7..42.3 && lon in 25.6..44.9

    fun nearestPlate(lat: Double, lon: Double): Int =
        cities.minByOrNull { (it.lat - lat) * (it.lat - lat) + ((it.lon - lon) * 0.78) * ((it.lon - lon) * 0.78) }?.plate ?: 34

    /** Blocking. Returns the diesel price in TL per litre, or throws with a readable reason. */
    fun fetchDiesel(lat: Double, lon: Double): Float {
        val plate = nearestPlate(lat, lon)
        val c = URL("https://api.opet.com.tr/api/fuelprices/prices?ProvinceCode=$plate").openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            c.setRequestProperty("Accept", "application/json, text/plain, */*")
            c.setRequestProperty("Accept-Language", "tr-TR,tr;q=0.9")
            if (c.responseCode != 200) error("HTTP ${c.responseCode}")
            val text = c.inputStream.bufferedReader().use { it.readText() }
            return parseDiesel(text) ?: error("yanıtta motorin fiyatı bulunamadı")
        } finally {
            c.disconnect()
        }
    }

    internal fun parseDiesel(text: String): Float? {
        val root = try { JSONTokener(text).nextValue() } catch (_: Exception) { return null }
        val found = mutableListOf<Pair<String, Float>>()
        fun num(v: Any?): Float? = when (v) {
            is Number -> v.toFloat()
            is String -> v.trim().replace(',', '.').toFloatOrNull()
            else -> null
        }
        fun walk(node: Any?) {
            when (node) {
                is JSONArray -> for (i in 0 until node.length()) walk(node.opt(i))
                is JSONObject -> {
                    val tr = Locale("tr")
                    var name: String? = null
                    var price: Float? = null
                    val keys = node.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        val v = node.opt(k)
                        if (v is String) {
                            val l = v.lowercase(tr)
                            if (name == null && (l.contains("motorin") || l.contains("diesel"))) name = v
                        }
                        val kl = k.lowercase(tr)
                        if (price == null && (kl.contains("amount") || kl.contains("price") || kl.contains("fiyat") || kl.contains("value"))) {
                            val n = num(v)
                            if (n != null && n in 10f..400f) price = n
                        }
                    }
                    if (name != null && price != null) found += name to price
                    val it2 = node.keys()
                    while (it2.hasNext()) walk(node.opt(it2.next()))
                }
            }
        }
        walk(root)
        if (found.isEmpty()) return null
        val tr = Locale("tr")
        val special = listOf("eco", "ultra", "max", "premium", "excellium", "v-power", "pro", "force")
        val plain = found.filter { (n, _) -> special.none { n.lowercase(tr).contains(it) } }
        return (plain.ifEmpty { found }).minByOrNull { it.second }?.second
    }
}
