package com.aldanmaz.webestenheater

/**
 * Battery state of the heater supply as reported by the controller.
 * 0 = normal (or unknown), 1 = low, 2 = critical.
 * 12 V systems: critical below 11.0 V (the controller itself trips E-01 at 10 V), low below 11.8 V.
 * 24 V systems (reading above 16 V): critical below 22.0 V, low below 23.6 V.
 */
fun batteryLevel(volts: Float): Int {
    if (volts.isNaN() || volts < 1f) return 0
    return if (volts < 16f) {
        when {
            volts < 11.0f -> 2
            volts < 11.8f -> 1
            else -> 0
        }
    } else {
        when {
            volts < 22.0f -> 2
            volts < 23.6f -> 1
            else -> 0
        }
    }
}
