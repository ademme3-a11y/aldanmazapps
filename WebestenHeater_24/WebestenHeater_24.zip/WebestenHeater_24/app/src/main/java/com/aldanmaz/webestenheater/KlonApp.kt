package com.aldanmaz.webestenheater

import android.app.Application
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner

/**
 * The heater logic (thermostat, programs, Bluetooth link, fuel counter) lives in HeaterViewModel. It is kept in an
 * application-wide store so it survives the screen being closed or the app being swiped away while the
 * foreground service keeps the process alive.
 */
class KlonApp : Application(), ViewModelStoreOwner {
    override val viewModelStore: ViewModelStore = ViewModelStore()
}

fun appHeaterViewModel(app: Application): HeaterViewModel =
    ViewModelProvider(app as ViewModelStoreOwner, ViewModelProvider.AndroidViewModelFactory.getInstance(app))[HeaterViewModel::class.java]

@Composable
fun rememberAppViewModel(): HeaterViewModel {
    val app = LocalContext.current.applicationContext as Application
    return remember { appHeaterViewModel(app) }
}
