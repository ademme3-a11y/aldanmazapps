package com.aldanmaz.webestenheater.weather

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.roundToInt

data class CurrentWeather(
    val time: LocalDateTime,
    val tempC: Float,
    val feelsC: Float,
    val humidity: Int,
    val precipMm: Float,
    val cloud: Int,
    val windKmh: Float,
    val gustKmh: Float,
    val code: Int,
    val isDay: Boolean
)

data class HourlyWeather(
    val time: LocalDateTime,
    val tempC: Float,
    val precipProb: Int,
    val precipMm: Float,
    val snowCm: Float,
    val cloud: Int,
    val cloudLow: Int,
    val cloudMid: Int,
    val cloudHigh: Int,
    val windKmh: Float,
    val gustKmh: Float,
    val code: Int,
    val radiationWm2: Float,
    val isDay: Boolean
)

data class DailyWeather(
    val date: LocalDate,
    val code: Int,
    val tMaxC: Float,
    val tMinC: Float,
    val precipMm: Float,
    val precipProbMax: Int,
    val gustMaxKmh: Float,
    val sunrise: LocalDateTime,
    val sunset: LocalDateTime,
    val sunshineSec: Float,
    val daylightSec: Float
)

data class WeatherData(
    val current: CurrentWeather,
    val hourly: List<HourlyWeather>,
    val daily: List<DailyWeather>,
    val latitude: Double,
    val longitude: Double
)

enum class AlertLevel { CAUTION, WARNING }

data class WeatherAlert(
    val kind: String,
    val level: AlertLevel,
    val title: String,
    val detail: String
)

data class WeatherUiState(
    val loading: Boolean = false,
    val error: String? = null,
    val data: WeatherData? = null,
    val alerts: List<WeatherAlert> = emptyList(),
    val locationKnown: Boolean = false,
    val updatedAtLabel: String = ""
)

/** One daylight day for solar panels: only the hours between sunrise and sunset are counted. */
data class SolarDay(
    val date: LocalDate,
    val sunrise: LocalDateTime,
    val sunset: LocalDateTime,
    val daylightHours: Float,
    val meanCloud: Int,
    val precipMm: Float,
    val snowCm: Float,
    val radiationKwhM2: Float,
    val sunshineHours: Float,
    val score: Int,
    val rating: String
)

object WeatherRepository {
    private const val BASE = "https://api.open-meteo.com/v1/forecast"
    private val TR = Locale("tr", "TR")

    private const val CURRENT_FIELDS =
        "temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,cloud_cover," +
            "wind_speed_10m,wind_gusts_10m,weather_code,is_day"
    private const val HOURLY_FIELDS =
        "temperature_2m,precipitation_probability,precipitation,snowfall,cloud_cover,cloud_cover_low," +
            "cloud_cover_mid,cloud_cover_high,wind_speed_10m,wind_gusts_10m,weather_code," +
            "shortwave_radiation,is_day"
    private const val DAILY_FIELDS =
        "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max," +
            "wind_gusts_10m_max,sunrise,sunset,sunshine_duration,daylight_duration"

    private fun JSONArray?.d(i: Int): Double = this?.optDouble(i, 0.0) ?: 0.0
    private fun JSONArray?.n(i: Int): Int = this?.optInt(i, 0) ?: 0

    /** Blocking network call: run it off the main thread. */
    fun fetch(lat: Double, lon: Double): WeatherData {
        val query = "latitude=%.4f&longitude=%.4f".format(Locale.US, lat, lon) +
            "&current=$CURRENT_FIELDS&hourly=$HOURLY_FIELDS&daily=$DAILY_FIELDS" +
            "&timezone=auto&forecast_days=6&wind_speed_unit=kmh"
        val connection = URL("$BASE?$query").openConnection() as HttpURLConnection
        val text = try {
            connection.connectTimeout = 10_000
            connection.readTimeout = 15_000
            connection.setRequestProperty("User-Agent", "KlonDizelIsitici/1.0")
            if (connection.responseCode != 200) error("Sunucu yanıtı: HTTP ${connection.responseCode}")
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
        return parse(text, lat, lon)
    }

    fun parse(text: String, lat: Double, lon: Double): WeatherData {
        val root = JSONObject(text)

        val c = root.getJSONObject("current")
        val current = CurrentWeather(
            time = LocalDateTime.parse(c.getString("time")),
            tempC = c.optDouble("temperature_2m", 0.0).toFloat(),
            feelsC = c.optDouble("apparent_temperature", 0.0).toFloat(),
            humidity = c.optInt("relative_humidity_2m", 0),
            precipMm = c.optDouble("precipitation", 0.0).toFloat(),
            cloud = c.optInt("cloud_cover", 0),
            windKmh = c.optDouble("wind_speed_10m", 0.0).toFloat(),
            gustKmh = c.optDouble("wind_gusts_10m", 0.0).toFloat(),
            code = c.optInt("weather_code", 0),
            isDay = c.optInt("is_day", 1) == 1
        )

        val h = root.getJSONObject("hourly")
        val ht = h.getJSONArray("time")
        val hourly = (0 until ht.length()).map { i ->
            HourlyWeather(
                time = LocalDateTime.parse(ht.getString(i)),
                tempC = h.optJSONArray("temperature_2m").d(i).toFloat(),
                precipProb = h.optJSONArray("precipitation_probability").n(i),
                precipMm = h.optJSONArray("precipitation").d(i).toFloat(),
                snowCm = h.optJSONArray("snowfall").d(i).toFloat(),
                cloud = h.optJSONArray("cloud_cover").n(i),
                cloudLow = h.optJSONArray("cloud_cover_low").n(i),
                cloudMid = h.optJSONArray("cloud_cover_mid").n(i),
                cloudHigh = h.optJSONArray("cloud_cover_high").n(i),
                windKmh = h.optJSONArray("wind_speed_10m").d(i).toFloat(),
                gustKmh = h.optJSONArray("wind_gusts_10m").d(i).toFloat(),
                code = h.optJSONArray("weather_code").n(i),
                radiationWm2 = h.optJSONArray("shortwave_radiation").d(i).toFloat(),
                isDay = h.optJSONArray("is_day").n(i) == 1
            )
        }

        val d = root.getJSONObject("daily")
        val dt = d.getJSONArray("time")
        val daily = (0 until dt.length()).map { i ->
            DailyWeather(
                date = LocalDate.parse(dt.getString(i)),
                code = d.optJSONArray("weather_code").n(i),
                tMaxC = d.optJSONArray("temperature_2m_max").d(i).toFloat(),
                tMinC = d.optJSONArray("temperature_2m_min").d(i).toFloat(),
                precipMm = d.optJSONArray("precipitation_sum").d(i).toFloat(),
                precipProbMax = d.optJSONArray("precipitation_probability_max").n(i),
                gustMaxKmh = d.optJSONArray("wind_gusts_10m_max").d(i).toFloat(),
                sunrise = LocalDateTime.parse(d.getJSONArray("sunrise").getString(i)),
                sunset = LocalDateTime.parse(d.getJSONArray("sunset").getString(i)),
                sunshineSec = d.optJSONArray("sunshine_duration").d(i).toFloat(),
                daylightSec = d.optJSONArray("daylight_duration").d(i).toFloat()
            )
        }
        return WeatherData(current, hourly, daily, lat, lon)
    }

    // ------------------------------------------------------------------ helpers

    /** The next [count] hourly rows, starting with the current hour. */
    fun upcomingHours(data: WeatherData, count: Int): List<HourlyWeather> {
        val nowHour = data.current.time.truncatedTo(ChronoUnit.HOURS)
        return data.hourly.filter { !it.time.isBefore(nowHour) }.take(count)
    }

    /** Days after today (tomorrow ... +5). */
    fun nextDays(data: WeatherData, count: Int = 5): List<DailyWeather> {
        val today = data.current.time.toLocalDate()
        return data.daily.filter { it.date.isAfter(today) }.take(count)
    }

    fun dayName(date: LocalDate): String =
        date.dayOfWeek.getDisplayName(TextStyle.FULL, TR).replaceFirstChar { it.titlecase(TR) }

    fun describe(code: Int): String = when (code) {
        0 -> "Açık"
        1 -> "Çoğunlukla açık"
        2 -> "Parçalı bulutlu"
        3 -> "Kapalı"
        45, 48 -> "Sisli"
        51, 53, 55 -> "Çisenti"
        56, 57 -> "Donan çisenti"
        61 -> "Hafif yağmur"
        63 -> "Yağmur"
        65 -> "Şiddetli yağmur"
        66, 67 -> "Donan yağmur"
        71 -> "Hafif kar"
        73 -> "Kar"
        75 -> "Yoğun kar"
        77 -> "Kar taneleri"
        80 -> "Hafif sağanak"
        81 -> "Sağanak"
        82 -> "Şiddetli sağanak"
        85, 86 -> "Kar sağanağı"
        95 -> "Gök gürültülü fırtına"
        96, 99 -> "Dolulu fırtına"
        else -> "—"
    }

    fun icon(code: Int, isDay: Boolean = true): String = when (code) {
        0 -> if (isDay) "☀️" else "🌙"
        1 -> if (isDay) "🌤️" else "🌙"
        2 -> "⛅"
        3 -> "☁️"
        45, 48 -> "🌫️"
        51, 53, 55, 56, 57 -> "🌦️"
        61, 63, 65, 66, 67, 80, 81, 82 -> "🌧️"
        71, 73, 75, 77, 85, 86 -> "❄️"
        95, 96, 99 -> "⛈️"
        else -> "•"
    }

    // ------------------------------------------------------------------ alerts

    /** Sudden cooling, frost, storm and heavy precipitation, looked up over the next 24 hours. */
    fun computeAlerts(data: WeatherData): List<WeatherAlert> {
        val alerts = mutableListOf<WeatherAlert>()
        val next24 = upcomingHours(data, 24)
        if (next24.isEmpty()) return alerts
        val now = data.current.tempC
        fun at(h: HourlyWeather) = "%02d:%02d".format(h.time.hour, h.time.minute)
        fun dayTag(h: HourlyWeather) =
            if (h.time.toLocalDate() == data.current.time.toLocalDate()) "bugün" else "yarın"

        // Frost
        val coldest = next24.minByOrNull { it.tempC }!!
        if (coldest.tempC <= 0f) {
            alerts += WeatherAlert(
                "frost", AlertLevel.WARNING, "DON UYARISI",
                "Sıcaklık ${dayTag(coldest)} ${at(coldest)} civarında %.1f°C'ye düşecek. Yakıt hattını, aküyü ve açıktaki boruları koruyun.".format(coldest.tempC)
            )
        } else if (coldest.tempC <= 2f) {
            alerts += WeatherAlert(
                "frost", AlertLevel.CAUTION, "DON RİSKİ",
                "Sıcaklık ${dayTag(coldest)} ${at(coldest)} civarında %.1f°C'ye inebilir; yer yer don olabilir.".format(coldest.tempC)
            )
        }

        // Sudden cooling: biggest drop against the current temperature within 12 hours
        val next12 = next24.take(12)
        val lowest12 = next12.minByOrNull { it.tempC }!!
        val drop = now - lowest12.tempC
        if (drop >= 8f) {
            alerts += WeatherAlert(
                "cooling", AlertLevel.WARNING, "ANİ HAVA SOĞUMASI",
                "12 saat içinde %.0f°C düşüş bekleniyor (%.1f°C → %.1f°C, ${dayTag(lowest12)} ${at(lowest12)}).".format(drop, now, lowest12.tempC)
            )
        } else if (drop >= 5f) {
            alerts += WeatherAlert(
                "cooling", AlertLevel.CAUTION, "HAVA SOĞUYOR",
                "12 saat içinde %.0f°C düşüş bekleniyor (%.1f°C → %.1f°C).".format(drop, now, lowest12.tempC)
            )
        } else {
            val tomorrow = nextDays(data, 1).firstOrNull()
            val today = data.daily.firstOrNull { it.date == data.current.time.toLocalDate() }
            if (tomorrow != null && today != null && today.tMaxC - tomorrow.tMaxC >= 8f) {
                alerts += WeatherAlert(
                    "cooling", AlertLevel.CAUTION, "YARIN BELİRGİN SOĞUMA",
                    "Yarınki en yüksek sıcaklık bugüne göre %.0f°C düşük (%.0f°C → %.0f°C).".format(today.tMaxC - tomorrow.tMaxC, today.tMaxC, tomorrow.tMaxC)
                )
            }
        }

        // Storm: thunderstorm codes or strong gusts
        val thunder = next24.firstOrNull { it.code == 95 || it.code == 96 || it.code == 99 }
        val gustiest = next24.maxByOrNull { it.gustKmh }!!
        if (thunder != null) {
            alerts += WeatherAlert(
                "storm", AlertLevel.WARNING, "FIRTINA UYARISI",
                "${dayTag(thunder)} ${at(thunder)} civarında gök gürültülü fırtına bekleniyor; rüzgâr hamlesi en fazla %.0f km/sa.".format(gustiest.gustKmh)
            )
        } else if (gustiest.gustKmh >= 75f) {
            alerts += WeatherAlert(
                "storm", AlertLevel.WARNING, "FIRTINA UYARISI",
                "${dayTag(gustiest)} ${at(gustiest)} civarında rüzgâr hamlesi %.0f km/sa'e çıkacak.".format(gustiest.gustKmh)
            )
        } else if (gustiest.gustKmh >= 60f) {
            alerts += WeatherAlert(
                "storm", AlertLevel.CAUTION, "KUVVETLİ RÜZGÂR",
                "${dayTag(gustiest)} ${at(gustiest)} civarında rüzgâr hamlesi %.0f km/sa'e çıkabilir.".format(gustiest.gustKmh)
            )
        }

        // Heavy precipitation
        val wettest = next24.maxByOrNull { it.precipMm }!!
        val sum24 = next24.sumOf { it.precipMm.toDouble() }.toFloat()
        val snow24 = next24.sumOf { it.snowCm.toDouble() }.toFloat()
        if (wettest.precipMm >= 7.6f || sum24 >= 40f) {
            alerts += WeatherAlert(
                "rain", AlertLevel.WARNING, "ŞİDDETLİ YAĞIŞ UYARISI",
                "24 saatte toplam %.0f mm; en yoğun saat ${dayTag(wettest)} ${at(wettest)} (%.1f mm/sa).".format(sum24, wettest.precipMm)
            )
        } else if (wettest.precipMm >= 4f || sum24 >= 25f) {
            alerts += WeatherAlert(
                "rain", AlertLevel.CAUTION, "YOĞUN YAĞIŞ",
                "24 saatte toplam %.0f mm; en yoğun saat ${dayTag(wettest)} ${at(wettest)} (%.1f mm/sa).".format(sum24, wettest.precipMm)
            )
        }
        if (snow24 >= 10f) {
            alerts += WeatherAlert("rain", AlertLevel.WARNING, "YOĞUN KAR UYARISI", "24 saatte yaklaşık %.0f cm kar bekleniyor.".format(snow24))
        } else if (snow24 >= 4f) {
            alerts += WeatherAlert("rain", AlertLevel.CAUTION, "KAR YAĞIŞI", "24 saatte yaklaşık %.0f cm kar bekleniyor.".format(snow24))
        }

        return alerts.sortedByDescending { it.level.ordinal }
    }

    // ------------------------------------------------------------------ solar panels

    private fun rating(score: Int): String = when {
        score >= 70 -> "ÇOK İYİ"
        score >= 45 -> "İYİ"
        score >= 25 -> "ORTA"
        else -> "ZAYIF"
    }

    /** Daylight-only statistics for every forecast day (today ... +5). */
    fun solarDays(data: WeatherData): List<SolarDay> = data.daily.map { day ->
        val hours = data.hourly.filter { it.isDay && it.time.toLocalDate() == day.date }
        val daylightH = day.daylightSec / 3600f
        val sunshineH = day.sunshineSec / 3600f
        val ratio = if (day.daylightSec > 0f) day.sunshineSec / day.daylightSec else 0f
        val score = (ratio * 100f).roundToInt().coerceIn(0, 100)
        SolarDay(
            date = day.date,
            sunrise = day.sunrise,
            sunset = day.sunset,
            daylightHours = daylightH,
            meanCloud = if (hours.isEmpty()) 0 else hours.map { it.cloud }.average().roundToInt(),
            precipMm = hours.sumOf { it.precipMm.toDouble() }.toFloat(),
            snowCm = hours.sumOf { it.snowCm.toDouble() }.toFloat(),
            radiationKwhM2 = hours.sumOf { it.radiationWm2.toDouble() }.toFloat() / 1000f,
            sunshineHours = sunshineH,
            score = score,
            rating = rating(score)
        )
    }

    /** The next [count] daylight hours (may run into tomorrow when the sun has already set). */
    fun nextDaylightHours(data: WeatherData, count: Int = 6): List<HourlyWeather> {
        val nowHour = data.current.time.truncatedTo(ChronoUnit.HOURS)
        return data.hourly.filter { it.isDay && !it.time.isBefore(nowHour) }.take(count)
    }

    fun hourRating(radiationWm2: Float): String = when {
        radiationWm2 >= 600f -> "Güçlü"
        radiationWm2 >= 300f -> "Orta"
        radiationWm2 >= 100f -> "Zayıf"
        else -> "Çok zayıf"
    }

    /** Short Turkish remark for a solar day (snow on panels, rain washing, haze...). */
    fun solarNote(day: SolarDay): String = when {
        day.snowCm >= 0.5f -> "Gün içinde kar var: panel üzerinde birikebilir, üretim ciddi düşer."
        day.precipMm >= 8f -> "Yoğun yağış: üretim düşük olur, yağmur paneli temizler."
        day.precipMm >= 1f -> "Hafif yağış beklentisi: gün içinde dalgalı üretim."
        day.meanCloud >= 80 -> "Gün boyu kapalı: yalnızca dağınık ışık, düşük üretim."
        day.meanCloud >= 50 -> "Bulutlu: üretim güneşli güne göre belirgin düşük."
        day.score >= 70 -> "Büyük ölçüde açık: yüksek üretim beklenir."
        else -> "Parçalı bulutlu: orta düzey üretim."
    }
}
