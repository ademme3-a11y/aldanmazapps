package com.aldanmaz.webestenheater

import android.Manifest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.aldanmaz.webestenheater.ble.BleUiState
import com.aldanmaz.webestenheater.model.HeaterUiState
import com.aldanmaz.webestenheater.ui.theme.WebestenHeaterTheme
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemUi()
        setContent { WebestenHeaterTheme { HeaterApp() } }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onResume() {
        super.onResume()
        hideSystemUi()
    }

    private fun hideSystemUi() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        WindowCompat.getInsetsController(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }
}

private enum class HeaterScreen {
    HOME, THERMOSTAT, PROGRAMS, MODES, STATISTICS, SETTINGS, BLUETOOTH
}

@Composable
private fun HeaterApp(vm: HeaterViewModel = viewModel()) {
    val s by vm.uiState.collectAsState()
    val ble by vm.bleState.collectAsState()
    var screenName by rememberSaveable { mutableStateOf(HeaterScreen.HOME.name) }
    val screen = runCatching { HeaterScreen.valueOf(screenName) }.getOrDefault(HeaterScreen.HOME)

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        vm.refreshBleSystemState()
    }
    val locationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.any { it }) vm.startLocationUpdates()
    }
    LaunchedEffect(Unit) { vm.refreshBleSystemState() }

    val activity = LocalContext.current as? Activity
    LaunchedEffect(s.nightModeEnabled) {
        activity?.window?.let { window ->
            val lp = window.attributes
            lp.screenBrightness = if (s.nightModeEnabled) 0.18f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            window.attributes = lp
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            activity?.window?.let { window ->
                val lp = window.attributes
                lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                window.attributes = lp
            }
        }
    }

    fun navigate(target: HeaterScreen) { screenName = target.name }
    fun backTarget(): HeaterScreen = when (screen) {
        HeaterScreen.MODES, HeaterScreen.BLUETOOTH -> HeaterScreen.SETTINGS
        else -> HeaterScreen.HOME
    }
    BackHandler(enabled = screen != HeaterScreen.HOME) { navigate(backTarget()) }

    fun requestBluetoothPermission() {
        val permissions = if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        permissionLauncher.launch(permissions)
    }

    fun requestLocationPermission() {
        locationPermissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = { HeaterBottomBar(screen, s, vm, ::navigate) }
    ) { innerPadding ->
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            val wide = maxWidth >= 700.dp && maxWidth > maxHeight
            if (screen == HeaterScreen.HOME) {
                Klon16HomePage(
                    s = s,
                    ble = ble,
                    vm = vm,
                    modifier = Modifier.fillMaxSize(),
                    wide = wide,
                    onNavigate = ::navigate,
                    onRequestLocation = ::requestLocationPermission
                )
            } else {
                // _22: Ana sayfa aynen korunur. Alt sayfalarda _20'deki kompakt
                // kart/panel geometrisi korunur; _21'deki 2x font büyütmesi düşürülür.
                // Böylece ekranın kendisi büyümez, yazı/rakam/simgeler okunaklı kalır.
                val baseDensity = LocalDensity.current
                val pageScale: Float
                val fontBoost: Float
                when {
                    wide && maxHeight <= 560.dp -> { pageScale = 0.72f; fontBoost = 1.45f }
                    !wide && maxWidth < 700.dp -> { pageScale = 0.80f; fontBoost = 1.35f }
                    else -> { pageScale = 0.88f; fontBoost = 1.28f }
                }
                CompositionLocalProvider(
                    LocalDensity provides Density(
                        density = baseDensity.density * pageScale,
                        fontScale = baseDensity.fontScale * fontBoost
                    )
                ) {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = if (wide) 14.dp else 10.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        when (screen) {
                            HeaterScreen.HOME -> Unit
                            HeaterScreen.THERMOSTAT -> {
                                PageHeader("TERMOSTAT", "Isı aralığını otomatik korur") { navigate(HeaterScreen.HOME) }
                                ThermostatCard(s, vm)
                                PageHint("Örnek: 20°C'de başlat, 25°C'de durdur. Her iki eşik de değiştirilebilir.")
                            }
                            HeaterScreen.PROGRAMS -> {
                                PageHeader("PROGRAMLAR", "Günlük ve haftalık zamanlama") { navigate(HeaterScreen.HOME) }
                                DailyCard(s, vm)
                                WeeklyCard(s, vm)
                            }
                            HeaterScreen.MODES -> {
                                PageHeader("ÖZEL MODLAR", "Gece, don koruma ve Turbo hızlı ısıtma") { navigate(HeaterScreen.SETTINGS) }
                                NightCard(s, vm)
                                FrostCard(s, vm)
                                BoostCard(s, vm)
                                PriorityCard()
                            }
                            HeaterScreen.STATISTICS -> {
                                PageHeader("GEÇMİŞ", "Sıcaklık, çalışma ve tüketim özeti") { navigate(HeaterScreen.HOME) }
                                StatisticsCard(s, vm)
                                TemperatureHistoryCard(s)
                                EventHistoryCard(s, vm)
                            }
                            HeaterScreen.SETTINGS -> {
                                PageHeader("AYARLAR", "Cihaz, özel modlar ve gelişmiş seçenekler") { navigate(HeaterScreen.HOME) }
                                SettingsPage(s, ble, ::navigate)
                            }
                            HeaterScreen.BLUETOOTH -> {
                                PageHeader("BLUETOOTH", "Gerçek ısıtıcı bağlantısı ve canlı veri") { navigate(HeaterScreen.SETTINGS) }
                                BleControlCard(ble, vm, ::requestBluetoothPermission)
                            }
                        }
                        if (screen == HeaterScreen.SETTINGS || screen == HeaterScreen.BLUETOOTH) {
                            Text(
                                "Klon_24 • gerçek BLE komutları: BAŞLAT/DURDUR, hedef sıcaklık, fan • soğutmada güç kilitli • demo yok",
                                color = Color(0xFF5D666D),
                                fontSize = 10.sp,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun HeaterBottomBar(
    screen: HeaterScreen,
    s: HeaterUiState,
    vm: HeaterViewModel,
    onNavigate: (HeaterScreen) -> Unit
) {
    val selected = when (screen) {
        HeaterScreen.MODES, HeaterScreen.BLUETOOTH -> HeaterScreen.SETTINGS
        else -> screen
    }
    val config = LocalConfiguration.current
    val landscape = config.screenWidthDp > config.screenHeightDp
    val large = minOf(config.screenWidthDp, config.screenHeightDp) >= 600
    val barHeight = when {
        large -> 82.dp
        landscape -> 67.dp
        else -> 58.dp
    }

    Surface(
        modifier = Modifier.fillMaxWidth().height(barHeight),
        color = Color(0xFF020B13),
        tonalElevation = 0.dp,
        shadowElevation = 0.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF12334F))
    ) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = if (large) 8.dp else 2.dp, vertical = 1.dp),
            horizontalArrangement = Arrangement.spacedBy(if (large) 4.dp else 1.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Klon17BottomActionItem("home", "Anasayfa", selected == HeaterScreen.HOME, Modifier.weight(1f), large) {
                onNavigate(HeaterScreen.HOME)
            }
            Klon17BottomActionItem("thermo", "Termostat", selected == HeaterScreen.THERMOSTAT, Modifier.weight(1f), large) {
                onNavigate(HeaterScreen.THERMOSTAT)
            }
            Klon17BottomActionItem("clock", "Program", selected == HeaterScreen.PROGRAMS, Modifier.weight(1f), large) {
                onNavigate(HeaterScreen.PROGRAMS)
            }
            Klon17BottomActionItem("moon", "Gece", s.nightModeEnabled, Modifier.weight(.88f), large) {
                vm.toggleNightMode()
            }
            Klon17BottomActionItem("bolt", "Turbo", s.boostEnabled, Modifier.weight(.88f), large) {
                vm.toggleBoost()
            }
            Klon17BottomActionItem("snow", "Don Koruma", s.frostProtectionEnabled, Modifier.weight(1.08f), large) {
                vm.toggleFrostProtection()
            }
            Klon17BottomActionItem("bars", "Geçmiş", selected == HeaterScreen.STATISTICS, Modifier.weight(.92f), large) {
                onNavigate(HeaterScreen.STATISTICS)
            }
            Klon17BottomActionItem("gear", "Ayarlar", selected == HeaterScreen.SETTINGS, Modifier.weight(.92f), large) {
                onNavigate(HeaterScreen.SETTINGS)
            }
        }
    }
}

@Composable
private fun Klon17BottomActionItem(
    icon: String,
    label: String,
    active: Boolean,
    modifier: Modifier,
    large: Boolean,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(if (large) 13.dp else 9.dp)
    Box(
        modifier
            .fillMaxHeight()
            .clip(shape)
            .background(
                if (active) Brush.horizontalGradient(
                    listOf(Color(0xFF082A50), Color(0xFF084B91), Color(0xFF082E5C))
                ) else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent)),
                shape
            )
            .then(if (active) Modifier.border(1.dp, Color(0xFF0C8CFF), shape) else Modifier)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Klon16LineIcon(
                icon,
                Modifier.size(if (large) 24.dp else 18.dp),
                when (icon) {
                    "bolt" -> if (active) Color(0xFFFFD21F) else Color(0xFF90B9DF)
                    "snow" -> if (active) Color(0xFF5EBBFF) else Color(0xFF90B9DF)
                    else -> if (active) Color(0xFF35B8FF) else Color(0xFF90B9DF)
                },
                strokeWidth = if (large) 2.35f else 2.0f
            )
            Spacer(Modifier.height(1.dp))
            Text(
                label,
                color = if (active) Color(0xFFB9E7FF) else Color(0xFF9DBCDD),
                fontSize = if (large) 11.sp else 9.sp,
                lineHeight = if (large) 12.sp else 10.sp,
                fontWeight = if (active) FontWeight.Black else FontWeight.Medium,
                maxLines = 1
            )
        }
    }
}


@Composable
private fun Klon16HomePage(
    s: HeaterUiState,
    ble: BleUiState,
    vm: HeaterViewModel,
    modifier: Modifier = Modifier,
    wide: Boolean,
    onNavigate: (HeaterScreen) -> Unit,
    onRequestLocation: () -> Unit
) {
    val live = ble.liveStatus
    val ambient = live?.ambientC ?: s.ambientTemperatureC
    val battery = live?.batteryVoltage ?: s.batteryVoltage
    val pump = live?.pumpHz ?: s.pumpHz
    val outlet = live?.outletC ?: s.outletTemperatureC
    val rpm = live?.fanRpm ?: s.fanRpm
    val altitude = live?.altitudeM ?: s.altitudeMeters
    val machineOn = live?.machineState?.let { it in setOf(1, 2, 3, 9) } ?: s.isHeaterOn
    val cooling = live?.machineState == 4 || (!machineOn && s.statusText.equals("SOĞUTMA", true))

    BoxWithConstraints(modifier.background(Color(0xFF010A12))) {
        val rootWidth = maxWidth
        val rootHeight = maxHeight

        if (wide) {
            val phoneLandscape = rootHeight <= 560.dp
            val outer = if (phoneLandscape) 5.dp else (rootWidth * .010f).coerceIn(8.dp, 18.dp)
            val gap = if (phoneLandscape) 5.dp else (rootWidth * .006f).coerceIn(6.dp, 10.dp)
            val scenicWidth = if (phoneLandscape) {
                (rootWidth * .205f).coerceIn(145.dp, 205.dp)
            } else {
                (rootWidth * .225f).coerceIn(220.dp, 360.dp)
            }

            Row(
                Modifier
                    .fillMaxSize()
                    .padding(start = outer, end = outer, top = 3.dp, bottom = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(gap)
            ) {
                Klon16ScenicPanel(Modifier.width(scenicWidth).fillMaxHeight())

                Column(
                    Modifier.weight(1f).fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(if (phoneLandscape) 5.dp else 8.dp)
                ) {
                    Klon16TopStrip(
                        ble = ble,
                        altitudeMeters = altitude,
                        onNavigate = onNavigate,
                        onRequestLocation = onRequestLocation,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (phoneLandscape) 43.dp else (rootHeight * .105f).coerceIn(58.dp, 76.dp))
                    )

                    Row(
                        Modifier.weight(1f).fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(if (phoneLandscape) 6.dp else 10.dp)
                    ) {
                        // _18: Ana sıcaklık kartı tüm boşalan yüksekliği kullanır.
                        Klon16TemperatureCard(
                            ambient = ambient,
                            target = s.targetTemperatureC,
                            isOn = machineOn,
                            cooling = cooling,
                            controller = s.activeController,
                            vm = vm,
                            modifier = Modifier.weight(.60f).fillMaxHeight()
                        )

                        // _18: Sağdaki boş alan AKÜ/POMPA/ÇIKIŞ/FAN ile 2x2 dolduruldu.
                        Column(
                            Modifier.weight(.40f).fillMaxHeight(),
                            verticalArrangement = Arrangement.spacedBy(if (phoneLandscape) 5.dp else 8.dp)
                        ) {
                            Klon16StatusPanel(
                                s = s,
                                ambient = ambient,
                                rpm = rpm,
                                isOn = machineOn,
                                cooling = cooling,
                                vm = vm,
                                modifier = Modifier.fillMaxWidth().weight(.52f)
                            )
                            Klon18MetricGrid(
                                battery = battery,
                                pump = pump,
                                outlet = outlet,
                                rpm = rpm,
                                modifier = Modifier.fillMaxWidth().weight(.48f)
                            )
                        }
                    }
                }
            }
        } else {
            // _17: Dikey ekran yataydaki aynı görsel dili ve oranları kullanır.
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 7.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Klon16ScenicPanel(Modifier.fillMaxWidth().height(132.dp))

                Klon16TopStrip(
                    ble = ble,
                    altitudeMeters = altitude,
                    onNavigate = onNavigate,
                    onRequestLocation = onRequestLocation,
                    modifier = Modifier.fillMaxWidth().height(104.dp)
                )

                Klon16TemperatureCard(
                    ambient = ambient,
                    target = s.targetTemperatureC,
                    isOn = machineOn,
                    cooling = cooling,
                    controller = s.activeController,
                    vm = vm,
                    modifier = Modifier.fillMaxWidth().height(315.dp)
                )

                Klon16StatusPanel(
                    s = s,
                    ambient = ambient,
                    rpm = rpm,
                    isOn = machineOn,
                    cooling = cooling,
                    vm = vm,
                    modifier = Modifier.fillMaxWidth().height(160.dp)
                )

                Klon18MetricGrid(
                    battery = battery,
                    pump = pump,
                    outlet = outlet,
                    rpm = rpm,
                    modifier = Modifier.fillMaxWidth().height(136.dp)
                )
                Spacer(Modifier.height(2.dp))
            }
        }
    }
}

@Composable
private fun Klon16ScenicPanel(modifier: Modifier = Modifier) {
    Box(modifier.clip(RoundedCornerShape(22.dp))) {
        Image(
            painter = painterResource(R.drawable.klon_camp_panel16),
            contentDescription = "KLON karavan gece görünümü",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.horizontalGradient(
                    listOf(
                        Color.Transparent,
                        Color.Transparent,
                        Color(0xFF010A12).copy(alpha = .30f)
                    )
                )
            )
        )
    }
}

@Composable
private fun Klon16CompactBrand() {
    Column(Modifier.fillMaxWidth()) {
        Text("KLON", color = Color(0xFFEAF7FF), fontWeight = FontWeight.Black, fontSize = 34.sp, letterSpacing = 2.sp)
        Text("Dizel Isıtıcı", color = Color(0xFFD9E8F7), fontWeight = FontWeight.Black, fontSize = 22.sp)
    }
}

@Composable
private fun Klon16TopStrip(
    ble: BleUiState,
    altitudeMeters: Int?,
    onNavigate: (HeaterScreen) -> Unit,
    onRequestLocation: () -> Unit,
    modifier: Modifier = Modifier
) {
    val now = LocalDateTime.now()
    val time = now.format(DateTimeFormatter.ofPattern("HH:mm"))
    val date = now.format(DateTimeFormatter.ofPattern("dd MMM yyyy", java.util.Locale("tr", "TR")))
    val connected = ble.service181aFound || (
        ble.connectionState.contains("BAĞ", true) &&
            !ble.connectionState.contains("DEĞİL", true) &&
            !ble.connectionState.contains("KESİLDİ", true)
    )
    val deviceName = ble.connectedName.ifBlank { if (connected) "KLON-001" else "Cihaz bekleniyor" }
    val config = LocalConfiguration.current
    val compact = config.screenWidthDp < 720
    val dense = minOf(config.screenWidthDp, config.screenHeightDp) < 600

    if (compact) {
        Column(modifier, verticalArrangement = Arrangement.spacedBy(if (dense) 4.dp else 8.dp)) {
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Klon16InfoTile("clock", time, date, Modifier.weight(1f).fillMaxHeight())
                Klon16InfoTile(
                    "mountain",
                    altitudeMeters?.let { "$it m" } ?: "-- m",
                    "Rakım",
                    Modifier.weight(1f).fillMaxHeight(),
                    onClick = onRequestLocation
                )
            }
            Row(Modifier.weight(1f).fillMaxWidth()) {
                Klon16InfoTile(
                    "bluetooth",
                    if (connected) "Bağlı" else "Bağlı değil",
                    deviceName,
                    Modifier.fillMaxSize(),
                    onClick = { onNavigate(HeaterScreen.BLUETOOTH) },
                    positive = connected
                )
            }
        }
    } else {
        Row(modifier, horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Klon16InfoTile(
                icon = "clock",
                value = time,
                subtitle = date,
                modifier = Modifier.weight(1.03f).fillMaxHeight()
            )
            Klon16InfoTile(
                icon = "mountain",
                value = altitudeMeters?.let { "$it m" } ?: "-- m",
                subtitle = "Rakım",
                modifier = Modifier.weight(.98f).fillMaxHeight(),
                onClick = onRequestLocation
            )
            Klon16InfoTile(
                icon = "bluetooth",
                value = if (connected) "Bağlı" else "Bağlı değil",
                subtitle = deviceName,
                modifier = Modifier.weight(1.08f).fillMaxHeight(),
                onClick = { onNavigate(HeaterScreen.BLUETOOTH) },
                positive = connected
            )
        }
    }
}

@Composable
private fun Klon16InfoTile(
    icon: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    positive: Boolean = true
) {
    val config = LocalConfiguration.current
    val dense = minOf(config.screenWidthDp, config.screenHeightDp) < 600
    val shape = RoundedCornerShape(if (dense) 12.dp else 15.dp)
    val bg = Brush.verticalGradient(listOf(Color(0xFF061829), Color(0xFF04121F)))
    val content: @Composable () -> Unit = {
        Row(
            Modifier.fillMaxSize().background(bg, shape).padding(horizontal = if (dense) 9.dp else 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Klon16LineIcon(icon, Modifier.size(if (dense) 20.dp else 36.dp), Color(0xFF5DBBFF), if (dense) 1.8f else 2.6f)
            Spacer(Modifier.width(if (dense) 6.dp else 14.dp))
            Column(verticalArrangement = Arrangement.Center) {
                Text(
                    value,
                    color = if (icon == "bluetooth") {
                        if (positive) Color(0xFF31EA7E) else Color(0xFF91A5B8)
                    } else Color.White,
                    fontSize = if (dense) 13.sp else 20.sp,
                    lineHeight = if (dense) 14.sp else 21.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1
                )
                Text(subtitle, color = Color(0xFFA9C8E9), fontSize = if (dense) 8.sp else 12.sp, lineHeight = if (dense) 9.sp else 14.sp, maxLines = 1)
            }
        }
    }

    if (onClick == null) {
        Surface(
            modifier = modifier,
            shape = shape,
            color = Color.Transparent,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF17466D))
        ) { content() }
    } else {
        Surface(
            onClick = onClick,
            modifier = modifier,
            shape = shape,
            color = Color.Transparent,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF17466D))
        ) { content() }
    }
}

@Composable
private fun Klon16SettingsTile(modifier: Modifier, onClick: () -> Unit) {
    val config = LocalConfiguration.current
    val dense = minOf(config.screenWidthDp, config.screenHeightDp) < 600
    Surface(
        onClick = onClick,
        modifier = modifier,
        color = Color(0xFF061522),
        shape = RoundedCornerShape(if (dense) 12.dp else 15.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF17466D))
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Klon16LineIcon("gear", Modifier.size(if (dense) 21.dp else 36.dp), Color.White, if (dense) 2.1f else 2.4f)
        }
    }
}

private fun Klon19ControlModeLabel(controller: String, cooling: Boolean): String {
    if (cooling) return "SOĞUTMA DÖNGÜSÜ"
    return when {
        controller.isBlank() || controller.equals("YOK", true) -> "HAZIR"
        controller.equals("MANUEL", true) -> "MANUEL KONTROL"
        controller.equals("OTOMATİK", true) -> "OTOMATİK KONTROL"
        else -> controller.uppercase()
    }
}

@Composable
private fun Klon16TemperatureCard(
    ambient: Float,
    target: Int,
    isOn: Boolean,
    cooling: Boolean,
    controller: String,
    vm: HeaterViewModel,
    modifier: Modifier = Modifier
) {
    val config = LocalConfiguration.current
    val dense = minOf(config.screenWidthDp, config.screenHeightDp) < 600
    val shape = RoundedCornerShape(if (dense) 13.dp else 16.dp)
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color(0xFF061827)),
        shape = shape,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF17466D))
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = if (dense) 10.dp else 18.dp, vertical = if (dense) 7.dp else 13.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "İÇ ORTAM SICAKLIĞI",
                color = Color(0xFFA7C9EB),
                fontSize = if (dense) 10.sp else 16.sp,
                lineHeight = if (dense) 11.sp else 17.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = .45.sp
            )
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                // _20: Renkli sıcaklık şeridi ana çerçevenin optik merkezine alındı.
                // Dıştaki -10 / 0 / 20 / 30 / 40 rakamları bilinçli olarak gösterilmez.
                Box(
                    Modifier
                        .fillMaxSize()
                        .offset(y = if (dense) 6.dp else 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Klon16Gauge(
                        isOn = isOn,
                        cooling = cooling,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = if (dense) 1.dp else 5.dp)
                    )
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(top = if (dense) 10.dp else 18.dp)
                    ) {
                        Text(
                            "%.1f°".format(ambient),
                            color = Color.White,
                            fontSize = if (dense) 34.sp else 54.sp,
                            lineHeight = if (dense) 35.sp else 55.sp,
                            fontWeight = FontWeight.Black
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(if (dense) 9.dp else 12.dp)
                        ) {
                            Text(
                                when {
                                    isOn -> "ISITIYOR"
                                    cooling -> "SOĞUTMA"
                                    else -> "BEKLİYOR"
                                },
                                color = if (isOn) Color(0xFF16A2FF) else if (cooling) Color(0xFF69CFFF) else Color(0xFF8EA1B5),
                                fontSize = if (dense) 12.sp else 18.sp,
                                lineHeight = if (dense) 13.sp else 19.sp,
                                fontWeight = FontWeight.Black
                            )
                            if (isOn) {
                                // _20: Alev 2x büyütüldü; çevresinde güvenli boşluk bırakıldı.
                                AnimatedFlame(
                                    Modifier
                                        .size(if (dense) 30.dp else 48.dp)
                                        .padding(horizontal = if (dense) 2.dp else 3.dp)
                                )
                            } else if (cooling) {
                                // _20: Dönen fan 2x ve biraz sağda.
                                AnimatedCoolingFan(
                                    Modifier
                                        .size(if (dense) 30.dp else 48.dp)
                                        .offset(x = if (dense) 4.dp else 6.dp)
                                        .padding(horizontal = if (dense) 2.dp else 3.dp)
                                )
                            }
                        }
                        Text(
                            Klon19ControlModeLabel(controller, cooling),
                            color = Color(0xFFA9C3DE),
                            fontSize = if (dense) 9.sp else 11.sp,
                            lineHeight = if (dense) 10.sp else 12.sp,
                            maxLines = 1
                        )
                    }
                }
            }

            Text("HEDEF SICAKLIK", color = Color(0xFFABC8E7), fontSize = if (dense) 10.sp else 14.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(if (dense) 2.dp else 5.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Klon16AdjustButton("−") { vm.setTargetTemperature(target - 1) }
                Text(
                    "${target}°C",
                    color = Color(0xFF159DFF),
                    fontSize = if (dense) 20.sp else 31.sp,
                    lineHeight = if (dense) 21.sp else 32.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(horizontal = if (dense) 14.dp else 24.dp)
                )
                Klon16AdjustButton("+") { vm.setTargetTemperature(target + 1) }
            }
            Spacer(Modifier.height(5.dp))
        }
    }
}

@Composable
private fun Klon16Gauge(
    isOn: Boolean,
    cooling: Boolean,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "klon16_gauge")
    val glow by transition.animateFloat(
        initialValue = .46f,
        targetValue = .95f,
        animationSpec = infiniteRepeatable(tween(1250), RepeatMode.Reverse),
        label = "gauge_glow"
    )

    Canvas(modifier) {
        val minD = size.minDimension
        val center = Offset(size.width / 2f, size.height / 2f + minD * .01f)
        val radius = minD * .515f
        val stroke = minD * .050f
        val arcRect = androidx.compose.ui.geometry.Rect(
            center.x - radius,
            center.y - radius,
            center.x + radius,
            center.y + radius
        )
        val start = 140f
        val sweep = 260f

        drawArc(
            color = Color(0xFF0A2942),
            startAngle = start,
            sweepAngle = sweep,
            useCenter = false,
            topLeft = arcRect.topLeft,
            size = arcRect.size,
            style = Stroke(stroke * 1.18f, cap = StrokeCap.Round)
        )

        val colors = listOf(
            Color(0xFF087CFF),
            Color(0xFF11AFFF),
            Color(0xFF25D6FF),
            Color(0xFFFF787A),
            Color(0xFFFF5B80),
            Color(0xFF5C63FF)
        )
        val segments = 104
        for (i in 0 until segments) {
            val t = i.toFloat() / (segments - 1).toFloat()
            val scaled = t * (colors.size - 1)
            val ci = scaled.toInt().coerceIn(0, colors.size - 2)
            val local = scaled - ci
            val c1 = colors[ci]
            val c2 = colors[ci + 1]
            val r = c1.red + (c2.red - c1.red) * local
            val g = c1.green + (c2.green - c1.green) * local
            val b = c1.blue + (c2.blue - c1.blue) * local
            val c = Color(r, g, b, 1f)

            drawArc(
                color = c,
                startAngle = start + sweep * t,
                sweepAngle = sweep / segments + .65f,
                useCenter = false,
                topLeft = arcRect.topLeft,
                size = arcRect.size,
                style = Stroke(stroke, cap = StrokeCap.Butt)
            )
        }

        if (isOn || cooling) {
            val halo = if (isOn) Color(0xFF149EFF) else Color(0xFF62CAFF)
            drawArc(
                color = halo.copy(alpha = .08f + .10f * glow),
                startAngle = start,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(arcRect.left - stroke * .65f, arcRect.top - stroke * .65f),
                size = Size(arcRect.width + stroke * 1.3f, arcRect.height + stroke * 1.3f),
                style = Stroke(stroke * 1.35f, cap = StrokeCap.Round)
            )
        }

        for (i in 0..18) {
            val angleDeg = start + sweep * i / 18f
            val a = Math.toRadians(angleDeg.toDouble())
            val major = i % 3 == 0
            val rOuter = radius - stroke * .85f
            val rInner = rOuter - if (major) minD * .034f else minD * .020f
            val p1 = Offset(center.x + cos(a).toFloat() * rInner, center.y + sin(a).toFloat() * rInner)
            val p2 = Offset(center.x + cos(a).toFloat() * rOuter, center.y + sin(a).toFloat() * rOuter)
            drawLine(
                Color(0xFFD8ECFF).copy(alpha = if (major) .95f else .68f),
                p1,
                p2,
                strokeWidth = if (major) 2.4f else 1.25f,
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
private fun Klon16AdjustButton(text: String, onClick: () -> Unit) {
    val config = LocalConfiguration.current
    val dense = minOf(config.screenWidthDp, config.screenHeightDp) < 600
    Surface(
        onClick = onClick,
        modifier = Modifier.size(if (dense) 32.dp else 53.dp),
        shape = CircleShape,
        color = Color(0xFF0B2135),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF325D82))
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(text, color = Color.White, fontSize = if (dense) 19.sp else 29.sp, lineHeight = if (dense) 20.sp else 30.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun Klon16StatusPanel(
    s: HeaterUiState,
    ambient: Float,
    rpm: Int,
    isOn: Boolean,
    cooling: Boolean,
    vm: HeaterViewModel,
    modifier: Modifier = Modifier
) {
    val config = LocalConfiguration.current
    val dense = minOf(config.screenWidthDp, config.screenHeightDp) < 600
    var coolingElapsedSeconds by rememberSaveable { mutableStateOf(0L) }
    LaunchedEffect(cooling) {
        if (!cooling) {
            coolingElapsedSeconds = 0L
        } else {
            coolingElapsedSeconds = 0L
            while (true) {
                delay(1_000)
                coolingElapsedSeconds += 1L
            }
        }
    }
    val coolingMinutes = coolingElapsedSeconds / 60L
    val coolingSeconds = coolingElapsedSeconds % 60L
    val coolingTimeText = "%02d:%02d".format(coolingMinutes, coolingSeconds)
    val shape = RoundedCornerShape(if (dense) 12.dp else 16.dp)
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color(0xFF061827)),
        shape = shape,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF17466D))
    ) {
        if (dense) {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 7.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(1.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth().weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        Modifier.weight(1f),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (isOn) Color(0xFF25F08B) else Color(0xFF60778C))
                            )
                            Spacer(Modifier.width(5.dp))
                            Text(
                                "ISITICI DURUMU",
                                color = Color(0xFFA4C6E8),
                                fontSize = 8.sp,
                                lineHeight = 9.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Spacer(Modifier.height(1.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(
                                when {
                                    isOn -> "ÇALIŞIYOR"
                                    cooling -> "SOĞUTMA"
                                    else -> "BEKLİYOR"
                                },
                                color = if (isOn) Color(0xFF129FFF) else if (cooling) Color(0xFF6DCBFF) else Color(0xFF8FA1B5),
                                fontSize = 15.sp,
                                lineHeight = 16.sp,
                                fontWeight = FontWeight.Black
                            )
                            if (isOn) {
                                AnimatedFlame(
                                    Modifier
                                        .size(26.dp)
                                        .padding(horizontal = 2.dp)
                                )
                            } else if (cooling) {
                                AnimatedCoolingFan(
                                    Modifier
                                        .size(26.dp)
                                        .offset(x = 3.dp)
                                        .padding(horizontal = 2.dp)
                                )
                            }
                        }
                        Text(
                            Klon19ControlModeLabel(s.activeController, cooling),
                            color = Color(0xFF9FBBD5),
                            fontSize = 6.sp,
                            lineHeight = 7.sp,
                            maxLines = 1
                        )
                        if (cooling) {
                            Text(
                                "SÜRE $coolingTimeText  •  Normal: 2–5 dk",
                                color = Color(0xFF79D7FF),
                                fontSize = 5.6.sp,
                                lineHeight = 6.2.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }
                    }
                    Klon16PremiumPowerButton(isOn, cooling, vm::togglePower)
                }

                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF244662)))

                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ÜFLEME", color = Color(0xFFABC6E1), fontSize = 7.sp, lineHeight = 8.sp)
                    Spacer(Modifier.width(5.dp))
                    Text("${s.fanLevel}/10", color = Color.White, fontSize = 11.sp, lineHeight = 12.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.width(5.dp))
                    Klon16LineIcon("fan", Modifier.size(13.dp), Color(0xFF78AEE2), 1.7f)
                    Spacer(Modifier.weight(1f))
                    Text("FAN", color = Color(0xFFABC6E1), fontSize = 7.sp, lineHeight = 8.sp)
                    Spacer(Modifier.width(4.dp))
                    Text("$rpm RPM", color = Color(0xFF169FFF), fontSize = 10.sp, lineHeight = 11.sp, fontWeight = FontWeight.Black, maxLines = 1)
                }

                Klon16FanSlider(
                    value = s.fanLevel.coerceIn(1, 10),
                    onValueChange = vm::setFanLevel,
                    modifier = Modifier.fillMaxWidth().height(9.dp)
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("1 SESSİZ", color = Color(0xFF91ACC5), fontSize = 6.sp, lineHeight = 7.sp)
                    Text("10 GÜÇLÜ", color = Color(0xFF91ACC5), fontSize = 6.sp, lineHeight = 7.sp)
                }
            }
        } else {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth().weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        Modifier.weight(1f),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(9.dp).clip(CircleShape).background(if (isOn) Color(0xFF25F08B) else Color(0xFF60778C)))
                            Spacer(Modifier.width(8.dp))
                            Text("ISITICI DURUMU", color = Color(0xFFA4C6E8), fontSize = 13.sp, fontWeight = FontWeight.Black)
                        }
                        Spacer(Modifier.height(5.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                when {
                                    isOn -> "ÇALIŞIYOR"
                                    cooling -> "SOĞUTMA"
                                    else -> "BEKLİYOR"
                                },
                                color = if (isOn) Color(0xFF129FFF) else if (cooling) Color(0xFF6DCBFF) else Color(0xFF8FA1B5),
                                fontSize = 24.sp,
                                lineHeight = 25.sp,
                                fontWeight = FontWeight.Black
                            )
                            if (isOn) {
                                AnimatedFlame(
                                    Modifier
                                        .size(48.dp)
                                        .padding(horizontal = 3.dp)
                                )
                            } else if (cooling) {
                                AnimatedCoolingFan(
                                    Modifier
                                        .size(48.dp)
                                        .offset(x = 6.dp)
                                        .padding(horizontal = 3.dp)
                                )
                            }
                        }
                        Text(
                            Klon19ControlModeLabel(s.activeController, cooling),
                            color = Color(0xFFB2C8DF),
                            fontSize = 9.sp,
                            lineHeight = 10.sp
                        )
                        if (cooling) {
                            Text(
                                "SOĞUTMA SÜRESİ  $coolingTimeText",
                                color = Color(0xFF79D7FF),
                                fontSize = 10.sp,
                                lineHeight = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                "Normal soğutma genelde 2–5 dk sürer",
                                color = Color(0xFF9AB5CC),
                                fontSize = 7.5.sp,
                                lineHeight = 8.5.sp
                            )
                        }
                    }
                    Klon16PremiumPowerButton(isOn, cooling, vm::togglePower)
                }

                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF244662)))

                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(.52f)) {
                        Text("ÜFLEME", color = Color(0xFFABC6E1), fontSize = 10.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${s.fanLevel} / 10", color = Color.White, fontSize = 21.sp, lineHeight = 22.sp, fontWeight = FontWeight.Black)
                            Spacer(Modifier.width(12.dp))
                            Klon16LineIcon("fan", Modifier.size(30.dp), Color(0xFF78AEE2), 2.0f)
                        }
                    }
                    Box(Modifier.width(1.dp).height(42.dp).background(Color(0xFF26465E)))
                    Spacer(Modifier.width(18.dp))
                    Column(Modifier.weight(.48f)) {
                        Text("GERÇEK FAN", color = Color(0xFFABC6E1), fontSize = 10.sp)
                        Text("$rpm RPM", color = Color(0xFF169FFF), fontSize = 17.sp, lineHeight = 18.sp, fontWeight = FontWeight.Black, maxLines = 1)
                    }
                }

                Klon16FanSlider(
                    value = s.fanLevel.coerceIn(1, 10),
                    onValueChange = vm::setFanLevel,
                    modifier = Modifier.fillMaxWidth().height(20.dp)
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("1 SESSİZ", color = Color(0xFFB4CBE1), fontSize = 8.sp)
                    Text("10 GÜÇLÜ", color = Color(0xFFB4CBE1), fontSize = 8.sp)
                }

                if (s.batteryVoltage < 11.8f) {
                    Text("⚠ Akü voltajı düşük", color = Color(0xFFFF8178), fontSize = 8.sp, fontWeight = FontWeight.Black)
                } else if (!isOn && ambient <= 4f && s.frostProtectionEnabled) {
                    Text("❄ Don koruma hazır", color = Color(0xFF78D9FF), fontSize = 8.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
private fun Klon16PremiumPowerButton(on: Boolean, cooling: Boolean, onClick: () -> Unit) {
    val config = LocalConfiguration.current
    val dense = minOf(config.screenWidthDp, config.screenHeightDp) < 600
    val transition = rememberInfiniteTransition(label = "klon21_power")
    val glow by transition.animateFloat(
        initialValue = .38f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1450), RepeatMode.Reverse),
        label = "power_glow"
    )
    val accent = when {
        cooling -> Color(0xFF6DCBFF)
        on -> Color(0xFF079CFF)
        else -> Color(0xFF54758F)
    }
    val buttonSize = if (dense) 52.dp else 98.dp

    Box(
        Modifier
            .size(buttonSize)
            .clip(CircleShape)
            .clickable(enabled = !cooling, onClick = onClick)
            .graphicsLayer { alpha = if (cooling) .78f else 1f },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            val c = Offset(size.width / 2f, size.height / 2f)

            drawCircle(accent.copy(alpha = .08f + glow * .10f), radius = r * .98f, center = c)
            drawCircle(accent.copy(alpha = .12f + glow * .12f), radius = r * .88f, center = c)
            drawCircle(Color(0xFF03111C), radius = r * .76f, center = c)
            drawCircle(accent, radius = r * .83f, center = c, style = Stroke(width = r * .075f))
            drawCircle(
                Color(0xFF48D2FF).copy(alpha = if (on || cooling) .92f else .42f),
                radius = r * .69f,
                center = c,
                style = Stroke(width = r * .024f)
            )

            val glyphCenter = Offset(c.x, c.y - r * .10f)
            val glyphR = r * .27f
            val glyphStroke = r * .075f
            drawArc(
                color = Color.White,
                startAngle = -40f,
                sweepAngle = 260f,
                useCenter = false,
                topLeft = Offset(glyphCenter.x - glyphR, glyphCenter.y - glyphR),
                size = Size(glyphR * 2f, glyphR * 2f),
                style = Stroke(width = glyphStroke, cap = StrokeCap.Round)
            )
            drawLine(
                color = Color.White,
                start = Offset(glyphCenter.x, glyphCenter.y - glyphR * 1.20f),
                end = Offset(glyphCenter.x, glyphCenter.y + glyphR * .08f),
                strokeWidth = glyphStroke,
                cap = StrokeCap.Round
            )
        }

        val actionText = when {
            cooling -> "SOĞUTMA\nDEVAM EDİYOR"
            on -> "DURDUR"
            else -> "BAŞLAT"
        }
        Text(
            actionText,
            color = Color.White,
            fontSize = when {
                cooling && dense -> 4.6.sp
                cooling -> 7.5.sp
                dense -> 5.8.sp
                else -> 9.5.sp
            },
            lineHeight = when {
                cooling && dense -> 5.0.sp
                cooling -> 8.0.sp
                dense -> 6.3.sp
                else -> 10.sp
            },
            textAlign = TextAlign.Center,
            maxLines = if (cooling) 2 else 1,
            fontWeight = FontWeight.Black,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(start = 2.dp, end = 2.dp, bottom = if (dense) 5.dp else 10.dp)
        )
    }
}

@Composable
private fun Klon16FanSlider(
    value: Int,
    onValueChange: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier.clickable {
            val next = if (value >= 10) 1 else value + 1
            onValueChange(next)
        }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cy = size.height / 2f
            val startX = size.height * .34f
            val endX = size.width - startX
            drawLine(Color(0xFF173750), Offset(startX, cy), Offset(endX, cy), strokeWidth = 13f, cap = StrokeCap.Round)
            val fraction = (value - 1) / 9f
            val activeEnd = startX + (endX - startX) * fraction
            drawLine(Color(0xFF119EFF), Offset(startX, cy), Offset(activeEnd.coerceAtLeast(startX + 1f), cy), strokeWidth = 13f, cap = StrokeCap.Round)

            for (i in 0..9) {
                val x = startX + (endX - startX) * i / 9f
                drawCircle(
                    color = if (i <= value - 1) Color(0xFF79CAFF) else Color(0xFF74A0C3),
                    radius = if (i == value - 1) 5.2f else 2.4f,
                    center = Offset(x, cy)
                )
            }

            val knobX = startX + (endX - startX) * fraction
            drawLine(Color.White, Offset(knobX, cy - 12f), Offset(knobX, cy + 12f), strokeWidth = 3.5f, cap = StrokeCap.Round)
            drawCircle(Color.White, 5.4f, Offset(knobX, cy))
        }
    }
}

@Composable
private fun Klon18MetricGrid(
    battery: Float,
    pump: Float,
    outlet: Float,
    rpm: Int,
    modifier: Modifier = Modifier
) {
    val config = LocalConfiguration.current
    val dense = minOf(config.screenWidthDp, config.screenHeightDp) < 600
    Column(
        modifier,
        verticalArrangement = Arrangement.spacedBy(if (dense) 4.dp else 7.dp)
    ) {
        Row(
            Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(if (dense) 4.dp else 7.dp)
        ) {
            Klon16MetricCard("battery", "AKÜ", "%.1f V".format(battery), Modifier.weight(1f).fillMaxHeight())
            Klon16MetricCard("pump", "POMPA", "%.1f Hz".format(pump), Modifier.weight(1f).fillMaxHeight())
        }
        Row(
            Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(if (dense) 4.dp else 7.dp)
        ) {
            Klon16MetricCard("thermo", "ÇIKIŞ", "%.0f°C".format(outlet), Modifier.weight(1f).fillMaxHeight())
            Klon16MetricCard("fan", "FAN", "$rpm", Modifier.weight(1f).fillMaxHeight())
        }
    }
}

@Composable
private fun Klon16MetricCard(
    icon: String,
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    val config = LocalConfiguration.current
    val dense = minOf(config.screenWidthDp, config.screenHeightDp) < 600
    val shape = RoundedCornerShape(if (dense) 12.dp else 15.dp)
    Column(
        modifier = modifier
            .background(Brush.verticalGradient(listOf(Color(0xFF071C2D), Color(0xFF04131F))), shape)
            .border(1.dp, Color(0xFF17466D), shape)
            .padding(horizontal = if (dense) 4.dp else 7.dp, vertical = if (dense) 4.dp else 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(title, color = Color(0xFFA9C6E2), fontSize = if (dense) 8.sp else 10.sp, lineHeight = if (dense) 9.sp else 11.sp)
        Spacer(Modifier.height(if (dense) 2.dp else 5.dp))
        Klon16LineIcon(icon, Modifier.size(if (dense) 15.dp else 27.dp), Color(0xFF5DBDFF), if (dense) 1.9f else 2.3f)
        Spacer(Modifier.height(if (dense) 2.dp else 5.dp))
        Text(value, color = Color.White, fontSize = if (dense) 11.sp else 17.sp, lineHeight = if (dense) 12.sp else 18.sp, fontWeight = FontWeight.Black, maxLines = 1)
    }
}

@Composable
private fun Klon16QuickControls(
    s: HeaterUiState,
    vm: HeaterViewModel,
    onNavigate: (HeaterScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    val config = LocalConfiguration.current
    val dense = minOf(config.screenWidthDp, config.screenHeightDp) < 600
    val wide = config.screenWidthDp >= 700
    if (wide) {
        Row(modifier, horizontalArrangement = Arrangement.spacedBy(if (dense) 6.dp else 10.dp)) {
            Klon16QuickTile("thermo", "Termostat", s.thermostatEnabled, Modifier.weight(1f)) { onNavigate(HeaterScreen.THERMOSTAT) }
            Klon16QuickTile("clock", "Program", s.dailyProgramEnabled || s.weeklyProgramEnabled, Modifier.weight(1f)) { onNavigate(HeaterScreen.PROGRAMS) }
            Klon16QuickTile("moon", "Gece", s.nightModeEnabled, Modifier.weight(1f), vm::toggleNightMode)
            Klon16QuickTile("bolt", "Turbo", s.boostEnabled, Modifier.weight(1f), vm::toggleBoost)
            Klon16QuickTile("snow", "Don Koruma", s.frostProtectionEnabled, Modifier.weight(1.08f), vm::toggleFrostProtection)
        }
    } else {
        Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Klon16QuickTile("thermo", "Termostat", s.thermostatEnabled, Modifier.weight(1f)) { onNavigate(HeaterScreen.THERMOSTAT) }
                Klon16QuickTile("clock", "Program", s.dailyProgramEnabled || s.weeklyProgramEnabled, Modifier.weight(1f)) { onNavigate(HeaterScreen.PROGRAMS) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Klon16QuickTile("moon", "Gece", s.nightModeEnabled, Modifier.weight(1f), vm::toggleNightMode)
                Klon16QuickTile("bolt", "Turbo", s.boostEnabled, Modifier.weight(1f), vm::toggleBoost)
                Klon16QuickTile("snow", "Don Koruma", s.frostProtectionEnabled, Modifier.weight(1f), vm::toggleFrostProtection)
            }
        }
    }
}

@Composable
private fun Klon16QuickTile(
    icon: String,
    label: String,
    active: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val config = LocalConfiguration.current
    val dense = minOf(config.screenWidthDp, config.screenHeightDp) < 600
    val shape = RoundedCornerShape(if (dense) 12.dp else 15.dp)
    Box(
        modifier
            .fillMaxHeight()
            .background(
                Brush.verticalGradient(
                    if (active) listOf(Color(0xFF0A2F4D), Color(0xFF061A2B))
                    else listOf(Color(0xFF071C2D), Color(0xFF04131F))
                ),
                shape
            )
            .border(1.dp, if (active) Color(0xFF1B8AE2) else Color(0xFF17517F), shape)
            .clip(shape)
            .clickable(onClick = onClick)
            .padding(if (dense) 4.dp else 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Klon16LineIcon(
                icon,
                Modifier.size(if (dense) 16.dp else 27.dp),
                when (icon) {
                    "bolt" -> Color(0xFFFFD21F)
                    "snow" -> Color(0xFF5EBBFF)
                    else -> Color(0xFF5AB9FF)
                },
                2.4f
            )
            Spacer(Modifier.height(if (dense) 1.dp else 3.dp))
            Text(label, color = Color.White, fontSize = if (dense) 9.sp else 13.sp, lineHeight = if (dense) 10.sp else 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        }
    }
}

@Composable
private fun Klon16LineIcon(
    kind: String,
    modifier: Modifier = Modifier,
    color: Color = Color(0xFF5DB8FF),
    strokeWidth: Float = 2.2f
) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val s = minOf(w, h)
        val c = Offset(w / 2f, h / 2f)
        val sw = strokeWidth

        when (kind) {
            "clock" -> {
                drawCircle(color, s * .36f, c, style = Stroke(sw))
                drawLine(color, c, Offset(c.x, c.y - s * .19f), sw, StrokeCap.Round)
                drawLine(color, c, Offset(c.x + s * .16f, c.y + s * .09f), sw, StrokeCap.Round)
            }
            "mountain" -> {
                val pth = Path().apply {
                    moveTo(w * .08f, h * .78f)
                    lineTo(w * .38f, h * .26f)
                    lineTo(w * .55f, h * .49f)
                    lineTo(w * .67f, h * .32f)
                    lineTo(w * .94f, h * .78f)
                    close()
                }
                drawPath(pth, color, style = Stroke(sw, cap = StrokeCap.Round))
                drawLine(color, Offset(w * .05f, h * .80f), Offset(w * .95f, h * .80f), sw, StrokeCap.Round)
            }
            "bluetooth" -> {
                val pth = Path().apply {
                    moveTo(w * .46f, h * .08f)
                    lineTo(w * .73f, h * .33f)
                    lineTo(w * .46f, h * .56f)
                    lineTo(w * .46f, h * .08f)
                    moveTo(w * .46f, h * .44f)
                    lineTo(w * .73f, h * .67f)
                    lineTo(w * .46f, h * .92f)
                    lineTo(w * .46f, h * .44f)
                    moveTo(w * .18f, h * .25f)
                    lineTo(w * .72f, h * .73f)
                    moveTo(w * .18f, h * .75f)
                    lineTo(w * .72f, h * .27f)
                }
                drawPath(pth, color, style = Stroke(sw, cap = StrokeCap.Round))
            }
            "gear" -> {
                drawCircle(color, s * .22f, c, style = Stroke(sw))
                drawCircle(color, s * .08f, c, style = Stroke(sw))
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val p1 = Offset(c.x + cos(a).toFloat() * s * .27f, c.y + sin(a).toFloat() * s * .27f)
                    val p2 = Offset(c.x + cos(a).toFloat() * s * .40f, c.y + sin(a).toFloat() * s * .40f)
                    drawLine(color, p1, p2, sw, StrokeCap.Round)
                }
            }
            "home" -> {
                val pth = Path().apply {
                    moveTo(w * .16f, h * .48f)
                    lineTo(w * .50f, h * .18f)
                    lineTo(w * .84f, h * .48f)
                    moveTo(w * .25f, h * .43f)
                    lineTo(w * .25f, h * .82f)
                    lineTo(w * .75f, h * .82f)
                    lineTo(w * .75f, h * .43f)
                    moveTo(w * .43f, h * .82f)
                    lineTo(w * .43f, h * .62f)
                    lineTo(w * .58f, h * .62f)
                    lineTo(w * .58f, h * .82f)
                }
                drawPath(pth, color, style = Stroke(sw, cap = StrokeCap.Round))
            }
            "thermo" -> {
                drawCircle(color, s * .13f, Offset(c.x, h * .74f), style = Stroke(sw))
                drawLine(color, Offset(c.x, h * .68f), Offset(c.x, h * .20f), sw * 1.15f, StrokeCap.Round)
                drawLine(color, Offset(c.x - s * .10f, h * .20f), Offset(c.x - s * .10f, h * .63f), sw, StrokeCap.Round)
                drawLine(color, Offset(c.x + s * .10f, h * .20f), Offset(c.x + s * .10f, h * .63f), sw, StrokeCap.Round)
                drawArc(
                    color = color,
                    startAngle = 180f,
                    sweepAngle = 180f,
                    useCenter = false,
                    topLeft = Offset(c.x - s * .10f, h * .12f),
                    size = Size(s * .20f, s * .16f),
                    style = Stroke(sw)
                )
            }
            "battery" -> {
                val left = w * .16f
                val top = h * .28f
                val rw = w * .62f
                val rh = h * .46f
                drawRoundRect(
                    color = color,
                    topLeft = Offset(left, top),
                    size = Size(rw, rh),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(s * .05f),
                    style = Stroke(sw)
                )
                drawRect(color, Offset(left + rw, top + rh * .32f), Size(w * .08f, rh * .36f))
                drawRoundRect(
                    color = color.copy(alpha = .85f),
                    topLeft = Offset(left + 4f, top + 4f),
                    size = Size((rw - 8f) * .78f, rh - 8f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(s * .03f)
                )
            }
            "pump" -> {
                drawRoundRect(
                    color = color,
                    topLeft = Offset(w * .20f, h * .19f),
                    size = Size(w * .40f, h * .62f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(s * .04f),
                    style = Stroke(sw)
                )
                drawRect(color, Offset(w * .27f, h * .26f), Size(w * .25f, h * .18f), style = Stroke(sw))
                drawLine(color, Offset(w * .60f, h * .31f), Offset(w * .75f, h * .42f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .75f, h * .42f), Offset(w * .75f, h * .67f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .75f, h * .67f), Offset(w * .64f, h * .67f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .17f, h * .81f), Offset(w * .65f, h * .81f), sw, StrokeCap.Round)
            }
            "fan" -> {
                drawCircle(color, s * .07f, c)
                for (i in 0 until 4) {
                    rotate(i * 90f, c) {
                        drawOval(
                            color.copy(alpha = .88f),
                            topLeft = Offset(c.x - s * .08f, c.y - s * .34f),
                            size = Size(s * .16f, s * .27f)
                        )
                    }
                }
            }
            "moon" -> {
                drawCircle(color, s * .34f, c)
                drawCircle(Color(0xFF071827), s * .31f, Offset(c.x + s * .16f, c.y - s * .10f))
            }
            "bolt" -> {
                val pth = Path().apply {
                    moveTo(w * .57f, h * .06f)
                    lineTo(w * .25f, h * .53f)
                    lineTo(w * .47f, h * .53f)
                    lineTo(w * .37f, h * .94f)
                    lineTo(w * .76f, h * .43f)
                    lineTo(w * .54f, h * .43f)
                    close()
                }
                drawPath(pth, color)
            }
            "snow" -> {
                for (i in 0 until 3) {
                    rotate(i * 60f, c) {
                        drawLine(color, Offset(c.x, h * .11f), Offset(c.x, h * .89f), sw, StrokeCap.Round)
                        drawLine(color, Offset(c.x, h * .18f), Offset(c.x - s * .10f, h * .29f), sw, StrokeCap.Round)
                        drawLine(color, Offset(c.x, h * .18f), Offset(c.x + s * .10f, h * .29f), sw, StrokeCap.Round)
                        drawLine(color, Offset(c.x, h * .82f), Offset(c.x - s * .10f, h * .71f), sw, StrokeCap.Round)
                        drawLine(color, Offset(c.x, h * .82f), Offset(c.x + s * .10f, h * .71f), sw, StrokeCap.Round)
                    }
                }
            }
            "bars" -> {
                drawLine(color, Offset(w * .24f, h * .80f), Offset(w * .24f, h * .58f), sw * 1.2f, StrokeCap.Round)
                drawLine(color, Offset(w * .44f, h * .80f), Offset(w * .44f, h * .42f), sw * 1.2f, StrokeCap.Round)
                drawLine(color, Offset(w * .64f, h * .80f), Offset(w * .64f, h * .27f), sw * 1.2f, StrokeCap.Round)
                drawLine(color, Offset(w * .82f, h * .80f), Offset(w * .82f, h * .13f), sw * 1.2f, StrokeCap.Round)
            }
        }
    }
}


@Composable
private fun HomePage(
    s: HeaterUiState,
    ble: BleUiState,
    vm: HeaterViewModel,
    wide: Boolean,
    onNavigate: (HeaterScreen) -> Unit,
    onRequestLocation: () -> Unit
) {
    FriendlyHeader(s) { onNavigate(HeaterScreen.SETTINGS) }
    HomeInfoStrip(s, ble, onRequestLocation)
    HomeWarningBanner(s)
    if (wide) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            HeatDialCard(s, vm, wide = true, modifier = Modifier.weight(1f))
            PowerFanCard(s, vm, Modifier.weight(1f))
        }
    } else {
        HeatDialCard(s, vm, wide = false)
        PowerFanCard(s, vm)
    }
    if (s.frostProtectionEnabled) FrostActiveBanner(s)
    EnvironmentMetrics(s)
    RuntimeSummary(s)
    FavoriteActions(s, vm, wide)
    QuickActions(s, vm, wide, onNavigate)
}

@Composable
private fun FriendlyHeader(s: HeaterUiState, onSettings: () -> Unit) {
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    val cooling = !s.isHeaterOn && s.statusText.equals("SOĞUTMA", true)
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("KLON", color = Color(0xFF58A6FF), fontSize = if (wide) 20.sp else 17.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("Dizel Isıtıcı", fontWeight = FontWeight.Black, fontSize = if (wide) 36.sp else 31.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
            if (s.frostProtectionEnabled) {
                StatusPill(if (wide) "❄ DON KORUMA" else "❄ DON", Color(0xFF72D7FF))
            }
            StatusPill(if (s.isDemoMode) "DEMO" else "GERÇEK MOD", if (s.isDemoMode) Color(0xFF64B5FF) else Color(0xFF51D5B7))
            StatusPill(
                when {
                    s.isHeaterOn -> if (s.activeController == "TURBO") "TURBO" else s.statusText.uppercase()
                    cooling -> "SOĞUTMA"
                    else -> "KAPALI"
                },
                when {
                    s.isHeaterOn -> Color(0xFF2F80ED)
                    cooling -> Color(0xFF70B9E8)
                    else -> Color(0xFF7E8990)
                }
            )
            Box(
                Modifier.size(if (wide) 48.dp else 44.dp).clip(CircleShape).background(Color(0xFF171C21)).clickable(onClick = onSettings),
                contentAlignment = Alignment.Center
            ) { Text("⚙", fontSize = if (wide) 22.sp else 20.sp) }
        }
    }
}

@Composable
private fun HomeInfoStrip(s: HeaterUiState, ble: BleUiState, onRequestLocation: () -> Unit) {
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    val now = LocalDateTime.now()
    val time = now.format(DateTimeFormatter.ofPattern("HH:mm"))
    val date = now.format(DateTimeFormatter.ofPattern("dd.MM"))
    val connected = ble.service181aFound || ble.connectionState.contains("BAĞ", ignoreCase = true) && !ble.connectionState.contains("DEĞİL", ignoreCase = true)
    val altitudeText = s.altitudeMeters?.let { "$it m" } ?: if (s.isDemoMode) "36 m" else "İZİN"
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1419)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = if (wide) 18.dp else 12.dp, vertical = if (wide) 12.dp else 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            InfoChip("SAAT", time, date, Color(0xFF58A6FF), Modifier.weight(1f))
            Surface(
                onClick = onRequestLocation,
                modifier = Modifier.weight(1f),
                color = Color.Transparent,
                shape = RoundedCornerShape(14.dp)
            ) {
                InfoChip("RAKIM", altitudeText, if (s.isDemoMode) "DEMO / GPS" else "GPS", Color(0xFF8AB4F8), Modifier.fillMaxWidth())
            }
            InfoChip(
                "BLUETOOTH",
                if (connected) "BAĞLI" else "BAĞLI DEĞİL",
                if (ble.service181aFound) "181A HAZIR" else ble.connectionState,
                if (connected) Color(0xFF58A6FF) else Color(0xFF8B969E),
                Modifier.weight(1.25f)
            )
        }
    }
}

@Composable
private fun InfoChip(title: String, value: String, subtitle: String, accent: Color, modifier: Modifier = Modifier) {
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    Column(
        modifier.background(Color(0xFF131A20), RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, color = Color(0xFF9CAAB4), fontSize = if (wide) 13.sp else 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(value, color = accent, fontSize = if (wide) 21.sp else 16.sp, fontWeight = FontWeight.Black, maxLines = 1)
        Text(subtitle, color = Color(0xFF6F7B84), fontSize = if (wide) 10.sp else 8.sp, maxLines = 1)
    }
}

@Composable
private fun HomeWarningBanner(s: HeaterUiState) {
    val latestError = s.errorLog.firstOrNull()
    val lowBattery = s.batteryVoltage < 11.8f
    if (latestError == null && !lowBattery) return
    val title = if (lowBattery) "AKÜ VOLTAJI DÜŞÜK" else latestError!!.title
    val detail = if (lowBattery) "${"%.1f".format(s.batteryVoltage)} V • Isıtıcıyı başlatmadan önce aküyü kontrol edin." else latestError!!.detail
    Card(
        Modifier.fillMaxWidth().border(1.dp, Color(0xFFFF6B5F).copy(alpha = .7f), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2B1517)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("⚠", fontSize = 24.sp, color = Color(0xFFFF6B5F))
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, color = Color(0xFFFF8A80), fontWeight = FontWeight.Black, fontSize = 15.sp)
                Text(detail, color = Color(0xFFC7A5A5), fontSize = 12.sp, maxLines = 2)
            }
        }
    }
}

@Composable
private fun StatusPill(text: String, color: Color) {
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    Box(
        Modifier
            .background(color.copy(alpha = .13f), RoundedCornerShape(50))
            .border(1.dp, color.copy(alpha = .45f), RoundedCornerShape(50))
            .padding(horizontal = if (wide) 13.dp else 11.dp, vertical = if (wide) 6.dp else 5.dp)
    ) { Text(text, color = color, fontWeight = FontWeight.Black, fontSize = if (wide) 16.sp else 14.sp) }
}


private fun temperatureBandColor(temp: Float): Color = when {
    temp <= 4f -> Color(0xFFF3F7FF)
    temp <= 12f -> Color(0xFF58A6FF)
    temp <= 18f -> Color(0xFF53D38A)
    temp <= 30f -> Color(0xFFFFD84D)
    else -> Color(0xFFFF5C4D)
}

private fun temperatureBandLabel(temp: Float): String = when {
    temp <= 4f -> "ÇOK SOĞUK"
    temp <= 12f -> "SOĞUK"
    temp <= 18f -> "ILIK"
    temp <= 30f -> "SICAK"
    else -> "ÇOK SICAK"
}

@Composable
private fun TemperatureBandPill(temp: Float) {
    val color = temperatureBandColor(temp)
    Box(
        Modifier
            .background(color.copy(alpha = .14f), RoundedCornerShape(50))
            .border(1.dp, color.copy(alpha = .55f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(temperatureBandLabel(temp), color = color, fontWeight = FontWeight.Black, fontSize = if (LocalConfiguration.current.screenWidthDp >= 720) 15.sp else 12.sp)
    }
}

@Composable
private fun HeatDialCard(s: HeaterUiState, vm: HeaterViewModel, wide: Boolean, modifier: Modifier = Modifier) {
    var demoControlsExpanded by rememberSaveable { mutableStateOf(false) }
    Card(modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF11161B)), shape = RoundedCornerShape(30.dp)) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = if (wide) 22.dp else 18.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("ORTAM SICAKLIĞI", color = Color(0xFFB6C1CA), fontSize = if (wide) 24.sp else 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Spacer(Modifier.height(6.dp))
            Box(Modifier.size(if (wide) 292.dp else 245.dp), contentAlignment = Alignment.Center) {
                HeaterDial(s.ambientTemperatureC, s.targetTemperatureC, s.isHeaterOn, s.statusText, s.frostProtectionEnabled)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("%.1f°".format(s.ambientTemperatureC), fontSize = if (wide) 76.sp else 62.sp, lineHeight = if (wide) 78.sp else 64.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(6.dp))
                    TemperatureBandPill(s.ambientTemperatureC)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val cooling = !s.isHeaterOn && s.statusText.equals("SOĞUTMA", true)
                        Text(
                            when {
                                s.isHeaterOn && s.activeController == "TURBO" -> "TURBO"
                                s.isHeaterOn -> "ISITIYOR"
                                cooling -> "SOĞUTMA"
                                else -> "BEKLİYOR"
                            },
                            color = when {
                                s.isHeaterOn -> Color(0xFF2F80ED)
                                cooling -> Color(0xFF70B9E8)
                                else -> Color(0xFF7E8990)
                            },
                            fontSize = if (wide) 22.sp else 17.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = .8.sp
                        )
                        if (s.isHeaterOn) AnimatedFlame(Modifier.size(if (wide) 27.dp else 21.dp))
                        else if (cooling) AnimatedCoolingFan(Modifier.size(if (wide) 25.dp else 20.dp))
                    }
                    Spacer(Modifier.height(5.dp))
                    Text(s.activeController.uppercase(), color = Color(0xFF9CB3C7), fontSize = if (wide) 17.sp else 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(2.dp))
            Text("HEDEF SICAKLIK", color = Color(0xFFB6C5D0), fontSize = if (wide) 23.sp else 17.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
            Spacer(Modifier.height(5.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                RoundAdjustButton("−") { vm.setTargetTemperature(s.targetTemperatureC - 1) }
                Text(
                    "${s.targetTemperatureC}°C",
                    modifier = Modifier.padding(horizontal = if (wide) 30.dp else 24.dp),
                    fontSize = if (wide) 34.sp else 28.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF58A6FF)
                )
                RoundAdjustButton("+") { vm.setTargetTemperature(s.targetTemperatureC + 1) }
            }
            if (s.isDemoMode) {
                Spacer(Modifier.height(11.dp))
                Surface(
                    onClick = { demoControlsExpanded = !demoControlsExpanded },
                    color = Color(0xFF171D22),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF252D33))
                ) {
                    Text(
                        if (demoControlsExpanded) "DEMO ORTAM AYARI  ▲" else "DEMO ORTAM AYARI  ▼",
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        color = Color(0xFF7F8A91),
                        fontSize = if (wide) 16.sp else 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                if (demoControlsExpanded) {
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        SmallAdjustButton("−0.5") { vm.setAmbientTemperature(s.ambientTemperatureC - .5f) }
                        Text("İç %.1f°C".format(s.ambientTemperatureC), fontWeight = FontWeight.Black, fontSize = 16.sp)
                        SmallAdjustButton("+0.5") { vm.setAmbientTemperature(s.ambientTemperatureC + .5f) }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmallAdjustButton("Dış −1") { vm.setExternalTemperature(s.externalTemperatureC - 1f) }
                        Text("Dış %.0f°C".format(s.externalTemperatureC), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        SmallAdjustButton("Dış +1") { vm.setExternalTemperature(s.externalTemperatureC + 1f) }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmallAdjustButton("−50 m") { vm.setDemoAltitude((s.altitudeMeters ?: 36) - 50) }
                        Text("Rakım ${s.altitudeMeters ?: 36} m", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        SmallAdjustButton("+50 m") { vm.setDemoAltitude((s.altitudeMeters ?: 36) + 50) }
                    }
                }
            }
        }
    }
}

@Composable
private fun HeaterDial(ambient: Float, target: Int, on: Boolean, statusText: String, frostEnabled: Boolean) {
    val transition = rememberInfiniteTransition(label = "dial_live")
    val pulse by transition.animateFloat(
        initialValue = 0.72f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(950), RepeatMode.Reverse),
        label = "dial_pulse"
    )
    Canvas(Modifier.fillMaxSize()) {
        val stroke = size.minDimension * .045f
        val inset = stroke / 2f + 4f
        val ambientColor = temperatureBandColor(ambient)
        val accent = if (frostEnabled) Color(0xFF72D7FF) else ambientColor
        val cooling = !on && statusText.equals("SOĞUTMA", true)
        drawArc(
            color = Color(0xFF293139), startAngle = 135f, sweepAngle = 270f, useCenter = false,
            topLeft = Offset(inset, inset), size = androidx.compose.ui.geometry.Size(size.width - inset * 2, size.height - inset * 2),
            style = Stroke(stroke, cap = StrokeCap.Round)
        )
        if (on || cooling) {
            drawArc(
                color = accent.copy(alpha = if (cooling) .25f + pulse * .25f else .20f + pulse * .30f),
                startAngle = 135f, sweepAngle = 270f, useCenter = false,
                topLeft = Offset(inset - stroke * .45f, inset - stroke * .45f),
                size = androidx.compose.ui.geometry.Size(size.width - (inset - stroke * .45f) * 2, size.height - (inset - stroke * .45f) * 2),
                style = Stroke(stroke * 1.35f, cap = StrokeCap.Round)
            )
        }
        val ratio = ((ambient + 30f) / 65f).coerceIn(0f, 1f)
        drawArc(
            color = when {
                frostEnabled -> Color(0xFF72D7FF)
                cooling -> Color(0xFF70B9E8)
                else -> ambientColor
            }.copy(alpha = if (on) .82f + pulse * .18f else 1f),
            startAngle = 135f, sweepAngle = 270f * ratio, useCenter = false,
            topLeft = Offset(inset, inset), size = androidx.compose.ui.geometry.Size(size.width - inset * 2, size.height - inset * 2),
            style = Stroke(stroke, cap = StrokeCap.Round)
        )
        val center = Offset(size.width / 2f, size.height / 2f)
        val r = size.minDimension * .42f
        for (i in 0..10) {
            val a = Math.toRadians((135.0 + 270.0 * i / 10.0))
            val p1 = Offset(center.x + cos(a).toFloat() * (r - 6f), center.y + sin(a).toFloat() * (r - 6f))
            val p2 = Offset(center.x + cos(a).toFloat() * (r - 14f), center.y + sin(a).toFloat() * (r - 14f))
            drawLine(Color(0xFF56616A), p1, p2, strokeWidth = 2f, cap = StrokeCap.Round)
        }
    }
}

@Composable
private fun RoundAdjustButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier.size(54.dp).clip(CircleShape).background(Color(0xFF20262C)).border(1.dp, Color(0xFF343C42), CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, fontSize = 29.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun SmallAdjustButton(text: String, onClick: () -> Unit) {
    Surface(onClick = onClick, color = Color(0xFF20262C), shape = RoundedCornerShape(12.dp)) {
        Text(text, modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PowerFanCard(s: HeaterUiState, vm: HeaterViewModel, modifier: Modifier = Modifier) {
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    val cooling = !s.isHeaterOn && s.statusText.equals("SOĞUTMA", true)
    Card(modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF11161B)), shape = RoundedCornerShape(30.dp)) {
        Column(Modifier.padding(if (wide) 24.dp else 20.dp), verticalArrangement = Arrangement.spacedBy(if (wide) 19.dp else 17.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ISITICI DURUMU", color = Color(0xFFC3CFD8), fontSize = if (wide) 23.sp else 18.sp, fontWeight = FontWeight.Bold, letterSpacing = .7.sp)
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                        Text(
                            when {
                                s.isHeaterOn && s.activeController == "TURBO" -> "TURBO"
                                s.isHeaterOn -> "ÇALIŞIYOR"
                                cooling -> "SOĞUTMA"
                                else -> "KAPALI"
                            },
                            fontSize = if (wide) 31.sp else 28.sp,
                            fontWeight = FontWeight.Black,
                            color = when {
                                s.isHeaterOn -> Color(0xFF2F80ED)
                                cooling -> Color(0xFF70B9E8)
                                else -> Color(0xFFCAD1D6)
                            }
                        )
                        if (s.isHeaterOn) AnimatedFlame(Modifier.size(if (wide) 38.dp else 34.dp))
                        else if (cooling) AnimatedCoolingFan(Modifier.size(if (wide) 35.dp else 31.dp))
                    }
                    Spacer(Modifier.height(6.dp))
                    StatusPill(s.activeController.uppercase(), if (s.frostProtectionEnabled) Color(0xFF72D7FF) else if (s.activeController.equals("MANUEL", true)) Color(0xFF8E99A1) else Color(0xFF58A6FF))
                }
                Spacer(Modifier.width(16.dp))
                PowerButton(s.isHeaterOn, vm::togglePower)
            }
            HorizontalDivider(color = Color(0xFF252C31))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ÜFLEME", color = Color(0xFFC3CFD8), fontSize = if (wide) 23.sp else 18.sp, fontWeight = FontWeight.Bold, letterSpacing = .7.sp)
                    Text("${s.fanLevel} / 10", fontSize = if (wide) 33.sp else 28.sp, fontWeight = FontWeight.Black)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("GERÇEK FAN", color = Color(0xFFB0C0CD), fontSize = if (wide) 20.sp else 15.sp, fontWeight = FontWeight.Bold)
                    Text("${s.fanRpm} RPM", color = Color(0xFF58A6FF), fontWeight = FontWeight.Black, fontSize = if (wide) 27.sp else 20.sp)
                }
            }
            Slider(
                value = s.fanLevel.toFloat(),
                onValueChange = { vm.setFanLevel(it.roundToInt()) },
                valueRange = 1f..10f,
                steps = 8,
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFF2F80ED),
                    activeTrackColor = Color(0xFF2F80ED),
                    inactiveTrackColor = Color(0xFF30363B)
                )
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("1  SESSİZ", color = Color(0xFF9AA7B0), fontSize = if (wide) 18.sp else 14.sp, fontWeight = FontWeight.Bold)
                Text("10  GÜÇLÜ", color = Color(0xFF9AA7B0), fontSize = if (wide) 18.sp else 14.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun AnimatedFlame(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "heater_flame")
    val flameScaleY by transition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 560),
            repeatMode = RepeatMode.Reverse
        ),
        label = "flame_scale"
    )
    val sway by transition.animateFloat(
        initialValue = -2.2f,
        targetValue = 2.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 430),
            repeatMode = RepeatMode.Reverse
        ),
        label = "flame_sway"
    )
    val glow by transition.animateFloat(
        initialValue = 0.68f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 360),
            repeatMode = RepeatMode.Reverse
        ),
        label = "flame_glow"
    )

    Canvas(
        modifier.graphicsLayer {
            scaleY = flameScaleY
            translationX = sway
        }
    ) {
        val w = size.width
        val h = size.height
        val outer = Path().apply {
            moveTo(w * .50f, h * .03f)
            cubicTo(w * .66f, h * .25f, w * .86f, h * .43f, w * .78f, h * .68f)
            cubicTo(w * .72f, h * .88f, w * .58f, h * .98f, w * .43f, h * .95f)
            cubicTo(w * .20f, h * .90f, w * .10f, h * .70f, w * .20f, h * .51f)
            cubicTo(w * .28f, h * .36f, w * .40f, h * .28f, w * .40f, h * .12f)
            cubicTo(w * .40f, h * .08f, w * .44f, h * .04f, w * .50f, h * .03f)
            close()
        }
        val inner = Path().apply {
            moveTo(w * .52f, h * .38f)
            cubicTo(w * .64f, h * .51f, w * .67f, h * .62f, w * .61f, h * .76f)
            cubicTo(w * .56f, h * .87f, w * .43f, h * .88f, w * .36f, h * .78f)
            cubicTo(w * .27f, h * .64f, w * .36f, h * .51f, w * .52f, h * .38f)
            close()
        }
        drawPath(outer, Color(0xFFFF5A24).copy(alpha = glow))
        drawPath(inner, Color(0xFFFFB02E).copy(alpha = .92f))
    }
}

@Composable
private fun AnimatedCoolingFan(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "cooling_fan")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "fan_rotation"
    )
    Box(
        modifier.graphicsLayer { rotationZ = rotation },
        contentAlignment = Alignment.Center
    ) {
        // _20: Unicode sembol yerine uygulamanın gerçek fan çizimi kullanılır; çağıran alan fanı 2x ölçekler.
        Klon16LineIcon(
            "fan",
            Modifier.fillMaxSize(),
            Color(0xFF70B9E8),
            strokeWidth = 2.2f
        )
    }
}

@Composable
private fun PowerButton(on: Boolean, onClick: () -> Unit) {
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    val accent = if (on) Color(0xFFFF5A4A) else Color(0xFF58A6FF)
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(28.dp),
        color = Color(0xFF11161B),
        border = androidx.compose.foundation.BorderStroke(2.dp, accent.copy(alpha = .9f)),
        shadowElevation = 0.dp,
        modifier = Modifier.size(width = if (wide) 126.dp else 112.dp, height = if (wide) 82.dp else 72.dp)
    ) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                Modifier.size(if (wide) 40.dp else 34.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = .12f))
                    .border(1.dp, accent.copy(alpha = .5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("⏻", fontSize = if (wide) 24.sp else 20.sp, color = accent, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(10.dp))
            Column(horizontalAlignment = Alignment.Start) {
                Text(if (on) "DURDUR" else "BAŞLAT", fontSize = if (wide) 20.sp else 17.sp, fontWeight = FontWeight.Black, color = Color.White)
                Text(if (on) "Çalışmayı durdur" else "Isıtıcıyı başlat", fontSize = if (wide) 12.sp else 11.sp, color = Color(0xFF9AA7B0), maxLines = 1)
            }
        }
    }
}

@Composable
private fun QuickActions(s: HeaterUiState, vm: HeaterViewModel, wide: Boolean, onNavigate: (HeaterScreen) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("HIZLI KONTROL", color = Color(0xFFB7C4CD), fontSize = if (wide) 23.sp else 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp))
        if (wide) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                QuickAction("°C", "Termostat", s.thermostatEnabled, Modifier.weight(1f)) { onNavigate(HeaterScreen.THERMOSTAT) }
                QuickAction("◷", "Program", s.dailyProgramEnabled || s.weeklyProgramEnabled, Modifier.weight(1f)) { onNavigate(HeaterScreen.PROGRAMS) }
                QuickAction("☾", "Gece", s.nightModeEnabled, Modifier.weight(1f), vm::toggleNightMode)
                QuickAction("⚡", "Turbo", s.boostEnabled, Modifier.weight(1f), vm::toggleBoost)
                FrostQuickAction(s, vm, Modifier.weight(1.15f))
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                QuickAction("°C", "Termostat", s.thermostatEnabled, Modifier.weight(1f)) { onNavigate(HeaterScreen.THERMOSTAT) }
                QuickAction("◷", "Program", s.dailyProgramEnabled || s.weeklyProgramEnabled, Modifier.weight(1f)) { onNavigate(HeaterScreen.PROGRAMS) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                QuickAction("☾", "Gece", s.nightModeEnabled, Modifier.weight(1f), vm::toggleNightMode)
                QuickAction("⚡", "Turbo", s.boostEnabled, Modifier.weight(1f), vm::toggleBoost)
                FrostQuickAction(s, vm, Modifier.weight(1.15f))
            }
        }
    }
}

@Composable
private fun QuickAction(icon: String, label: String, active: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    Surface(
        onClick = onClick,
        modifier = modifier.height(if (wide) 108.dp else 96.dp),
        color = if (active) Color(0xFF102842) else Color(0xFF13191E),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (active) Color(0xFF2F80ED) else Color(0xFF262E34))
    ) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = if (wide) 34.sp else 30.sp, color = if (active) Color(0xFF58A6FF) else Color(0xFF8E999F))
            Spacer(Modifier.height(3.dp))
            Text(label, fontSize = if (wide) 21.sp else 17.sp, fontWeight = FontWeight.Bold, color = if (active) Color.White else Color(0xFFBBC2C7), maxLines = 1)
            if (active) {
                Spacer(Modifier.height(4.dp))
                Box(Modifier.width(26.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF2F80ED)))
            }
        }
    }
}

@Composable
private fun FrostQuickAction(s: HeaterUiState, vm: HeaterViewModel, modifier: Modifier = Modifier) {
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    val active = s.frostProtectionEnabled
    Surface(
        onClick = vm::toggleFrostProtection,
        modifier = modifier.height(if (wide) 108.dp else 96.dp),
        color = if (active) Color(0xFF0C3143) else Color(0xFF13191E),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(if (active) 2.dp else 1.dp, if (active) Color(0xFF72D7FF) else Color(0xFF262E34))
    ) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("❄", fontSize = if (wide) 35.sp else 30.sp, color = if (active) Color(0xFF8BE1FF) else Color(0xFF8E999F))
            Text(if (wide) "Don Koruma" else "Don", fontSize = if (wide) 20.sp else 16.sp, fontWeight = FontWeight.Black, color = if (active) Color.White else Color(0xFFBBC2C7), maxLines = 1)
            if (active) Text("AKTİF", color = Color(0xFF8BE1FF), fontSize = if (wide) 13.sp else 11.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun FrostActiveBanner(s: HeaterUiState) {
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    val heating = s.activeController == "DON KORUMA" && s.isHeaterOn
    Card(
        Modifier.fillMaxWidth().border(2.dp, Color(0xFF72D7FF).copy(alpha = .70f), RoundedCornerShape(18.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0C2635)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = if (wide) 13.dp else 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("❄", fontSize = if (wide) 30.sp else 25.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("DON KORUMA AKTİF", color = Color(0xFF8BE1FF), fontSize = if (wide) 20.sp else 17.sp, fontWeight = FontWeight.Black)
                Text(
                    "${s.frostStartC}°C ve altında başlat • ${s.frostStopC}°C'de kapat • Fan ${s.frostFanLevel}/10",
                    color = Color(0xFFB8DCEB), fontSize = if (wide) 16.sp else 13.sp, fontWeight = FontWeight.Bold
                )
            }
            StatusPill(if (heating) "ISITIYOR" else "HAZIR", Color(0xFF72D7FF))
        }
    }
}

@Composable
private fun EnvironmentMetrics(s: HeaterUiState) {
    val outside = if (s.externalTemperatureAvailable) "%.0f°C".format(s.externalTemperatureC) else "--"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FriendlyMetric("İÇ ORTAM", "%.1f°C".format(s.ambientTemperatureC), Modifier.weight(1f))
        FriendlyMetric("DIŞ ORTAM", outside, Modifier.weight(1f))
        FriendlyMetric("AKÜ", "%.1f V".format(s.batteryVoltage), Modifier.weight(1f))
        FriendlyMetric("RAKIM", "${s.altitudeMeters ?: 36} m", Modifier.weight(1f))
    }
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FriendlyMetric("POMPA", "%.1f Hz".format(s.pumpHz), Modifier.weight(1f))
        FriendlyMetric("ÇIKIŞ", "%.0f°C".format(s.outletTemperatureC), Modifier.weight(1f))
        FriendlyMetric("FAN", "${s.fanRpm}", Modifier.weight(1f))
        FriendlyMetric("HEDEF", "${s.targetTemperatureC}°C", Modifier.weight(1f))
    }
}

@Composable
private fun RuntimeSummary(s: HeaterUiState) {
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    fun formatSec(sec: Long): String {
        val m = sec / 60
        val h = m / 60
        val r = m % 60
        return if (h > 0) "${h} sa ${r} dk" else "${m} dk"
    }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF0F151A)), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f)) {
                Text("SON ÇALIŞMA", color = Color(0xFF9EABB5), fontSize = if (wide) 14.sp else 11.sp, fontWeight = FontWeight.Bold)
                Text(s.lastRunLabel, fontSize = if (wide) 20.sp else 16.sp, fontWeight = FontWeight.Black)
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                Text("BUGÜN TOPLAM", color = Color(0xFF9EABB5), fontSize = if (wide) 14.sp else 11.sp, fontWeight = FontWeight.Bold)
                Text(formatSec(s.totalRunSeconds), color = Color(0xFF58A6FF), fontSize = if (wide) 20.sp else 16.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun FavoriteActions(s: HeaterUiState, vm: HeaterViewModel, wide: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("FAVORİLER", color = Color(0xFFB7C4CD), fontSize = if (wide) 21.sp else 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FavoriteCard("☾", "Gece", "${s.nightStartC}→${s.nightStopC}°C", s.nightModeEnabled, Modifier.weight(1f), vm::favoriteNight)
            FavoriteCard("❄", "Don", "${s.frostStartC}→${s.frostStopC}°C", s.frostProtectionEnabled, Modifier.weight(1f), vm::favoriteFrost)
            FavoriteCard("⚡", "Turbo", "${s.boostDurationMinutes} dk", s.boostEnabled, Modifier.weight(1f), vm::favoriteTurbo)
        }
    }
}

@Composable
private fun FavoriteCard(icon: String, title: String, detail: String, active: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    Surface(
        onClick = onClick,
        modifier = modifier.height(if (wide) 78.dp else 70.dp),
        color = if (active) Color(0xFF102A45) else Color(0xFF12181D),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (active) Color(0xFF58A6FF) else Color(0xFF273038))
    ) {
        Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = if (wide) 26.sp else 22.sp)
            Spacer(Modifier.width(9.dp))
            Column {
                Text(title, fontSize = if (wide) 17.sp else 14.sp, fontWeight = FontWeight.Black, color = if (active) Color(0xFF7DB9FF) else Color.White)
                Text(detail, fontSize = if (wide) 12.sp else 10.sp, color = Color(0xFF8F9CA5), maxLines = 1)
            }
        }
    }
}

@Composable
private fun FriendlyMetrics(s: HeaterUiState) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FriendlyMetric("AKÜ", "%.1f V".format(s.batteryVoltage), Modifier.weight(1f))
        FriendlyMetric("POMPA", "%.1f Hz".format(s.pumpHz), Modifier.weight(1f))
        FriendlyMetric("ÇIKIŞ", "%.0f°C".format(s.outletTemperatureC), Modifier.weight(1f))
        FriendlyMetric("FAN", "${s.fanRpm}", Modifier.weight(1f))
    }
}

@Composable
private fun FriendlyMetric(title: String, value: String, modifier: Modifier) {
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1418)), shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.fillMaxWidth().padding(vertical = if (wide) 17.dp else 15.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = Color(0xFFB8C4CE), fontSize = if (wide) 20.sp else 15.sp, fontWeight = FontWeight.Bold)
            Text(value, fontSize = if (wide) 28.sp else 22.sp, fontWeight = FontWeight.Black, maxLines = 1)
        }
    }
}

@Composable
private fun ActiveAutomationCard(s: HeaterUiState) {
    val active = buildList {
        if (s.thermostatEnabled) add("Termostat")
        if (s.dailyProgramEnabled) add("Günlük")
        if (s.weeklyProgramEnabled) add("Haftalık")
        if (s.nightModeEnabled) add("Gece")
        if (s.frostProtectionEnabled) add("Don")
        if (s.boostEnabled) add("Turbo")
    }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1216)), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(if (active.isEmpty()) Color(0xFF555F66) else Color(0xFF2F80ED)))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("AKTİF OTOMASYON", color = Color(0xFF677179), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(if (active.isEmpty()) "Otomasyon kapalı" else active.joinToString(" • "), fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
            Text(s.activeController, color = Color(0xFF58A6FF), fontSize = 15.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun SettingsPage(s: HeaterUiState, ble: BleUiState, onNavigate: (HeaterScreen) -> Unit) {
    var testedBrands by rememberSaveable { mutableStateOf("1. Webesten") }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF11161B)), shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            SettingsRow("Bluetooth", ble.connectionState, if (ble.service181aFound) Color(0xFF58A6FF) else Color(0xFF8A949B))
            SettingsRow("Kontrol", s.activeController, Color(0xFF58A6FF))
        }
    }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF10161C)), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("TEST EDİLEN DİZEL ISITICI MARKALARI", fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color(0xFF58A6FF))
            Text("Bu alanı istediğiniz markalarla düzenleyebilirsiniz. İlk satır varsayılan olarak Webesten gelir.", color = Color(0xFF9FB0BD), fontSize = 13.sp)
            OutlinedTextField(
                value = testedBrands,
                onValueChange = { testedBrands = it },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF58A6FF),
                    unfocusedBorderColor = Color(0xFF2B343C),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = Color(0xFF13191E),
                    unfocusedContainerColor = Color(0xFF13191E)
                )
            )
        }
    }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF0F151A)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("ANA EKRAN KISAYOLLARI", color = Color(0xFF58A6FF), fontWeight = FontWeight.Black, fontSize = 15.sp)
            Text("Favori 1: Gece • Favori 2: Don Koruma • Favori 3: Turbo ${s.boostDurationMinutes} dk", color = Color(0xFFB2BEC7), fontSize = 13.sp)
            Text("Gece modu aktif olduğunda ekran parlaklığı otomatik olarak düşürülür.", color = Color(0xFF7F8D97), fontSize = 12.sp)
            Text("Dış sıcaklık harici sensör alanıdır; gerçek BLE sensörü doğrulanınca otomatik veri bağlanacaktır.", color = Color(0xFF7F8D97), fontSize = 12.sp)
        }
    }
    NavButton("ÖZEL MODLAR", "Gece modu, don koruma ve Turbo ayarları", Modifier.fillMaxWidth()) { onNavigate(HeaterScreen.MODES) }
    NavButton("BLUETOOTH / GERÇEK CİHAZ", "Tarama, bağlantı, 181A servisi ve canlı veri", Modifier.fillMaxWidth()) { onNavigate(HeaterScreen.BLUETOOTH) }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1B2A)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text("GERÇEK KONTROL", color = Color(0xFF58A6FF), fontWeight = FontWeight.Black, fontSize = 14.sp)
            Text("Bu sürümde BAŞLAT/DURDUR, hedef sıcaklık ve fan komutları gerçek ısıtıcıya gönderilir. Önce Bluetooth ekranından bağlanın ve canlı verinin geldiğini doğrulayın. İlk denemeyi cihazın başındayken yapın.", color = Color(0xFFA9BDD1), fontSize = 13.sp)
        }
    }
}

@Composable
private fun SettingsRow(title: String, value: String, valueColor: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color(0xFFA5B0BA), fontSize = 16.sp)
        Text(value, color = valueColor, fontSize = 16.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun PageHeader(title: String, subtitle: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(onClick = onBack, shape = CircleShape, color = Color(0xFF171D22), modifier = Modifier.size(42.dp)) {
            Box(contentAlignment = Alignment.Center) { Text("‹", fontSize = 30.sp, fontWeight = FontWeight.Bold) }
        }
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Black, fontSize = 28.sp)
            Text(subtitle, color = Color(0xFF9FB0BD), fontSize = 16.sp)
        }
    }
}

@Composable
private fun NavButton(title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = modifier.heightIn(min = 66.dp), color = Color(0xFF13191E), shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF242B31))) {
        Row(Modifier.fillMaxSize().padding(horizontal = 15.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Black, fontSize = 16.sp)
                Text(subtitle, color = Color(0xFF94A3AF), fontSize = 13.sp)
            }
            Text("›", color = Color(0xFF2F80ED), fontSize = 26.sp)
        }
    }
}

@Composable
private fun PageHint(text: String) {
    Text(text, color = muted, fontSize = 13.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
}

@Composable
private fun BadgeBox(text: String, color: Color) {
    Box(Modifier.background(color.copy(alpha=.12f), RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 6.dp)) {
        Text(text, color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    }
}

@Composable private fun BleControlCard(ble: BleUiState, vm: HeaterViewModel, requestPermission: () -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF101A22)), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("GERÇEK BLUETOOTH • _24", fontWeight = FontWeight.Black, fontSize = 17.sp)
                    Text("HeatGenie 181A servisi • kontrol komutları AÇIK", color = muted, fontSize = 10.sp)
                }
                BadgeBox(ble.connectionState, if (ble.service181aFound) Color(0xFF58A6FF) else Color(0xFF58A6FF))
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SmallStatus("İZİN", if (ble.permissionGranted) "OK" else "YOK", Modifier.weight(1f))
                SmallStatus("BLUETOOTH", if (ble.adapterEnabled) "AÇIK" else "KAPALI", Modifier.weight(1f))
                SmallStatus("181A", if (ble.service181aFound) "BULUNDU" else "—", Modifier.weight(1f))
                SmallStatus("MTU", ble.negotiatedMtu.toString(), Modifier.weight(1f))
            }

            if (!ble.permissionGranted) {
                Button(onClick = requestPermission, modifier = Modifier.fillMaxWidth()) { Text("BLUETOOTH İZNİ VER", fontWeight = FontWeight.Black) }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { if (ble.isScanning) vm.stopBleScan() else vm.startBleScan() }, modifier = Modifier.weight(1f)) {
                        Text(if (ble.isScanning) "TARAMAYI DURDUR" else "BLE TARA", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = vm::connectLastBleDevice, modifier = Modifier.weight(1f)) { Text("SON CİHAZ") }
                }
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("OTOMATİK YENİDEN BAĞLAN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("Bağlantı düşerse 5 saniyede bir, en fazla 5 kez dener.", color = muted, fontSize = 9.sp)
                }
                Switch(checked = ble.autoReconnect, onCheckedChange = vm::setBleAutoReconnect)
            }

            if (ble.devices.isNotEmpty()) {
                Text("BULUNAN CİHAZLAR", color = muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                ble.devices.take(8).forEach { d ->
                    Row(Modifier.fillMaxWidth().background(Color(0xFF151F27), RoundedCornerShape(12.dp)).padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text((if (d.likelyHeater) "★ " else "") + d.name, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (d.likelyHeater) Color(0xFF58A6FF) else Color.White)
                            Text("${d.address} • ${d.rssi} dBm", color = muted, fontSize = 9.sp)
                        }
                        OutlinedButton(onClick = { vm.connectBle(d.address) }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) { Text("BAĞLAN", fontSize = 10.sp) }
                    }
                }
            } else if (ble.permissionGranted) {
                Text("Henüz tarama yapılmadı veya yakınlarda BLE cihaz bulunmadı.", color = muted, fontSize = 10.sp)
            }

            if (ble.connectedAddress.isNotBlank()) {
                HorizontalDivider(color = Color(0xFF263640))
                Text("BAĞLI CİHAZ", color = Color(0xFF58A6FF), fontWeight = FontWeight.Black, fontSize = 11.sp)
                Text("${ble.connectedName.ifBlank { "İsimsiz cihaz" }} • ${ble.connectedAddress}", fontSize = 11.sp)
                Text("Yazma kanalı: ${if (ble.writeCharacteristicFound) "HAZIR" else "YOK"} • Bildirim kanalı: ${ble.notifyCharacteristicCount}", color = muted, fontSize = 10.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = vm::requestBleStatus, enabled = ble.writeCharacteristicFound, modifier = Modifier.weight(1f)) { Text("DURUM İSTE") }
                    OutlinedButton(onClick = vm::disconnectBle, modifier = Modifier.weight(1f)) { Text("BAĞLANTIYI KES") }
                }
            }

            ble.liveStatus?.let { live ->
                HorizontalDivider(color = Color(0xFF263640))
                Text("CANLI ISITICI VERİSİ", color = Color(0xFF58A6FF), fontWeight = FontWeight.Black, fontSize = 11.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SmallStatus("DURUM", live.machineStateText, Modifier.weight(1.5f))
                    SmallStatus("ORTAM", "%.1f °C".format(live.ambientC), Modifier.weight(1f))
                    SmallStatus("AKÜ", "%.1f V".format(live.batteryVoltage), Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SmallStatus("FAN", "${live.fanRpm} rpm", Modifier.weight(1f))
                    SmallStatus("POMPA", "%.1f Hz".format(live.pumpHz), Modifier.weight(1f))
                    SmallStatus("ÇIKIŞ", "%.1f °C".format(live.outletC), Modifier.weight(1f))
                    SmallStatus("HATA", "0x%04X".format(live.errorMask), Modifier.weight(1f))
                }
            }

            if (ble.lastRxHex.isNotBlank()) {
                Text("SON HAM RX PAKETİ", color = muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(ble.lastRxHex, fontSize = 9.sp, color = Color(0xFFB8E8E1))
            }

            Text(ble.message, color = Color(0xFF9FCBFF), fontSize = 10.sp)
            if (ble.lastTxHex.isNotBlank()) {
                Text("SON GÖNDERİLEN KOMUT (TX)", color = muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(ble.lastTxHex, fontSize = 9.sp, color = Color(0xFFFFD28A))
                if (ble.lastWriteResult.isNotBlank()) Text("Cihaz yanıtı: ${ble.lastWriteResult}", fontSize = 10.sp, color = Color(0xFFFFD28A))
            }
            if (ble.gattDump.isNotBlank()) {
                Text("181A KARAKTERİSTİKLERİ (R=oku W=yaz WNR=yanıtsız yaz N=bildirim I=indikasyon)", color = muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(ble.gattDump, fontSize = 9.sp, color = Color(0xFFB8E8E1))
            }
        }
    }
}

@Composable private fun SmallStatus(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Color(0xFF16232B), RoundedCornerShape(10.dp)).padding(horizontal = 5.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(value, fontSize = 11.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, maxLines = 2)
    }
}

@Composable private fun DemoClockCard(s: HeaterUiState, vm: HeaterViewModel) {
    if (!s.isDemoMode) return
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0E2020)), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("DEMO ZAMANI", color = Color(0xFF58A6FF), fontWeight = FontWeight.Black)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column { Text(dayName(s.demoDayOfWeek), fontSize = 18.sp, fontWeight = FontWeight.Bold); Text(formatClock(s.demoClockMinutes), fontSize = 30.sp, fontWeight = FontWeight.Black) }
                Column(horizontalAlignment = Alignment.End) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { OutlinedButton({ vm.shiftDemoDay(-1) }) { Text("← GÜN") }; OutlinedButton({ vm.shiftDemoDay(1) }) { Text("GÜN →") } }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { OutlinedButton({ vm.shiftDemoClock(-15) }) { Text("−15 dk") }; OutlinedButton({ vm.shiftDemoClock(15) }) { Text("+15 dk") } }
                }
            }
        }
    }
}

@Composable private fun ThermostatCard(s: HeaterUiState, vm: HeaterViewModel) {
    SectionCard("OTOMATİK TERMOSTAT", s.thermostatStatusText, s.thermostatEnabled, vm::toggleThermostat) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ValueBox("BAŞLAT EŞİĞİ", "${s.thermostatStartC} °C", { vm.setThermostatStartTemperature(s.thermostatStartC - 1) }, { vm.setThermostatStartTemperature(s.thermostatStartC + 1) }, Modifier.weight(1f))
            ValueBox("DURDUR EŞİĞİ", "${s.thermostatStopC} °C", { vm.setThermostatStopTemperature(s.thermostatStopC - 1) }, { vm.setThermostatStopTemperature(s.thermostatStopC + 1) }, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ValueBox("MİN. ÇALIŞMA", "${s.minimumRunMinutes} dk", { vm.setMinimumRunMinutes(s.minimumRunMinutes - 1) }, { vm.setMinimumRunMinutes(s.minimumRunMinutes + 1) }, Modifier.weight(1f))
            ValueBox("MİN. BEKLEME", "${s.minimumRestMinutes} dk", { vm.setMinimumRestMinutes(s.minimumRestMinutes - 1) }, { vm.setMinimumRestMinutes(s.minimumRestMinutes + 1) }, Modifier.weight(1f))
        }
    }
}

@Composable private fun DailyCard(s: HeaterUiState, vm: HeaterViewModel) {
    SectionCard("GÜNLÜK PROGRAM", s.dailyProgramStatusText, s.dailyProgramEnabled, vm::toggleDailyProgram) {
        ScheduleControls(s.dailyProgramStartMinutes, s.dailyProgramEndMinutes, s.dailyProgramStartC, s.dailyProgramStopC, s.dailyProgramFanLevel,
            { vm.shiftDailyProgramStart(-15) }, { vm.shiftDailyProgramStart(15) }, { vm.shiftDailyProgramEnd(-15) }, { vm.shiftDailyProgramEnd(15) },
            { vm.setDailyProgramStartTemperature(s.dailyProgramStartC - 1) }, { vm.setDailyProgramStartTemperature(s.dailyProgramStartC + 1) },
            { vm.setDailyProgramStopTemperature(s.dailyProgramStopC - 1) }, { vm.setDailyProgramStopTemperature(s.dailyProgramStopC + 1) }, vm::setDailyProgramFanLevel)
    }
}

@Composable private fun WeeklyCard(s: HeaterUiState, vm: HeaterViewModel) {
    SectionCard("HAFTALIK PROGRAM", s.weeklyStatusText, s.weeklyProgramEnabled, vm::toggleWeeklyProgram) {
        Text("ÇALIŞACAĞI GÜNLER", color = muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            (1..7).forEach { d ->
                val selected = d in s.weeklyDays
                Button(onClick = { vm.toggleWeeklyDay(d) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 2.dp, vertical = 7.dp), colors = ButtonDefaults.buttonColors(containerColor = if (selected) Color(0xFF1F4E85) else Color(0xFF262D32))) { Text(dayShort(d), fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            }
        }
        ScheduleControls(s.weeklyStartMinutes, s.weeklyEndMinutes, s.weeklyStartC, s.weeklyStopC, s.weeklyFanLevel,
            { vm.shiftWeeklyStart(-15) }, { vm.shiftWeeklyStart(15) }, { vm.shiftWeeklyEnd(-15) }, { vm.shiftWeeklyEnd(15) },
            { vm.setWeeklyStartC(s.weeklyStartC - 1) }, { vm.setWeeklyStartC(s.weeklyStartC + 1) },
            { vm.setWeeklyStopC(s.weeklyStopC - 1) }, { vm.setWeeklyStopC(s.weeklyStopC + 1) }, vm::setWeeklyFan)
    }
}

@Composable private fun NightCard(s: HeaterUiState, vm: HeaterViewModel) {
    SectionCard("GECE MODU", s.nightStatusText, s.nightModeEnabled, vm::toggleNightMode) {
        Text("Sessiz kullanım için varsayılan fan düşüktür. Saat aralığı gece yarısını geçebilir.", color = muted, fontSize = 10.sp)
        ScheduleControls(s.nightStartMinutes, s.nightEndMinutes, s.nightStartC, s.nightStopC, s.nightFanLevel,
            { vm.shiftNightStart(-15) }, { vm.shiftNightStart(15) }, { vm.shiftNightEnd(-15) }, { vm.shiftNightEnd(15) },
            { vm.setNightStartC(s.nightStartC - 1) }, { vm.setNightStartC(s.nightStartC + 1) },
            { vm.setNightStopC(s.nightStopC - 1) }, { vm.setNightStopC(s.nightStopC + 1) }, vm::setNightFan)
    }
}

@Composable private fun FrostCard(s: HeaterUiState, vm: HeaterViewModel) {
    val active = s.frostProtectionEnabled
    Card(
        Modifier.fillMaxWidth().then(if (active) Modifier.border(2.dp, Color(0xFF72D7FF), RoundedCornerShape(20.dp)) else Modifier),
        colors = CardDefaults.cardColors(containerColor = if (active) Color(0xFF0C2635) else Color(0xFF101A1D)),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(if (active) "❄  DON KORUMA AKTİF" else "❄  DON KORUMA", fontWeight = FontWeight.Black, fontSize = 19.sp, color = if (active) Color(0xFF8BE1FF) else Color.White)
                    Text(if (active) s.frostStatusText else "PASİF", color = if (active) Color(0xFFB8DCEB) else muted, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Button(onClick = vm::toggleFrostProtection, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 4.dp), colors = ButtonDefaults.buttonColors(containerColor = if (active) Color(0xFF8B2B2B) else Color(0xFF1F4E85))) { Text(if (active) "PASİF YAP" else "AKTİF ET", fontWeight = FontWeight.Black, maxLines = 1) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ValueBox("BAŞLAT EŞİĞİ", "${s.frostStartC} °C", { vm.setFrostStartC(s.frostStartC - 1) }, { vm.setFrostStartC(s.frostStartC + 1) }, Modifier.weight(1f))
                ValueBox("DURDUR EŞİĞİ", "${s.frostStopC} °C", { vm.setFrostStopC(s.frostStopC - 1) }, { vm.setFrostStopC(s.frostStopC + 1) }, Modifier.weight(1f))
            }
            Text("DON KORUMA FAN ${s.frostFanLevel}/10", fontWeight = FontWeight.Bold, color = if (active) Color(0xFF8BE1FF) else Color.White)
            Slider(s.frostFanLevel.toFloat(), onValueChange = { vm.setFrostFan(it.roundToInt()) }, valueRange = 1f..10f, steps = 8,
                colors = SliderDefaults.colors(thumbColor = Color(0xFF72D7FF), activeTrackColor = Color(0xFF72D7FF), inactiveTrackColor = Color(0xFF30363B)))
        }
    }
}

@Composable private fun BoostCard(s: HeaterUiState, vm: HeaterViewModel) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF101A26)), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("⚡ SÜRELİ TURBO", fontWeight = FontWeight.Black, fontSize = 19.sp, color = if (s.boostEnabled) Color(0xFF58A6FF) else Color.White)
                    Text(if (s.boostEnabled) "AKTİF • KALAN ${ceil(s.boostRemainingSeconds / 60.0).toInt()} dk • FAN 10" else "PASİF", color = if (s.boostEnabled) Color(0xFF82BEFF) else muted, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Button(vm::toggleBoost, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 4.dp), colors = ButtonDefaults.buttonColors(containerColor = if (s.boostEnabled) Color(0xFF8B2B2B) else Color(0xFF195FAF))) { Text(if (s.boostEnabled) "TURBOYU DURDUR" else "TURBOYU BAŞLAT", fontWeight = FontWeight.Black, maxLines = 1) }
            }
            ValueBox("TURBO SÜRESİ", "${s.boostDurationMinutes} dk", { vm.setBoostDuration(s.boostDurationMinutes - 5) }, { vm.setBoostDuration(s.boostDurationMinutes + 5) })
            if (s.isDemoMode && s.boostEnabled) {
                OutlinedButton(onClick = { vm.demoAdvanceBoost(5) }, modifier = Modifier.fillMaxWidth()) { Text("DEMO • TURBO'YU 5 DK İLERLET") }
                Text("Demo modunda ayrıca her 1 gerçek saniye, 1 Turbo dakikası gibi ilerler.", color = muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable private fun ScheduleControls(start: Int, end: Int, low: Int, high: Int, fan: Int,
    startDown: () -> Unit, startUp: () -> Unit, endDown: () -> Unit, endUp: () -> Unit,
    lowDown: () -> Unit, lowUp: () -> Unit, highDown: () -> Unit, highUp: () -> Unit, onFan: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ValueBox("BAŞLANGIÇ", formatClock(start), startDown, startUp, Modifier.weight(1f))
        ValueBox("BİTİŞ", formatClock(end), endDown, endUp, Modifier.weight(1f))
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ValueBox("BAŞLAT EŞİĞİ", "$low °C", lowDown, lowUp, Modifier.weight(1f))
        ValueBox("DURDUR EŞİĞİ", "$high °C", highDown, highUp, Modifier.weight(1f))
    }
    Text("PROGRAM ÜFLEME / FAN $fan/10", fontWeight = FontWeight.Bold)
    Slider(fan.toFloat(), onValueChange = { onFan(it.roundToInt()) }, valueRange = 1f..10f, steps = 8)
}

@Composable private fun SectionCard(title: String, status: String, enabled: Boolean, onToggle: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF101A1D)), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(title, fontWeight = FontWeight.Black, fontSize = 17.sp, maxLines = 1)
                    Text(
                        if (enabled) status else "PASİF",
                        color = if (enabled) Color(0xFF58A6FF) else muted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2
                    )
                }
                Button(
                    onClick = onToggle,
                    contentPadding = PaddingValues(horizontal = 9.dp, vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (enabled) Color(0xFF8B2B2B) else Color(0xFF1F4E85))
                ) {
                    Text(if (enabled) "PASİF YAP" else "AKTİF ET", fontWeight = FontWeight.Black, maxLines = 1)
                }
            }
            content()
        }
    }
}

@Composable private fun ValueBox(title: String, value: String, down: () -> Unit, up: () -> Unit, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF11161B)), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 7.dp, vertical = 5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color(0xFF58A6FF))
            StepperButtons(down, up, "−", "+")
        }
    }
}

@Composable private fun StepperButtons(down: () -> Unit, up: () -> Unit, downText: String, upText: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        OutlinedButton(onClick = down, modifier = Modifier.size(44.dp), contentPadding = PaddingValues(0.dp)) { Text(downText, fontSize = 18.sp) }
        OutlinedButton(onClick = up, modifier = Modifier.size(44.dp), contentPadding = PaddingValues(0.dp)) { Text(upText, fontSize = 18.sp) }
    }
}

@Composable private fun Metrics(s: HeaterUiState) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Metric("AKÜ", "%.2f V".format(s.batteryVoltage), Modifier.weight(1f)); Metric("FAN", "${s.fanRpm}", Modifier.weight(1f)); Metric("POMPA", "%.1f Hz".format(s.pumpHz), Modifier.weight(1f)); Metric("ÇIKIŞ", "%.0f °C".format(s.outletTemperatureC), Modifier.weight(1f))
    }
}

@Composable private fun Metric(title: String, value: String, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF11161B)), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(title, color = muted, fontSize = 9.sp, fontWeight = FontWeight.Bold); Text(value, fontSize = 15.sp, fontWeight = FontWeight.Black) }
    }
}

@Composable private fun StatisticsCard(s: HeaterUiState, vm: HeaterViewModel) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF101A1D)), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("ÇALIŞMA İSTATİSTİĞİ", fontWeight = FontWeight.Black, fontSize = 17.sp)
                    Text("Bugünkü oturum", color = muted, fontSize = 10.sp)
                }
                OutlinedButton(onClick = vm::resetStatistics) { Text("SIFIRLA") }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox("TOPLAM ÇALIŞMA", formatDuration(s.totalRunSeconds), Modifier.weight(1f))
                StatBox("BAŞLATMA", "${s.startCount} kez", Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox("TAHMİNİ YAKIT", "%.3f L".format(s.estimatedFuelLiters), Modifier.weight(1f))
                StatBox("MİN / MAKS", "%.1f° / %.1f°".format(s.minRecordedTemperatureC, s.maxRecordedTemperatureC), Modifier.weight(1f))
            }
            Text("Yakıt değeri şimdilik fan seviyesine göre geçici tahmindir. Gerçek ısıtıcı testinde pompa verisiyle kalibre edeceğiz.", color = muted, fontSize = 10.sp)
        }
    }
}

@Composable private fun StatBox(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF11161B)), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color(0xFF58A6FF))
        }
    }
}

@Composable private fun TemperatureHistoryCard(s: HeaterUiState) {
    val samples = s.historySamples.takeLast(60)
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF0F171B)), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("SICAKLIK GRAFİĞİ", fontWeight = FontWeight.Black, fontSize = 17.sp)
            Text("Son 60 kayıt", color = muted, fontSize = 10.sp)
            if (samples.size < 2) {
                Box(Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) { Text("Grafik için birkaç saniye bekleyin", color = muted) }
            } else {
                val minT = samples.minOf { it.ambientC }
                val maxT = samples.maxOf { it.ambientC }
                Text("%.1f °C  –  %.1f °C".format(minT, maxT), color = Color(0xFF58A6FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Canvas(Modifier.fillMaxWidth().height(170.dp)) {
                    val range = (maxT - minT).coerceAtLeast(1f)
                    val dx = if (samples.size <= 1) size.width else size.width / (samples.size - 1)
                    // yatay referans çizgileri
                    repeat(4) { i ->
                        val y = size.height * i / 3f
                        drawLine(Color(0xFF273137), start = androidx.compose.ui.geometry.Offset(0f, y), end = androidx.compose.ui.geometry.Offset(size.width, y), strokeWidth = 1f)
                    }
                    samples.forEachIndexed { i, sample ->
                        if (sample.heaterOn) {
                            val left = i * dx
                            drawRect(Color(0x5539D9C5), topLeft = androidx.compose.ui.geometry.Offset(left, size.height - 12f), size = androidx.compose.ui.geometry.Size(dx.coerceAtLeast(2f), 12f))
                        }
                    }
                    for (i in 1 until samples.size) {
                        val a = samples[i - 1]
                        val b = samples[i]
                        val x1 = (i - 1) * dx
                        val x2 = i * dx
                        val y1 = size.height - 18f - ((a.ambientC - minT) / range) * (size.height - 32f)
                        val y2 = size.height - 18f - ((b.ambientC - minT) / range) * (size.height - 32f)
                        drawLine(Color(0xFF58A6FF), start = androidx.compose.ui.geometry.Offset(x1, y1), end = androidx.compose.ui.geometry.Offset(x2, y2), strokeWidth = 5f)
                    }
                }
            }
        }
    }
}

@Composable private fun EventHistoryCard(s: HeaterUiState, vm: HeaterViewModel) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF10151A)), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("ÇALIŞMA / HATA GEÇMİŞİ", fontWeight = FontWeight.Black, fontSize = 17.sp)
                    Text("Son açma, kapatma ve hata olayları", color = muted, fontSize = 10.sp)
                }
                if (s.isDemoMode) OutlinedButton(onClick = vm::addDemoError) { Text("DEMO HATA") }
            }
            if (s.eventLog.isEmpty()) {
                Text("Henüz kayıt yok. Isıtıcıyı çalıştırıp kapatarak kayıt oluşturabilirsiniz.", color = muted, fontSize = 11.sp)
            } else {
                s.eventLog.take(8).forEach { event ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(event.timeLabel, color = Color(0xFF58A6FF), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(62.dp))
                        Column(Modifier.weight(1f)) {
                            Text(event.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (event.title.contains("HATA")) Color(0xFFFF7777) else Color.White)
                            Text(event.detail, color = muted, fontSize = 10.sp)
                        }
                    }
                    HorizontalDivider(color = Color(0xFF252C31))
                }
            }
            if (s.errorLog.isNotEmpty()) Text("Hata kaydı: ${s.errorLog.size}", color = Color(0xFFFF7777), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private fun formatDuration(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    return if (h > 0) "${h} sa ${m} dk" else "${m} dk"
}

@Composable private fun PriorityCard() {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1317)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp)) {
            Text("KONTROL ÖNCELİĞİ", color = muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text("MANUEL  >  TURBO  >  DON KORUMA  >  GECE  >  HAFTALIK  >  GÜNLÜK  >  TERMOSTAT", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("Aynı anda birden fazla özellik açık olsa bile tek kontrolcü komut verir.", color = muted, fontSize = 10.sp)
        }
    }
}

@Composable private fun AppCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(18.dp), content = content)
    }
}

private val muted = Color(0xFF89969F)
private fun formatClock(m: Int) = "%02d:%02d".format(m / 60, m % 60)
private fun dayShort(d: Int) = listOf("Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz")[(d - 1).coerceIn(0, 6)]
private fun dayName(d: Int) = listOf("Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar")[(d - 1).coerceIn(0, 6)]
