package com.aldanmaz.webestenheater.model

data class TemperatureSample(
    val index: Int,
    val ambientC: Float,
    val heaterOn: Boolean
)

data class HeaterEvent(
    val timeLabel: String,
    val title: String,
    val detail: String
)

data class HeaterUiState(
    val isDemoMode: Boolean = false,
    val isHeaterOn: Boolean = false,
    val ambientTemperatureC: Float = 22.0f,
    val targetTemperatureC: Int = 25,
    val fanLevel: Int = 5,
    val fanRpm: Int = 0,
    val batteryVoltage: Float = 12.7f,
    val pumpHz: Float = 0f,
    val heaterShellC: Float = 22f,
    val outletTemperatureC: Float = 22f,
    val statusText: String = "BEKLİYOR",
    val coolingStartedAtMs: Long = 0L,
    val activeController: String = "YOK",

    // Ana ekran çevresel bilgiler (_14)
    val altitudeMeters: Int? = null,
    val gpsAltitudeMeters: Int? = null,
    val heaterAltitudeMeters: Int? = null,
    val externalTemperatureC: Float = 14.0f,
    val externalTemperatureAvailable: Boolean = false,
    val lastRunSeconds: Long = 0L,
    val lastRunLabel: String = "Henüz çalışma yok",

    // Termostat
    val thermostatEnabled: Boolean = false,
    val thermostatStartC: Int = 20,
    val thermostatStopC: Int = 25,
    val minimumRunMinutes: Int = 0,
    val minimumRestMinutes: Int = 0,
    val thermostatStatusText: String = "PASİF",

    // Günlük program
    val dailyProgramEnabled: Boolean = false,
    val dailyProgramStartMinutes: Int = 3 * 60,
    val dailyProgramEndMinutes: Int = 3 * 60 + 45,
    val dailyProgramStartC: Int = 20,
    val dailyProgramStopC: Int = 24,
    val dailyProgramFanLevel: Int = 3,
    val dailyProgramStatusText: String = "PASİF",

    // Haftalık program
    val weeklyProgramEnabled: Boolean = false,
    val weeklyDays: Set<Int> = setOf(1, 2, 3, 4, 5),
    val weeklyStartMinutes: Int = 6 * 60 + 30,
    val weeklyEndMinutes: Int = 7 * 60 + 30,
    val weeklyStartC: Int = 20,
    val weeklyStopC: Int = 24,
    val weeklyFanLevel: Int = 4,
    val weeklyStatusText: String = "PASİF",

    // Gece modu
    val nightModeEnabled: Boolean = false,
    val nightStartMinutes: Int = 23 * 60,
    val nightEndMinutes: Int = 7 * 60,
    val nightStartC: Int = 18,
    val nightStopC: Int = 21,
    val nightFanLevel: Int = 2,
    val nightStatusText: String = "PASİF",

    // Don koruma
    val frostProtectionEnabled: Boolean = false,
    val frostStartC: Int = 4,
    val frostStopC: Int = 8,
    val frostFanLevel: Int = 3,
    val frostStatusText: String = "PASİF",

    // Süreli boost
    val boostEnabled: Boolean = false,
    val boostDurationMinutes: Int = 20,
    val boostRemainingSeconds: Int = 0,

    // Demo zamanı
    val demoClockMinutes: Int = 2 * 60 + 45,
    val demoDayOfWeek: Int = 1,

    // İstatistik / geçmiş (_05)
    val totalRunSeconds: Long = 0L,
    val startCount: Int = 0,
    val estimatedFuelLiters: Float = 0f,
    val minRecordedTemperatureC: Float = 22f,
    val maxRecordedTemperatureC: Float = 22f,
    val historySamples: List<TemperatureSample> = emptyList(),
    val eventLog: List<HeaterEvent> = emptyList(),
    val errorLog: List<HeaterEvent> = emptyList(),
    val historySampleIndex: Int = 0,

    // Fan (ventilation) mode, low-voltage alert
    val isFanMode: Boolean = false,
    val fanModeMessage: String = "",
    val lowVoltageBeepEnabled: Boolean = true,
    val stopAtTarget: Boolean = true,
    /** Thermostat starts at (target - startOffsetC); it stops at the target. */
    val startOffsetC: Int = 4,
    val backgroundRun: Boolean = true
)
