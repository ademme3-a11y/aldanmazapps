package com.aldanmaz.webestenheater.weather

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.tan

data class SatelliteImage(
    val bitmap: Bitmap,
    val dateLabel: String,
    val key: String,
    /** Approximate ground width of the picture in kilometres. */
    val spanKm: Int
)

/**
 * True-colour satellite picture (NASA GIBS, VIIRS Suomi NPP corrected reflectance, no API key) centred on the
 * given position. Real clouds, sea and relief as captured by the satellite, newest day that has data.
 */
object SatelliteMap {
    private const val ZOOM = 7
    private const val TILE = 256
    private const val SIZE = 512
    private const val LAYER = "VIIRS_SNPP_CorrectedReflectance_TrueColor"

    private fun worldTile(lat: Double, lon: Double): Pair<Double, Double> {
        val n = 2.0.pow(ZOOM)
        val x = (lon + 180.0) / 360.0 * n
        val latRad = Math.toRadians(lat.coerceIn(-85.0, 85.0))
        val y = (1.0 - ln(tan(latRad) + 1.0 / cos(latRad)) / PI) / 2.0 * n
        return x to y
    }

    private fun fetchTile(date: LocalDate, z: Int, x: Int, y: Int): Bitmap? {
        val url = "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/$LAYER/default/$date/GoogleMapsCompatible_Level9/$z/$y/$x.jpg"
        val c = URL(url).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", "KlonDizelIsitici/1.0")
            if (c.responseCode != 200) null else c.inputStream.use { BitmapFactory.decodeStream(it) }
        } catch (_: Exception) {
            null
        } finally {
            c.disconnect()
        }
    }

    fun keyFor(lat: Double, lon: Double): String {
        val (x, y) = worldTile(lat, lon)
        return "${floor(x * 2).toInt()}_${floor(y * 2).toInt()}_${LocalDate.now()}"
    }

    /** Blocking: run off the main thread. Tries today, then up to two earlier days. Returns null when no tile loads. */
    fun load(lat: Double, lon: Double): SatelliteImage? {
        val (wx, wy) = worldTile(lat, lon)
        val tx = floor(wx).toInt()
        val ty = floor(wy).toInt()
        val fx = (wx - tx).toFloat()
        val fy = (wy - ty).toFloat()
        val n = 1 shl ZOOM
        for (back in 0..2) {
            val date = LocalDate.now().minusDays(back.toLong())
            val center = fetchTile(date, ZOOM, tx, ty) ?: continue
            val out = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            canvas.drawColor(android.graphics.Color.rgb(8, 22, 40))
            for (dy in -1..1) {
                for (dx in -1..1) {
                    val x = (tx + dx).mod(n)
                    val y = ty + dy
                    if (y < 0 || y >= n) continue
                    val bmp = if (dx == 0 && dy == 0) center else fetchTile(date, ZOOM, x, y) ?: continue
                    val left = SIZE / 2f - fx * TILE + dx * TILE
                    val top = SIZE / 2f - fy * TILE + dy * TILE
                    canvas.drawBitmap(bmp, left, top, null)
                }
            }
            val km = (SIZE / TILE.toFloat() * 40075.0 * cos(Math.toRadians(lat)) / n).toInt()
            return SatelliteImage(out, date.toString(), keyFor(lat, lon), km)
        }
        return null
    }
}
