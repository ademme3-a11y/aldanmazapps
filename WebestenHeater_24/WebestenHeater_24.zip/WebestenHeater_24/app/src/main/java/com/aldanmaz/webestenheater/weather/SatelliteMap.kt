package com.aldanmaz.webestenheater.weather

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.tan
import kotlin.math.roundToInt

data class SatelliteImage(
    val bitmap: Bitmap,
    val dateLabel: String,
    val key: String,
    /** Approximate ground width of the picture in kilometres. */
    val spanKm: Int
)

/**
 * True-colour satellite picture (NASA GIBS, VIIRS Suomi NPP corrected reflectance, no API key) centred on the
 * given position. Real clouds, sea and relief as captured by the satellite, newest day that has data.
 */
object SatelliteMap {
    private const val ZOOM = 7
    private const val TILE = 256
    private const val SIZE = 512
    private val LAYERS = listOf("VIIRS_SNPP_CorrectedReflectance_TrueColor", "MODIS_Terra_CorrectedReflectance_TrueColor")

    /** Last failure, shown on the map page so a failing source can be diagnosed on the phone. */
    @Volatile var lastError: String = ""

    fun spanKm(lat: Double): Int = (SIZE / TILE.toFloat() * 40075.0 * cos(Math.toRadians(lat)) / (1 shl ZOOM)).toInt()

    private fun worldTile(lat: Double, lon: Double): Pair<Double, Double> {
        val n = 2.0.pow(ZOOM)
        val x = (lon + 180.0) / 360.0 * n
        val latRad = Math.toRadians(lat.coerceIn(-85.0, 85.0))
        val y = (1.0 - ln(tan(latRad) + 1.0 / cos(latRad)) / PI) / 2.0 * n
        return x to y
    }

    private fun fetchTile(layer: String, date: LocalDate, z: Int, x: Int, y: Int): Bitmap? {
        val url = "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/$layer/default/$date/GoogleMapsCompatible_Level9/$z/$y/$x.jpg"
        val c = URL(url).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", "KlonDizelIsitici/1.0")
            val code = c.responseCode
            if (code != 200) { lastError = "HTTP $code ($layer, $date)"; null }
            else c.inputStream.use { BitmapFactory.decodeStream(it) } ?: run { lastError = "Görüntü çözülemedi ($layer)"; null }
        } catch (e: Exception) {
            lastError = e.javaClass.simpleName + ": " + (e.message ?: "")
            null
        } finally {
            c.disconnect()
        }
    }

    fun keyFor(lat: Double, lon: Double): String {
        val (x, y) = worldTile(lat, lon)
        return "${floor(x * 2).toInt()}_${floor(y * 2).toInt()}_${LocalDate.now()}"
    }

    /** Blocking: run off the main thread. Tries today, then up to two earlier days. Returns null when no tile loads. */
    fun load(lat: Double, lon: Double): SatelliteImage? {
        val (wx, wy) = worldTile(lat, lon)
        val tx = floor(wx).toInt()
        val ty = floor(wy).toInt()
        val fx = (wx - tx).toFloat()
        val fy = (wy - ty).toFloat()
        val n = 1 shl ZOOM
        for (layer in LAYERS) for (back in 0..2) {
            val date = LocalDate.now().minusDays(back.toLong())
            val center = fetchTile(layer, date, ZOOM, tx, ty) ?: continue
            val out = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            canvas.drawColor(android.graphics.Color.rgb(8, 22, 40))
            for (dy in -1..1) {
                for (dx in -1..1) {
                    val x = (tx + dx).mod(n)
                    val y = ty + dy
                    if (y < 0 || y >= n) continue
                    val bmp = if (dx == 0 && dy == 0) center else fetchTile(layer, date, ZOOM, x, y) ?: continue
                    val left = SIZE / 2f - fx * TILE + dx * TILE
                    val top = SIZE / 2f - fy * TILE + dy * TILE
                    canvas.drawBitmap(bmp, left, top, null)
                }
            }
            return SatelliteImage(out, date.toString() + if (layer.startsWith("MODIS")) " (MODIS)" else "", keyFor(lat, lon), spanKm(lat))
        }
        return null
    }


    // ------------------------------------------------------------------ reference lines (coast, borders, names)

    @Volatile var referenceError: String = ""

    private val MATRIX_SETS = listOf("GoogleMapsCompatible_Level13", "GoogleMapsCompatible_Level9")

    private fun fetchRef(layer: String, matrixSet: String, z: Int, x: Int, y: Int): Bitmap? {
        val c = URL("https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/$layer/default/$matrixSet/$z/$y/$x.png").openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", "KlonDizelIsitici/1.0")
            val code = c.responseCode
            if (code != 200) { referenceError = "HTTP $code ($layer, $matrixSet)"; null }
            else c.inputStream.use { BitmapFactory.decodeStream(it) }
        } catch (e: Exception) {
            referenceError = e.javaClass.simpleName + ": " + (e.message ?: "")
            null
        } finally {
            c.disconnect()
        }
    }

    /** Transparent picture with coastlines, country/state borders and place names, aligned with the satellite picture. */
    fun loadReference(lat: Double, lon: Double): Bitmap? {
        val (wx, wy) = worldTile(lat, lon)
        val tx = floor(wx).toInt()
        val ty = floor(wy).toInt()
        val fx = (wx - tx).toFloat()
        val fy = (wy - ty).toFloat()
        val n = 1 shl ZOOM
        val out = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        var any = false
        for (layer in listOf("Coastlines_15m", "Reference_Features_15m", "Reference_Labels_15m")) {
            val set = MATRIX_SETS.firstOrNull { fetchRef(layer, it, ZOOM, tx.mod(n), ty) != null } ?: continue
            for (dy in -1..1) for (dx in -1..1) {
                val y = ty + dy
                if (y < 0 || y >= n) continue
                val bmp = fetchRef(layer, set, ZOOM, (tx + dx).mod(n), y) ?: continue
                any = true
                canvas.drawBitmap(bmp, SIZE / 2f - fx * TILE + dx * TILE, SIZE / 2f - fy * TILE + dy * TILE, null)
            }
        }
        return if (any) out else null
    }

    // ------------------------------------------------------------------ live layers

    data class LiveOverlay(
        val cloud: Bitmap?,
        val cloudLabel: String,
        val radar: Bitmap?,
        val radarLabel: String,
        val error: String
    )

    /**
     * Live layers drawn on top of the picture:
     *  - cloud cover: Open-Meteo current cloud_cover on a 7x7 grid around the position (weather-model analysis, hourly);
     *  - rain radar: RainViewer composite (10-minute frames, where radar coverage exists).
     */
    fun loadLive(lat: Double, lon: Double): LiveOverlay {
        var err = ""
        var cloudBmp: Bitmap? = null
        var cloudLabel = ""
        try {
            val halfKm = spanKm(lat) / 2.0
            val n = 7
            val latStep = halfKm / 111.0 / (n / 2)
            val lonStep = halfKm / (111.0 * cos(Math.toRadians(lat)).coerceAtLeast(0.2)) / (n / 2)
            val lats = StringBuilder()
            val lons = StringBuilder()
            // Row 0 = north.
            for (r in 0 until n) for (c in 0 until n) {
                if (lats.isNotEmpty()) { lats.append(','); lons.append(',') }
                lats.append("%.4f".format(java.util.Locale.US, lat + (n / 2 - r) * latStep))
                lons.append("%.4f".format(java.util.Locale.US, lon + (c - n / 2) * lonStep))
            }
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lats&longitude=$lons&current=cloud_cover&timezone=auto"
            val text = httpText(url)
            val arr = if (text.trim().startsWith("[")) JSONArray(text) else JSONArray().put(JSONObject(text))
            val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
            for (i in 0 until arr.length().coerceAtMost(n * n)) {
                val cur = arr.getJSONObject(i).getJSONObject("current")
                val cc = cur.optInt("cloud_cover", 0).coerceIn(0, 100)
                val a = (cc / 100f * 0.85f * 255).roundToInt().coerceIn(0, 255)
                val g = 255 - (cc * 0.25f).roundToInt()
                bmp.setPixel(i % n, i / n, android.graphics.Color.argb(a, g, g, 255.coerceAtMost(g + 4)))
            }
            cloudBmp = bmp
            val t = java.time.LocalTime.now()
            cloudLabel = "%02d:%02d".format(t.hour, t.minute)
        } catch (e: Exception) {
            err += "Bulut: ${e.javaClass.simpleName} ${e.message ?: ""}. "
        }

        var radarBmp: Bitmap? = null
        var radarLabel = ""
        try {
            val meta = JSONObject(httpText("https://api.rainviewer.com/public/weather-maps.json"))
            val host = meta.optString("host", "https://tilecache.rainviewer.com")
            val past = meta.getJSONObject("radar").getJSONArray("past")
            val last = past.getJSONObject(past.length() - 1)
            val path = last.getString("path")
            val epoch = last.getLong("time")
            val (wx, wy) = worldTile(lat, lon)
            val tx = floor(wx).toInt()
            val ty = floor(wy).toInt()
            val fx = (wx - tx).toFloat()
            val fy = (wy - ty).toFloat()
            val n = 1 shl ZOOM
            val out = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            var any = false
            for (dy in -1..1) for (dx in -1..1) {
                val y = ty + dy
                if (y < 0 || y >= n) continue
                val x = (tx + dx).mod(n)
                val bmp = fetchPng("$host$path/256/$ZOOM/$x/$y/2/1_1.png") ?: continue
                any = true
                canvas.drawBitmap(bmp, SIZE / 2f - fx * TILE + dx * TILE, SIZE / 2f - fy * TILE + dy * TILE, null)
            }
            if (any) {
                radarBmp = out
                val tm = java.time.LocalDateTime.ofEpochSecond(epoch, 0, java.time.ZoneId.systemDefault().rules.getOffset(java.time.Instant.ofEpochSecond(epoch)))
                radarLabel = "%02d:%02d".format(tm.hour, tm.minute)
            } else err += "Radar karoları alınamadı. "
        } catch (e: Exception) {
            err += "Radar: ${e.javaClass.simpleName} ${e.message ?: ""}. "
        }
        return LiveOverlay(cloudBmp, cloudLabel, radarBmp, radarLabel, err.trim())
    }

    private fun httpText(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", "KlonDizelIsitici/1.0")
            if (c.responseCode != 200) error("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun fetchPng(url: String): Bitmap? {
        val c = URL(url).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", "KlonDizelIsitici/1.0")
            if (c.responseCode != 200) null else c.inputStream.use { BitmapFactory.decodeStream(it) }
        } catch (_: Exception) {
            null
        } finally {
            c.disconnect()
        }
    }
}
