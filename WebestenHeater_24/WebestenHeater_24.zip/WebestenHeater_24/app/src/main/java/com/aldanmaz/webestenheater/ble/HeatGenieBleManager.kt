package com.aldanmaz.webestenheater.ble

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.aldanmaz.webestenheater.protocol.HeatGenieProtocol
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class HeatGenieBleManager(private val context: Context) {

    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val adapter get() = bluetoothManager?.adapter
    private val handler = Handler(Looper.getMainLooper())
    private val prefs = context.getSharedPreferences("heater_ble", Context.MODE_PRIVATE)
    private val discovered = ConcurrentHashMap<String, BleDeviceItem>()

    private val _state = MutableStateFlow(
        BleUiState(
            permissionGranted = hasRequiredPermissions(),
            adapterAvailable = adapter != null,
            adapterEnabled = safelyAdapterEnabled()
        )
    )
    val state: StateFlow<BleUiState> = _state.asStateFlow()

    private var gatt: BluetoothGatt? = null
    private var txCharacteristic: BluetoothGattCharacteristic? = null
    private var notificationQueue: ArrayDeque<BluetoothGattCharacteristic> = ArrayDeque()
    private var manualDisconnect = false
    private var reconnectAttempts = 0
    private var scanStopRunnable: Runnable? = null
    private var powerToken = 0
    private var statusRequested = false

    fun refreshSystemState() {
        _state.update {
            it.copy(
                permissionGranted = hasRequiredPermissions(),
                adapterAvailable = adapter != null,
                adapterEnabled = safelyAdapterEnabled()
            )
        }
    }

    fun setAutoReconnect(enabled: Boolean) {
        _state.update { it.copy(autoReconnect = enabled) }
    }

    @SuppressLint("MissingPermission")
    fun startScan() {
        refreshSystemState()
        if (!hasRequiredPermissions()) {
            _state.update { it.copy(message = "Önce Bluetooth izni verin") }
            return
        }
        if (adapter == null) {
            _state.update { it.copy(message = "Bu cihazda Bluetooth adaptörü yok") }
            return
        }
        if (!safelyAdapterEnabled()) {
            _state.update { it.copy(message = "Bluetooth kapalı. Telefon ayarlarından açın") }
            return
        }
        stopScan()
        discovered.clear()
        _state.update { it.copy(devices = emptyList(), isScanning = true, message = "BLE cihazları aranıyor…") }
        try {
            adapter?.bluetoothLeScanner?.startScan(scanCallback)
            scanStopRunnable = Runnable { stopScan() }.also { handler.postDelayed(it, 12_000L) }
        } catch (e: Exception) {
            _state.update { it.copy(isScanning = false, message = "Tarama başlatılamadı: ${e.message ?: "bilinmeyen hata"}") }
        }
    }

    @SuppressLint("MissingPermission")
    fun stopScan() {
        scanStopRunnable?.let(handler::removeCallbacks)
        scanStopRunnable = null
        if (hasRequiredPermissions()) {
            try { adapter?.bluetoothLeScanner?.stopScan(scanCallback) } catch (_: Exception) {}
        }
        _state.update { it.copy(isScanning = false) }
    }

    @SuppressLint("MissingPermission")
    fun connect(address: String) {
        refreshSystemState()
        if (!hasRequiredPermissions()) {
            _state.update { it.copy(message = "Bluetooth bağlantı izni gerekli") }
            return
        }
        stopScan()
        manualDisconnect = false
        reconnectAttempts = 0
        closeGatt()
        try {
            val device = adapter?.getRemoteDevice(address)
            val displayName = friendlyName(discovered[address]?.name ?: try { device?.name } catch (_: SecurityException) { null })
            _state.update {
                it.copy(
                    connectionState = "BAĞLANIYOR…",
                    connectedName = displayName,
                    connectedAddress = address,
                    service181aFound = false,
                    writeCharacteristicFound = false,
                    notifyCharacteristicCount = 0,
                    message = "GATT bağlantısı kuruluyor"
                )
            }
            gatt = device?.connectGatt(context, false, gattCallback, android.bluetooth.BluetoothDevice.TRANSPORT_LE)
        } catch (e: Exception) {
            _state.update { it.copy(connectionState = "BAĞLANTI HATASI", message = e.message ?: "Bağlantı hatası") }
        }
    }

    /** A MAC-like code (C1:00:45:44:FE:3A) or "unnamed" is not a name: show the product name instead. */
    private fun friendlyName(raw: String?): String {
        val n = raw.orEmpty().trim()
        val looksLikeCode = n.isBlank() || n == "İsimsiz BLE cihazı" ||
            Regex("^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$").matches(n) ||
            Regex("^[0-9A-Fa-f]{12}$").matches(n)
        return if (looksLikeCode) "KLON Dizel Isıtıcı" else n
    }

    fun connectLastDevice() {
        val address = prefs.getString("last_address", null)
        if (address.isNullOrBlank()) {
            _state.update { it.copy(message = "Daha önce kaydedilmiş cihaz yok") }
        } else connect(address)
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        manualDisconnect = true
        reconnectAttempts = 0
        try { gatt?.disconnect() } catch (_: Exception) {}
        closeGatt()
        _state.update {
            it.copy(
                connectionState = "BAĞLI DEĞİL",
                service181aFound = false,
                writeCharacteristicFound = false,
                notifyCharacteristicCount = 0,
                message = "Bağlantı kullanıcı tarafından kesildi"
            )
        }
    }

    /** Asks the controller to periodically report register/status data. */
    fun requestStatusUpdates() {
        writeFrame(HeatGenieProtocol.autoUpdateFrame(true), "DURUM İSTEĞİ")
    }

    private fun startStatusOnce() {
        if (statusRequested || gatt == null) return
        statusRequested = true
        requestStatusUpdates()
    }

    /** True when connected and the 181A write characteristic was found. */
    fun isCommandChannelReady(): Boolean = gatt != null && txCharacteristic != null

    /** _24: real START / STOP command. Returns true if the frame was queued for writing. */
    fun sendPower(turnOn: Boolean): Boolean {
        powerToken = (powerToken % 0xFE) + 1
        return writeFrame(HeatGenieProtocol.powerFrame(turnOn, powerToken), if (turnOn) "BAŞLAT KOMUTU" else "DURDUR KOMUTU")
    }

    /** _24: real target temperature command (auto mode). */
    fun sendTargetTemperature(celsius: Int): Boolean =
        writeFrame(HeatGenieProtocol.targetTemperatureFrame(celsius), "HEDEF SICAKLIK $celsius°C")

    /** _24: real fan/gear command (manual mode). */
    fun sendTargetGear(gear: Int): Boolean =
        writeFrame(HeatGenieProtocol.targetGearFrame(gear), "FAN KADEMESİ $gear")

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            if (!hasRequiredPermissions()) return
            val name = try {
                result.scanRecord?.deviceName ?: result.device.name ?: "İsimsiz BLE cihazı"
            } catch (_: SecurityException) { "İsimsiz BLE cihazı" }
            val address = try { result.device.address } catch (_: SecurityException) { return }
            val serviceLikely = result.scanRecord?.serviceUuids?.any { it.uuid.toString().contains("181a", ignoreCase = true) } == true
            val likely = name.contains("boygu", ignoreCase = true) || serviceLikely || looksLikeHeatGenieName(name)
            discovered[address] = BleDeviceItem(name, address, result.rssi, likely)
            val sorted = discovered.values.sortedWith(compareByDescending<BleDeviceItem> { it.likelyHeater }.thenByDescending { it.rssi })
            _state.update { it.copy(devices = sorted, message = "${sorted.size} BLE cihaz bulundu") }
        }

        override fun onScanFailed(errorCode: Int) {
            _state.update { it.copy(isScanning = false, message = "BLE tarama hatası: $errorCode") }
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    gatt = g
                    reconnectAttempts = 0
                    prefs.edit().putString("last_address", g.device.address).apply()
                    _state.update {
                        it.copy(
                            connectionState = "BAĞLANDI • SERVİSLER ARANIYOR",
                            connectedAddress = g.device.address,
                            message = "Bağlantı kuruldu"
                        )
                    }
                    try { g.discoverServices() } catch (e: Exception) {
                        _state.update { it.copy(message = "Servis keşfi başlatılamadı: ${e.message}") }
                    }
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    txCharacteristic = null
                    _state.update {
                        it.copy(
                            connectionState = "BAĞLANTI KESİLDİ",
                            service181aFound = false,
                            writeCharacteristicFound = false,
                            notifyCharacteristicCount = 0,
                            message = "Bluetooth bağlantısı kesildi (GATT $status)"
                        )
                    }
                    if (!manualDisconnect && _state.value.autoReconnect) scheduleReconnect(g.device.address)
                }
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                _state.update { it.copy(connectionState = "SERVİS HATASI", message = "Servis keşfi başarısız: $status") }
                return
            }
            val service = g.services.firstOrNull { it.uuid.toString().contains(HeatGenieProtocol.SERVICE_UUID_FRAGMENT, ignoreCase = true) }
            if (service == null) {
                _state.update {
                    it.copy(
                        connectionState = "181A BULUNAMADI",
                        service181aFound = false,
                        message = "Bağlandı ama HeatGenie 181A servisi bulunamadı"
                    )
                }
                return
            }

            val chars = service.characteristics
            // Same rule as the original HeatGenie app: it walks ALL characteristics of the 181A service and
            // the LAST one that has the WRITE property wins (no break in its loop). Fall back to the last
            // write-without-response characteristic.
            txCharacteristic = chars.lastOrNull { c ->
                (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0
            } ?: chars.lastOrNull { c ->
                (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
            }
            val dump = chars.joinToString("\n") { c ->
                val p = c.properties
                val flags = buildList {
                    if (p and BluetoothGattCharacteristic.PROPERTY_READ != 0) add("R")
                    if (p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) add("W")
                    if (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) add("WNR")
                    if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) add("N")
                    if (p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) add("I")
                }.joinToString("+")
                val mark = if (c == txCharacteristic) "  <== KOMUT KANALI" else ""
                "${c.uuid.toString().take(8)} [$flags]$mark"
            }
            val rx = chars.filter { c ->
                (c.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 ||
                    (c.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0
            }
            notificationQueue = ArrayDeque(rx)
            _state.update {
                it.copy(
                    connectionState = if (txCharacteristic != null) "HEATGENIE SERVİSİ HAZIR" else "YAZMA KANALI YOK",
                    service181aFound = true,
                    writeCharacteristicFound = txCharacteristic != null,
                    notifyCharacteristicCount = rx.size,
                    gattDump = dump,
                    message = "181A bulundu • ${rx.size} bildirim kanalı • yazma=${txCharacteristic != null}"
                )
            }
            // Android runs ONE GATT operation at a time: notifications -> MTU -> status request,
            // each started only after the previous one finished. A fallback timer covers lost callbacks.
            statusRequested = false
            enableNextNotification(g)
            handler.postDelayed({ startStatusOnce() }, 5000L)
        }

        override fun onMtuChanged(gatt: BluetoothGatt, mtu: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) _state.update { it.copy(negotiatedMtu = mtu) }
            handler.postDelayed({ startStatusOnce() }, 200L)
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            val text = if (status == BluetoothGatt.GATT_SUCCESS) "Bluetooth katmanı gönderdi (GATT 0)" else "GÖNDERİM HATASI (GATT $status)"
            _state.update { it.copy(lastWriteResult = text) }
        }

        @SuppressLint("MissingPermission")
        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            enableNextNotification(g)
        }

        @Deprecated("Deprecated in API 33; kept for Android 8-12 compatibility")
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            handleIncoming(characteristic.value ?: return)
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            handleIncoming(value)
        }
    }

    @SuppressLint("MissingPermission")
    private fun enableNextNotification(g: BluetoothGatt) {
        if (!hasRequiredPermissions()) return
        val characteristic = if (notificationQueue.isEmpty()) null else notificationQueue.removeFirst()
        if (characteristic == null) {
            // all notifications enabled -> now (and only now) negotiate MTU, then request status
            val started = try { g.requestMtu(247) } catch (_: Exception) { false }
            if (!started) handler.postDelayed({ startStatusOnce() }, 300L)
            return
        }
        try {
            g.setCharacteristicNotification(characteristic, true)
            val descriptor = characteristic.getDescriptor(CCCD_UUID)
            if (descriptor == null) {
                enableNextNotification(g)
                return
            }
            val indicate = (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0
            val value = if (indicate) BluetoothGattDescriptor.ENABLE_INDICATION_VALUE else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (Build.VERSION.SDK_INT >= 33) {
                val result = g.writeDescriptor(descriptor, value)
                if (result != BluetoothGatt.GATT_SUCCESS) enableNextNotification(g)
            } else {
                @Suppress("DEPRECATION")
                descriptor.value = value
                @Suppress("DEPRECATION")
                if (!g.writeDescriptor(descriptor)) enableNextNotification(g)
            }
        } catch (_: Exception) {
            enableNextNotification(g)
        }
    }

    @SuppressLint("MissingPermission")
    private fun writeFrame(frame: ByteArray, label: String, attempt: Int = 0): Boolean {
        if (!hasRequiredPermissions()) return false
        val g = gatt
        val ch = txCharacteristic
        if (g == null || ch == null) {
            _state.update { it.copy(message = "$label gönderilemedi: yazma kanalı hazır değil") }
            return false
        }
        return try {
            // The original HeatGenie app always writes with "writeNoResponse"; mirror that when the
            // characteristic supports it, otherwise fall back to a normal acknowledged write.
            val writeType = if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) {
                BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            } else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            val ok = if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(ch, frame, writeType) == BluetoothGatt.GATT_SUCCESS
            } else {
                @Suppress("DEPRECATION") ch.writeType = writeType
                @Suppress("DEPRECATION") ch.value = frame
                @Suppress("DEPRECATION") g.writeCharacteristic(ch)
            }
            if (!ok && attempt < 3) {
                // Another GATT operation is still running: retry shortly instead of silently dropping the command.
                handler.postDelayed({ writeFrame(frame, label, attempt + 1) }, 400L)
            }
            _state.update {
                it.copy(
                    lastTxHex = frame.toHex(),
                    message = if (ok) "$label gönderildi: ${frame.toHex()}"
                    else if (attempt < 3) "$label meşgul, tekrar denenecek (${attempt + 1}/3)"
                    else "$label yazma kuyruğuna alınamadı"
                )
            }
            ok
        } catch (e: Exception) {
            _state.update { it.copy(message = "$label hatası: ${e.message}") }
            false
        }
    }

    private fun handleIncoming(data: ByteArray) {
        val hex = data.toHex()
        val parsed = HeatGenieStatusParser.parse(data)
        _state.update { old ->
            old.copy(
                lastRxHex = hex,
                rxLog = (listOf(hex) + old.rxLog).take(12),
                liveStatus = parsed ?: old.liveStatus,
                message = if (parsed != null) "Canlı durum paketi çözüldü" else "${data.size} byte veri alındı"
            )
        }
    }

    private fun scheduleReconnect(address: String) {
        if (reconnectAttempts >= 5) {
            _state.update { it.copy(message = "Otomatik yeniden bağlantı 5 denemeden sonra durdu") }
            return
        }
        reconnectAttempts++
        _state.update { it.copy(message = "Yeniden bağlanma denemesi $reconnectAttempts/5") }
        handler.postDelayed({
            if (!manualDisconnect && _state.value.autoReconnect) connectWithoutReset(address)
        }, 5000L)
    }

    @SuppressLint("MissingPermission")
    private fun connectWithoutReset(address: String) {
        if (!hasRequiredPermissions()) return
        try {
            closeGatt()
            val device = adapter?.getRemoteDevice(address) ?: return
            _state.update { it.copy(connectionState = "YENİDEN BAĞLANIYOR…") }
            gatt = device.connectGatt(context, false, gattCallback, android.bluetooth.BluetoothDevice.TRANSPORT_LE)
        } catch (_: Exception) {
            scheduleReconnect(address)
        }
    }

    @SuppressLint("MissingPermission")
    private fun closeGatt() {
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
        txCharacteristic = null
        statusRequested = false
        notificationQueue.clear()
    }

    private fun hasRequiredPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= 31) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    @SuppressLint("MissingPermission")
    private fun safelyAdapterEnabled(): Boolean = try {
        adapter?.isEnabled == true
    } catch (_: SecurityException) { false }

    private fun looksLikeHeatGenieName(name: String): Boolean {
        val parts = name.split(":")
        if (parts.size < 5) return false
        return parts.firstOrNull()?.equals("C1", ignoreCase = true) == true &&
            parts.getOrNull(4)?.equals("FE", ignoreCase = true) == true
    }

    private fun ByteArray.toHex(): String = joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }

    companion object {
        private val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }
}
