package com.aldanmaz.webestenheater.protocol

/**
 * HeatGenie 1.1.1 APK analysis based protocol helpers.
 * Protocol helper extracted from HeatGenie 1.1.1.
 * High-level heater control stays locked in _06; status polling is enabled for real BLE testing.
 */
object HeatGenieProtocol {
    const val SERVICE_UUID_FRAGMENT = "181A"

    private const val FRAME_START = 0xAA
    private const val DB0_DN_CMD = 0x61
    private const val DB0_DN_SHORT_PARA = 0x66
    private const val DB0_DN_AUTO_UPDATA = 0x65

    const val CMD_ON = 0x01
    const val CMD_OFF = 0x02

    const val SHORT_RUN_MODE = 0x00
    const val SHORT_TARGET_TEMP = 0x01
    const val SHORT_TARGET_GEAR = 0x02

    const val RUN_MODE_AUTO = 0
    const val RUN_MODE_MANUAL = 1
    const val RUN_MODE_START_STOP = 2

    fun powerFrame(turnOn: Boolean, token: Int): ByteArray = frame(
        command = DB0_DN_CMD,
        p0 = if (turnOn) CMD_ON else CMD_OFF,
        p1 = token.coerceIn(0, 0xFE),
        p2 = 0
    )

    fun targetTemperatureFrame(celsius: Int): ByteArray = frame(
        command = DB0_DN_SHORT_PARA,
        p0 = SHORT_TARGET_TEMP,
        p1 = 0,
        p2 = celsius.coerceIn(10, 40)
    )

    fun targetGearFrame(gear: Int): ByteArray = frame(
        command = DB0_DN_SHORT_PARA,
        p0 = SHORT_TARGET_GEAR,
        p1 = 0,
        p2 = gear.coerceIn(1, 10)
    )

    fun runModeFrame(mode: Int): ByteArray = frame(
        command = DB0_DN_SHORT_PARA,
        p0 = SHORT_RUN_MODE,
        p1 = 0,
        p2 = mode.coerceIn(RUN_MODE_AUTO, RUN_MODE_START_STOP)
    )


    fun autoUpdateFrame(enable: Boolean): ByteArray = frame(
        command = DB0_DN_AUTO_UPDATA,
        p0 = 0x02, // ADDR_TYPE_REG
        p1 = if (enable) 10 else 0,
        p2 = if (enable) 0 else 30
    )

    fun isValidFrame(data: ByteArray): Boolean = data.size >= 8 && crc16Ccitt(data) == 0

    private fun frame(command: Int, p0: Int, p1: Int, p2: Int): ByteArray {
        val firstSix = byteArrayOf(
            FRAME_START.toByte(),
            0x00,
            command.toByte(),
            p0.toByte(),
            p1.toByte(),
            p2.toByte()
        )
        val crc = crc16Ccitt(firstSix)
        return firstSix + byteArrayOf(((crc shr 8) and 0xFF).toByte(), (crc and 0xFF).toByte())
    }

    fun crc16Ccitt(data: ByteArray): Int {
        var crc = 0x0000
        for (byte in data) {
            crc = crc xor ((byte.toInt() and 0xFF) shl 8)
            repeat(8) {
                crc = if ((crc and 0x8000) != 0) {
                    ((crc shl 1) xor 0x1021) and 0xFFFF
                } else {
                    (crc shl 1) and 0xFFFF
                }
            }
        }
        return crc and 0xFFFF
    }
}
