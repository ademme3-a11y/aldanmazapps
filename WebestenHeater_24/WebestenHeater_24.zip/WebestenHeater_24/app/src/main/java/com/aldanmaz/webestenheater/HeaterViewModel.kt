package com.aldanmaz.webestenheater

import android.app.Application
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewModelScope
import com.aldanmaz.webestenheater.model.HeaterUiState
import com.aldanmaz.webestenheater.ble.HeatGenieBleManager
import com.aldanmaz.webestenheater.model.HeaterEvent
import com.aldanmaz.webestenheater.model.TemperatureSample
import android.media.AudioManager
import android.media.ToneGenerator
import com.aldanmaz.webestenheater.weather.SatelliteImage
import com.aldanmaz.webestenheater.weather.SatelliteMap
import com.aldanmaz.webestenheater.weather.WeatherRepository
import com.aldanmaz.webestenheater.weather.WeatherUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.max
import kotlin.math.min

class HeaterViewModel(application: Application) : AndroidViewModel(application) {

    private val bleManager = HeatGenieBleManager(application.applicationContext)
    val bleState = bleManager.state

    private val appContext = application.applicationContext
    private val locationManager = appContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            applyGpsAltitude(location)
        }
        override fun onProviderEnabled(provider: String) = Unit
        override fun onProviderDisabled(provider: String) = Unit
        @Deprecated("Deprecated in Android")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
    }

    /**
     * The heater's own altitude sensor can be far off (it reported 800 m at ~90 m), so the phone's GPS altitude
     * is preferred. On Android 14+ the mean-sea-level altitude is used; older versions use Location.altitude.
     */
    private fun applyGpsAltitude(location: Location) {
        onLocationFix(location.latitude, location.longitude)
        val meters: Double = if (Build.VERSION.SDK_INT >= 34 && location.hasMslAltitude()) {
            location.mslAltitudeMeters.toDouble()
        } else if (location.hasAltitude()) {
            location.altitude
        } else return
        _uiState.update { cur ->
            val old = cur.gpsAltitudeMeters
            val smoothed = if (old == null) meters.toInt() else (old * 0.7 + meters * 0.3).toInt()
            cur.copy(gpsAltitudeMeters = smoothed, altitudeMeters = smoothed)
        }
    }

    private val _uiState = MutableStateFlow(HeaterUiState())

    // ---- weather (Open-Meteo), refreshed from the phone's location ----
    private val _weather = MutableStateFlow(WeatherUiState())
    val weather: StateFlow<WeatherUiState> = _weather.asStateFlow()
    private var weatherLat: Double? = null
    private var weatherLon: Double? = null
    private var lastWeatherFetchMs = 0L
    private var weatherFetching = false
    private var weatherTick = 0

    private fun onLocationFix(lat: Double, lon: Double) {
        weatherLat = lat
        weatherLon = lon
        _weather.update { it.copy(locationKnown = true) }
        val stale = SystemClock.elapsedRealtime() - lastWeatherFetchMs > 30 * 60_000L
        if (_weather.value.data == null || stale) refreshWeather()
    }

    fun refreshWeather() {
        val lat = weatherLat ?: return
        val lon = weatherLon ?: return
        if (weatherFetching) return
        weatherFetching = true
        _weather.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            try {
                val data = withContext(Dispatchers.IO) { WeatherRepository.fetch(lat, lon) }
                val alerts = WeatherRepository.computeAlerts(data)
                lastWeatherFetchMs = SystemClock.elapsedRealtime()
                val t = LocalTime.now()
                _weather.update {
                    it.copy(
                        loading = false, error = null, data = data, alerts = alerts, locationKnown = true,
                        updatedAtLabel = "%02d:%02d".format(t.hour, t.minute)
                    )
                }
                _uiState.update { it.copy(externalTemperatureC = data.current.tempC, externalTemperatureAvailable = true) }
            } catch (e: Exception) {
                _weather.update { it.copy(loading = false, error = e.message ?: e.javaClass.simpleName) }
            } finally {
                weatherFetching = false
            }
        }
    }

    // ---- satellite picture (NASA GIBS) for the space view ----
    data class SatelliteState(
        val loading: Boolean = false,
        val error: String? = null,
        val image: SatelliteImage? = null,
        val live: SatelliteMap.LiveOverlay? = null,
        val liveLoading: Boolean = false
    )
    private val _satellite = MutableStateFlow(SatelliteState())
    val satellite: StateFlow<SatelliteState> = _satellite.asStateFlow()
    private var satFetching = false

    fun loadSatellite(force: Boolean = false) {
        val lat = weatherLat ?: return
        val lon = weatherLon ?: return
        val key = SatelliteMap.keyFor(lat, lon)
        if (!force && _satellite.value.image?.key == key) return
        if (satFetching) return
        satFetching = true
        _satellite.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            try {
                val img = withContext(Dispatchers.IO) { SatelliteMap.load(lat, lon) }
                _satellite.update {
                    if (img != null) it.copy(loading = false, error = null, image = img)
                    else it.copy(loading = false, error = "Uydu fotoğrafı alınamadı. Ayrıntı: " + SatelliteMap.lastError)
                }
            } catch (e: Exception) {
                _satellite.update { it.copy(loading = false, error = e.message ?: e.javaClass.simpleName) }
            } finally {
                satFetching = false
            }
        }
    }

    private var liveFetching = false

    fun loadLiveLayers() {
        val lat = weatherLat ?: return
        val lon = weatherLon ?: return
        if (liveFetching) return
        liveFetching = true
        _satellite.update { it.copy(liveLoading = true) }
        viewModelScope.launch {
            try {
                val live = withContext(Dispatchers.IO) { SatelliteMap.loadLive(lat, lon) }
                _satellite.update { it.copy(live = live, liveLoading = false) }
            } catch (e: Exception) {
                _satellite.update { it.copy(liveLoading = false) }
            } finally {
                liveFetching = false
            }
        }
    }

    // ---- low-voltage beep ----
    private var lastBeepMs = 0L

    fun setLowVoltageBeep(enabled: Boolean) = _uiState.update { it.copy(lowVoltageBeepEnabled = enabled) }

    fun testBeep() = playDoubleBeep()

    private fun playDoubleBeep() {
        viewModelScope.launch {
            val tone = runCatching { ToneGenerator(AudioManager.STREAM_ALARM, 90) }.getOrNull() ?: return@launch
            try {
                tone.startTone(ToneGenerator.TONE_PROP_BEEP, 200)
                delay(380)
                tone.startTone(ToneGenerator.TONE_PROP_BEEP, 200)
                delay(300)
            } finally {
                tone.release()
            }
        }
    }

    private fun checkBatteryAlarm() {
        val s = _uiState.value
        if (!s.lowVoltageBeepEnabled || bleState.value.liveStatus == null) return
        val level = batteryLevel(s.batteryVoltage)
        if (level == 0) return
        val interval = if (level == 2) 15_000L else 60_000L
        val now = SystemClock.elapsedRealtime()
        if (now - lastBeepMs >= interval) {
            lastBeepMs = now
            playDoubleBeep()
        }
    }

    // ---- fan (ventilation) mode ----
    fun toggleFanMode() {
        val s = _uiState.value
        if (s.isFanMode) {
            val ok = bleManager.sendFanMode(false)
            _uiState.update { it.copy(fanModeMessage = if (ok) "Fan modu durduruluyor…" else "Komut gönderilemedi: ısıtıcı bağlı değil") }
            return
        }
        if (s.isHeaterOn) {
            _uiState.update { it.copy(fanModeMessage = "Isıtıcı çalışırken fan modu açılamaz; önce durdurun.") }
            return
        }
        val ok = bleManager.sendFanMode(true)
        _uiState.update { it.copy(fanModeMessage = if (ok) "Fan modu komutu gönderildi." else "Komut gönderilemedi: ısıtıcı bağlı değil") }
    }
    val uiState: StateFlow<HeaterUiState> = _uiState.asStateFlow()

    private var lastHeaterStartMs = 0L
    private var lastHeaterStopMs = 0L
    private var frostLatched = false
    private var thermostatOwnsRun = false
    private var lastThermostatCmdMs = 0L

    /**
     * Name of the automation (TERMOSTAT, GÜNLÜK, TURBO ...) that STARTED the current run, or null when the
     * heater was started by hand. Previously this was guessed from the "activeController" label, which the
     * live heater status kept overwriting (OTOMATİK/MANUEL/...). A manual START was then mistaken for an
     * automation run whose window had ended and the app sent STOP about a minute later.
     */
    private var autoOwner: String? = null
    private var lastAutoStartCmdMs = 0L
    private var lastSentGear = -1
    private var lastSentTarget = -1

    init {
        bindBleLiveStatus()
        startRuntimeLoop()
    }

    fun togglePower() {
        if (_uiState.value.isFanMode) { toggleFanMode(); return }
        val next = !_uiState.value.isHeaterOn
        disableAllAutomations()
        _uiState.update { it.copy(activeController = "MANUEL") }
        setHeaterPower(next)
    }

    fun setTargetTemperature(value: Int) {
        val v = value.coerceIn(10, 40)
        _uiState.update { it.copy(targetTemperatureC = v) }
        if (bleManager.isCommandChannelReady()) bleManager.sendTargetTemperature(v)
    }

    fun setAmbientTemperature(value: Float) {
        if (!_uiState.value.isDemoMode) return
        _uiState.update { it.copy(ambientTemperatureC = value.coerceIn(-30f, 45f)) }
        evaluateAutomation()
    }

    fun setExternalTemperature(value: Float) {
        if (!_uiState.value.isDemoMode) return
        _uiState.update { it.copy(externalTemperatureC = value.coerceIn(-30f, 50f), externalTemperatureAvailable = true) }
    }

    fun setDemoAltitude(value: Int) {
        if (!_uiState.value.isDemoMode) return
        _uiState.update { it.copy(altitudeMeters = value.coerceIn(-100, 5000)) }
    }

    fun startLocationUpdates() {
        val fine = ContextCompat.checkSelfPermission(appContext, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(appContext, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return
        try {
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            providers.forEach { provider ->
                if (runCatching { locationManager.isProviderEnabled(provider) }.getOrDefault(false)) {
                    runCatching { locationManager.getLastKnownLocation(provider) }.getOrNull()?.let { location ->
                        applyGpsAltitude(location)
                    }
                    runCatching { locationManager.requestLocationUpdates(provider, 5_000L, 5f, locationListener) }
                }
            }
        } catch (_: SecurityException) { }
    }

    fun stopLocationUpdates() {
        runCatching { locationManager.removeUpdates(locationListener) }
    }

    fun setFanLevel(value: Int) {
        val v = value.coerceIn(1, 10)
        _uiState.update { it.copy(fanLevel = v) }
        if (bleManager.isCommandChannelReady()) bleManager.sendTargetGear(v)
    }

    fun toggleThermostat() {
        val enabling = !_uiState.value.thermostatEnabled
        if (!enabling) thermostatOwnsRun = false
        _uiState.update { it.copy(thermostatEnabled = enabling) }
        evaluateAutomation()
    }
    fun setThermostatStartTemperature(value: Int) = updateBandTemp("thermostatStart", value)
    fun setThermostatStopTemperature(value: Int) = updateBandTemp("thermostatStop", value)
    fun setMinimumRunMinutes(value: Int) { _uiState.update { it.copy(minimumRunMinutes = value.coerceIn(0, 30)) }; evaluateAutomation() }
    fun setMinimumRestMinutes(value: Int) { _uiState.update { it.copy(minimumRestMinutes = value.coerceIn(0, 30)) }; evaluateAutomation() }

    fun toggleDailyProgram() { _uiState.update { it.copy(dailyProgramEnabled = !it.dailyProgramEnabled) }; evaluateAutomation() }
    fun shiftDailyProgramStart(delta: Int) { _uiState.update { it.copy(dailyProgramStartMinutes = wrapMinutes(it.dailyProgramStartMinutes + delta)) }; evaluateAutomation() }
    fun shiftDailyProgramEnd(delta: Int) { _uiState.update { it.copy(dailyProgramEndMinutes = wrapMinutes(it.dailyProgramEndMinutes + delta)) }; evaluateAutomation() }
    fun setDailyProgramStartTemperature(value: Int) = updateBandTemp("dailyStart", value)
    fun setDailyProgramStopTemperature(value: Int) = updateBandTemp("dailyStop", value)
    fun setDailyProgramFanLevel(value: Int) { _uiState.update { it.copy(dailyProgramFanLevel = value.coerceIn(1, 10)) }; evaluateAutomation() }

    fun toggleWeeklyProgram() { _uiState.update { it.copy(weeklyProgramEnabled = !it.weeklyProgramEnabled) }; evaluateAutomation() }
    fun toggleWeeklyDay(day: Int) {
        if (day !in 1..7) return
        _uiState.update { s ->
            val next = s.weeklyDays.toMutableSet().also { if (!it.add(day)) it.remove(day) }
            s.copy(weeklyDays = next)
        }
        evaluateAutomation()
    }
    fun shiftWeeklyStart(delta: Int) { _uiState.update { it.copy(weeklyStartMinutes = wrapMinutes(it.weeklyStartMinutes + delta)) }; evaluateAutomation() }
    fun shiftWeeklyEnd(delta: Int) { _uiState.update { it.copy(weeklyEndMinutes = wrapMinutes(it.weeklyEndMinutes + delta)) }; evaluateAutomation() }
    fun setWeeklyStartC(value: Int) = updateBandTemp("weeklyStart", value)
    fun setWeeklyStopC(value: Int) = updateBandTemp("weeklyStop", value)
    fun setWeeklyFan(value: Int) { _uiState.update { it.copy(weeklyFanLevel = value.coerceIn(1, 10)) }; evaluateAutomation() }

    fun toggleNightMode() { _uiState.update { it.copy(nightModeEnabled = !it.nightModeEnabled) }; evaluateAutomation() }
    fun shiftNightStart(delta: Int) { _uiState.update { it.copy(nightStartMinutes = wrapMinutes(it.nightStartMinutes + delta)) }; evaluateAutomation() }
    fun shiftNightEnd(delta: Int) { _uiState.update { it.copy(nightEndMinutes = wrapMinutes(it.nightEndMinutes + delta)) }; evaluateAutomation() }
    fun setNightStartC(value: Int) = updateBandTemp("nightStart", value)
    fun setNightStopC(value: Int) = updateBandTemp("nightStop", value)
    fun setNightFan(value: Int) { _uiState.update { it.copy(nightFanLevel = value.coerceIn(1, 10)) }; evaluateAutomation() }

    fun toggleFrostProtection() {
        val enabled = !_uiState.value.frostProtectionEnabled
        if (!enabled) frostLatched = false
        _uiState.update { it.copy(frostProtectionEnabled = enabled) }
        evaluateAutomation()
    }
    fun setFrostStartC(value: Int) = updateBandTemp("frostStart", value)
    fun setFrostStopC(value: Int) = updateBandTemp("frostStop", value)
    fun setFrostFan(value: Int) { _uiState.update { it.copy(frostFanLevel = value.coerceIn(1, 10)) }; evaluateAutomation() }

    fun toggleBoost() {
        val s = _uiState.value
        if (s.boostEnabled) {
            _uiState.update { it.copy(boostEnabled = false, boostRemainingSeconds = 0) }
        } else {
            _uiState.update { it.copy(boostEnabled = true, boostRemainingSeconds = it.boostDurationMinutes * 60) }
        }
        evaluateAutomation()
    }
    fun setBoostDuration(value: Int) {
        _uiState.update {
            val v = value.coerceIn(5, 60)
            it.copy(boostDurationMinutes = v, boostRemainingSeconds = if (it.boostEnabled) v * 60 else it.boostRemainingSeconds)
        }
    }
    fun demoAdvanceBoost(minutes: Int) {
        if (!_uiState.value.isDemoMode || !_uiState.value.boostEnabled) return
        _uiState.update { it.copy(boostRemainingSeconds = (it.boostRemainingSeconds - minutes * 60).coerceAtLeast(0)) }
        if (_uiState.value.boostRemainingSeconds == 0) {
            _uiState.update { it.copy(boostEnabled = false) }
        }
        evaluateAutomation()
    }

    fun favoriteNight() {
        if (!_uiState.value.nightModeEnabled) _uiState.update { it.copy(nightModeEnabled = true) }
        evaluateAutomation()
    }

    fun favoriteFrost() {
        if (!_uiState.value.frostProtectionEnabled) _uiState.update { it.copy(frostProtectionEnabled = true) }
        evaluateAutomation()
    }

    fun favoriteTurbo() {
        if (!_uiState.value.boostEnabled) {
            _uiState.update { it.copy(boostEnabled = true, boostRemainingSeconds = it.boostDurationMinutes * 60) }
        }
        evaluateAutomation()
    }

    fun shiftDemoClock(delta: Int) { if (_uiState.value.isDemoMode) { _uiState.update { it.copy(demoClockMinutes = wrapMinutes(it.demoClockMinutes + delta)) }; evaluateAutomation() } }
    fun shiftDemoDay(delta: Int) {
        if (!_uiState.value.isDemoMode) return
        _uiState.update { it.copy(demoDayOfWeek = wrapDay(it.demoDayOfWeek + delta)) }
        evaluateAutomation()
    }

    fun refreshBleSystemState() = bleManager.refreshSystemState()
    fun startBleScan() = bleManager.startScan()
    fun stopBleScan() = bleManager.stopScan()
    fun connectBle(address: String) = bleManager.connect(address)
    fun connectLastBleDevice() = bleManager.connectLastDevice()
    fun disconnectBle() = bleManager.disconnect()
    fun requestBleStatus() = bleManager.requestStatusUpdates()
    fun setBleAutoReconnect(enabled: Boolean) = bleManager.setAutoReconnect(enabled)

    fun resetStatistics() {
        _uiState.update { s ->
            s.copy(
                totalRunSeconds = 0L,
                startCount = 0,
                estimatedFuelLiters = 0f,
                minRecordedTemperatureC = s.ambientTemperatureC,
                maxRecordedTemperatureC = s.ambientTemperatureC,
                historySamples = emptyList(),
                eventLog = emptyList(),
                errorLog = emptyList(),
                historySampleIndex = 0
            )
        }
    }

    fun addDemoError() {
        if (!_uiState.value.isDemoMode) return
        _uiState.update { s ->
            val event = HeaterEvent(
                timeLabel = eventTimeLabel(s),
                title = "DEMO HATA",
                detail = "Test hata kaydı • gerçek hata kodları BLE bağlantısında okunacak"
            )
            s.copy(
                errorLog = (listOf(event) + s.errorLog).take(20),
                eventLog = (listOf(event) + s.eventLog).take(30)
            )
        }
    }

    private fun disableAllAutomations() {
        frostLatched = false
        thermostatOwnsRun = false
        autoOwner = null
        _uiState.update {
            it.copy(
                boostEnabled = false, boostRemainingSeconds = 0,
                thermostatEnabled = false,
                dailyProgramEnabled = false,
                weeklyProgramEnabled = false,
                nightModeEnabled = false,
                frostProtectionEnabled = false,
                thermostatStatusText = "PASİF",
                dailyProgramStatusText = "PASİF",
                weeklyStatusText = "PASİF",
                nightStatusText = "PASİF",
                frostStatusText = "PASİF"
            )
        }
    }

    private fun updateBandTemp(kind: String, value: Int) {
        _uiState.update { s ->
            when (kind) {
                "thermostatStart" -> s.copy(thermostatStartC = value.coerceIn(5, s.thermostatStopC - 1))
                "thermostatStop" -> s.copy(thermostatStopC = value.coerceIn(s.thermostatStartC + 1, 40))
                "dailyStart" -> s.copy(dailyProgramStartC = value.coerceIn(5, s.dailyProgramStopC - 1))
                "dailyStop" -> s.copy(dailyProgramStopC = value.coerceIn(s.dailyProgramStartC + 1, 40))
                "weeklyStart" -> s.copy(weeklyStartC = value.coerceIn(5, s.weeklyStopC - 1))
                "weeklyStop" -> s.copy(weeklyStopC = value.coerceIn(s.weeklyStartC + 1, 40))
                "nightStart" -> s.copy(nightStartC = value.coerceIn(5, s.nightStopC - 1))
                "nightStop" -> s.copy(nightStopC = value.coerceIn(s.nightStartC + 1, 35))
                "frostStart" -> s.copy(frostStartC = value.coerceIn(-5, s.frostStopC - 1))
                "frostStop" -> s.copy(frostStopC = value.coerceIn(s.frostStartC + 1, 15))
                else -> s
            }
        }
        evaluateAutomation()
    }

    private data class Demand(val controller: String, val targetC: Int, val fan: Int)

    private fun evaluateAutomation() {
        var s = _uiState.value
        val nowMin = currentMinutes(s)
        val day = currentDay(s)

        // Durum metinlerini her değerlendirmede güncelle.
        _uiState.update { cur ->
            cur.copy(
                thermostatStatusText = if (cur.thermostatEnabled) {
                    cur.thermostatStatusText.takeIf { it != "PASİF" && it.isNotBlank() } ?: "AKTİF • ${cur.thermostatStartC}→${cur.thermostatStopC}°C"
                } else "PASİF",
                dailyProgramStatusText = if (cur.dailyProgramEnabled) dailyText(cur, nowMin) else "PASİF",
                weeklyStatusText = if (cur.weeklyProgramEnabled) weeklyText(cur, nowMin, day) else "PASİF",
                nightStatusText = if (cur.nightModeEnabled) nightText(cur, nowMin) else "PASİF",
                frostStatusText = if (cur.frostProtectionEnabled) "HAZIR • ${cur.frostStartC}°C'DE DEVREYE GİRER" else "PASİF"
            )
        }
        s = _uiState.value
        if (s.isFanMode) return

        // 1) TURBO en yüksek otomatik öncelik.
        if (s.boostEnabled && s.boostRemainingSeconds > 0) {
            applyDemand(Demand("TURBO", s.targetTemperatureC, 10))
            return
        }

        // 2) Don koruma yalnızca gerektiğinde üst önceliği ele alır.
        if (s.frostProtectionEnabled) {
            if (s.ambientTemperatureC <= s.frostStartC) frostLatched = true
            if (frostLatched && s.ambientTemperatureC >= s.frostStopC) frostLatched = false
            if (frostLatched) {
                _uiState.update { it.copy(frostStatusText = "DON KORUMA ISITIYOR • ${it.frostStopC}°C HEDEF") }
                applyDemand(Demand("DON KORUMA", s.frostStopC, s.frostFanLevel))
                return
            }
        }

        // 3) Gece modu pencere içindeyse kontrolü alır.
        if (s.nightModeEnabled && isInsideWindow(nowMin, s.nightStartMinutes, s.nightEndMinutes)) {
            applyBandController("GECE", s.nightStartC, s.nightStopC, s.nightFanLevel)
            return
        }

        // 4) Haftalık program seçili gün + pencere içindeyse.
        if (s.weeklyProgramEnabled && day in s.weeklyDays && isInsideWindow(nowMin, s.weeklyStartMinutes, s.weeklyEndMinutes)) {
            applyBandController("HAFTALIK", s.weeklyStartC, s.weeklyStopC, s.weeklyFanLevel)
            return
        }

        // 5) Günlük program.
        if (s.dailyProgramEnabled && isInsideWindow(nowMin, s.dailyProgramStartMinutes, s.dailyProgramEndMinutes)) {
            applyBandController("GÜNLÜK", s.dailyProgramStartC, s.dailyProgramStopC, s.dailyProgramFanLevel)
            return
        }

        // 6) Genel termostat.
        if (s.thermostatEnabled) {
            applyThermostatController()
            return
        }

        // Otomasyon penceresi bitti: yalnızca otomasyonun kendisinin başlattığı çalışmayı durdur.
        // Elle başlatılan ısıtıcıya (autoOwner == null) asla dokunma.
        if (autoOwner != null) {
            autoOwner = null
            thermostatOwnsRun = false
            _uiState.update { it.copy(activeController = "YOK") }
            if (s.isHeaterOn) setHeaterPower(false)
        }
    }

    private fun applyBandController(controller: String, startC: Int, stopC: Int, fan: Int) {
        val s = _uiState.value
        when {
            // Stop only runs that an automation started.
            s.isHeaterOn && autoOwner != null && s.ambientTemperatureC >= stopC -> {
                autoOwner = null
                _uiState.update { it.copy(activeController = controller) }
                setHeaterPower(false)
            }
            !s.isHeaterOn && s.ambientTemperatureC <= startC -> applyDemand(Demand(controller, stopC, fan))
            s.isHeaterOn && autoOwner != null -> applyDemand(Demand(controller, stopC, fan))
            !s.isHeaterOn -> _uiState.update { it.copy(activeController = controller) }
            else -> Unit
        }
    }

    private fun thermostatStatus(text: String) {
        if (_uiState.value.thermostatStatusText != text) _uiState.update { it.copy(thermostatStatusText = text) }
    }

    /**
     * Thermostat: starts the heater whenever the measured temperature is AT OR BELOW the start threshold
     * (so 18 °C starts it when the threshold is 20 °C) and stops it again at the stop threshold.
     * The stop decision no longer depends on the "activeController" label, which the live heater status
     * kept overwriting with MANUEL/OTOMATİK, and the start command is re-sent at most every 8 seconds.
     */
    private fun applyThermostatController() {
        val s = _uiState.value
        val now = SystemClock.elapsedRealtime()
        val runElapsed = if (lastHeaterStartMs == 0L) Long.MAX_VALUE else now - lastHeaterStartMs
        val restElapsed = if (lastHeaterStopMs == 0L) Long.MAX_VALUE else now - lastHeaterStopMs
        val minRun = s.minimumRunMinutes * 60_000L
        val minRest = s.minimumRestMinutes * 60_000L
        val t = s.ambientTemperatureC
        val tTxt = "%.1f°C".format(t)
        when {
            !s.isHeaterOn && t <= s.thermostatStartC -> when {
                restElapsed < minRest ->
                    thermostatStatus("ÖLÇÜLEN $tTxt • MİN. BEKLEME SÜRESİ DOLUNCA BAŞLAR")
                !bleManager.isCommandChannelReady() ->
                    thermostatStatus("ÖLÇÜLEN $tTxt • BAŞLATMAK İÇİN BLUETOOTH BAĞLI OLMALI")
                now - lastThermostatCmdMs < 8_000L ->
                    thermostatStatus("ÖLÇÜLEN $tTxt ≤ ${s.thermostatStartC}°C • BAŞLATILIYOR")
                else -> {
                    lastThermostatCmdMs = now
                    thermostatOwnsRun = true
                    thermostatStatus("ÖLÇÜLEN $tTxt ≤ ${s.thermostatStartC}°C • BAŞLAT KOMUTU GÖNDERİLDİ")
                    applyDemand(Demand("TERMOSTAT", s.thermostatStopC, s.fanLevel))
                }
            }
            s.isHeaterOn && thermostatOwnsRun && t >= s.thermostatStopC -> {
                if (runElapsed >= minRun) {
                    thermostatOwnsRun = false
                    autoOwner = null
                    thermostatStatus("HEDEFE ULAŞTI ($tTxt) • DURDURULUYOR")
                    setHeaterPower(false)
                } else {
                    thermostatStatus("HEDEFE ULAŞTI ($tTxt) • MİN. ÇALIŞMA SÜRESİ BEKLENİYOR")
                }
            }
            s.isHeaterOn && thermostatOwnsRun ->
                thermostatStatus("ÇALIŞIYOR • $tTxt → ${s.thermostatStopC}°C'DE DURUR")
            s.isHeaterOn ->
                thermostatStatus("ISITICI ELLE ÇALIŞIYOR ($tTxt) • TERMOSTAT DURDURMAZ")
            else -> {
                thermostatOwnsRun = false
                if (autoOwner == "TERMOSTAT") autoOwner = null
                thermostatStatus("BEKLİYOR • ÖLÇÜLEN $tTxt • ${s.thermostatStartC}°C VE ALTINDA BAŞLAR")
            }
        }
    }

    /**
     * Applies what an automation wants. The program's fan level / target are written to the UI only at
     * start time and are then sent to the heater (once per change) instead of being forced into the UI
     * every second, which used to fight the live heater values (ÜFLEME 3/10 <-> 4/10 flicker).
     */
    private fun applyDemand(d: Demand) {
        val s = _uiState.value
        if (s.isHeaterOn) {
            if (autoOwner != null) {
                autoOwner = d.controller
                if (s.activeController != d.controller) _uiState.update { it.copy(activeController = d.controller) }
                pushDemandToHeater(d)
            } else if (d.controller == "TURBO") {
                pushDemandToHeater(d)
            }
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (now - lastAutoStartCmdMs < 8_000L) {
            if (s.activeController != d.controller) _uiState.update { it.copy(activeController = d.controller) }
            return
        }
        lastAutoStartCmdMs = now
        lastSentGear = -1
        lastSentTarget = -1
        autoOwner = d.controller
        _uiState.update { it.copy(activeController = d.controller, targetTemperatureC = d.targetC, fanLevel = d.fan) }
        setHeaterPower(true)
    }

    private fun pushDemandToHeater(d: Demand) {
        if (!bleManager.isCommandChannelReady()) return
        if (d.fan != lastSentGear && bleManager.sendTargetGear(d.fan)) lastSentGear = d.fan
        if (d.targetC != lastSentTarget && bleManager.sendTargetTemperature(d.targetC)) lastSentTarget = d.targetC
    }

    private fun setHeaterPower(on: Boolean) {
        val current = _uiState.value
        if (current.isHeaterOn == on) return
        // _24: gerçek cihaza komut gönder. Bağlantı yoksa yerel durumu değiştirme
        // (demo modu yok); gerçek durum canlı BLE paketlerinden gelir.
        if (!bleManager.sendPower(on)) return
        val now = SystemClock.elapsedRealtime()
        val justFinishedSeconds = if (!on && lastHeaterStartMs > 0L) {
            val realSeconds = ((now - lastHeaterStartMs) / 1000L).coerceAtLeast(1L)
            if (current.isDemoMode) realSeconds * 60L else realSeconds
        } else 0L
        if (on) lastHeaterStartMs = now else lastHeaterStopMs = now
        _uiState.update { s ->
            val event = HeaterEvent(
                timeLabel = eventTimeLabel(s),
                title = if (on) "ISITICI BAŞLADI" else "ISITICI DURDURULDU",
                detail = "${s.activeController} • hedef ${s.targetTemperatureC}°C • fan ${s.fanLevel}/10"
            )
            s.copy(
                isHeaterOn = on,
                statusText = if (on) "ATEŞLEME" else "SOĞUTMA",
                startCount = s.startCount + if (on) 1 else 0,
                lastRunSeconds = if (!on) justFinishedSeconds else s.lastRunSeconds,
                lastRunLabel = if (!on) formatDuration(justFinishedSeconds) else s.lastRunLabel,
                eventLog = (listOf(event) + s.eventLog).take(30)
            )
        }
    }

    private fun bindBleLiveStatus() {
        viewModelScope.launch {
            bleState.collect { ble ->
                val live = ble.liveStatus ?: return@collect
                val liveHeaterOn = live.machineState in setOf(1, 2, 3, 9)
                _uiState.update { current ->
                    current.copy(
                        isHeaterOn = liveHeaterOn,
                        isFanMode = live.machineState == 8,
                        fanModeMessage = if (live.machineState == 8 || current.isFanMode) "" else current.fanModeMessage,
                        ambientTemperatureC = live.ambientC,
                        targetTemperatureC = live.targetTemperatureC.takeIf { it in 5..40 } ?: current.targetTemperatureC,
                        fanLevel = live.targetGear.takeIf { it in 1..10 } ?: current.fanLevel,
                        fanRpm = live.fanRpm,
                        batteryVoltage = live.batteryVoltage,
                        pumpHz = live.pumpHz,
                        heaterShellC = live.heaterShellC,
                        outletTemperatureC = live.outletC,
                        heaterAltitudeMeters = live.altitudeM.takeIf { it in 0..7999 },
                        altitudeMeters = current.gpsAltitudeMeters ?: live.altitudeM.takeIf { it in 0..7999 },
                        statusText = live.machineStateText,
                        coolingStartedAtMs = if (live.machineState == 4) {
                            if (current.coolingStartedAtMs == 0L) SystemClock.elapsedRealtime() else current.coolingStartedAtMs
                        } else 0L,
                        activeController = when (live.machineState) {
                            4 -> "SOĞUTMA"
                            6 -> "HATA"
                            else -> autoOwner ?: when (live.machineState) {
                                2 -> "OTOMATİK"
                                3 -> "MANUEL"
                                9 -> "START-STOP"
                                else -> current.activeController
                            }
                        }
                    )
                }
            }
        }
    }

    /**
     * _15: Demo modu kaldırıldı. Bu döngü artık sıcaklık/akü/pompa gibi değerleri
     * yapay olarak değiştirmez; sadece gerçek çalışma süresini, Turbo sayacını ve
     * geçmiş örneklerini canlı durum üzerinden günceller.
     */
    private fun startRuntimeLoop() {
        viewModelScope.launch {
            while (isActive) {
                delay(1_000)
                _uiState.update { s ->
                    val ticked = if (s.boostEnabled && s.boostRemainingSeconds > 0) {
                        val remain = (s.boostRemainingSeconds - 1).coerceAtLeast(0)
                        s.copy(boostRemainingSeconds = remain, boostEnabled = remain > 0)
                    } else s

                    val runSecondsAdded = if (ticked.isHeaterOn) 1L else 0L
                    val estimatedLitersPerHour = 0.08f + ticked.fanLevel * 0.027f
                    val fuelAdded = if (ticked.isHeaterOn) estimatedLitersPerHour / 3600f else 0f
                    val nextIndex = ticked.historySampleIndex + 1
                    val sample = TemperatureSample(nextIndex, ticked.ambientTemperatureC, ticked.isHeaterOn)
                    ticked.copy(
                        totalRunSeconds = ticked.totalRunSeconds + runSecondsAdded,
                        estimatedFuelLiters = ticked.estimatedFuelLiters + fuelAdded,
                        minRecordedTemperatureC = min(ticked.minRecordedTemperatureC, ticked.ambientTemperatureC),
                        maxRecordedTemperatureC = max(ticked.maxRecordedTemperatureC, ticked.ambientTemperatureC),
                        historySamples = (ticked.historySamples + sample).takeLast(120),
                        historySampleIndex = nextIndex
                    )
                }
                evaluateAutomation()
                checkBatteryAlarm()
                weatherTick++
                if (weatherTick % 1800 == 0) refreshWeather()
            }
        }
    }

    private fun eventTimeLabel(s: HeaterUiState): String {
        return if (s.isDemoMode) {
            "${dayShort(s.demoDayOfWeek)} ${fmt(s.demoClockMinutes)}"
        } else {
            val t = LocalTime.now()
            "%02d:%02d".format(t.hour, t.minute)
        }
    }

    private fun dayShort(d: Int): String = listOf("Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz")[(d - 1).coerceIn(0, 6)]

    private fun currentMinutes(s: HeaterUiState): Int = if (s.isDemoMode) s.demoClockMinutes else LocalTime.now().let { it.hour * 60 + it.minute }
    private fun currentDay(s: HeaterUiState): Int = if (s.isDemoMode) s.demoDayOfWeek else LocalDate.now().dayOfWeek.value
    private fun isInsideWindow(now: Int, start: Int, end: Int): Boolean = when { start == end -> true; start < end -> now in start until end; else -> now >= start || now < end }
    private fun wrapMinutes(v: Int): Int = ((v % 1440) + 1440) % 1440
    private fun wrapDay(v: Int): Int = ((v - 1) % 7 + 7) % 7 + 1
    private fun fmt(m: Int): String = "%02d:%02d".format(m / 60, m % 60)
    private fun formatDuration(seconds: Long): String {
        val m = seconds / 60
        val h = m / 60
        val rem = m % 60
        return if (h > 0) "${h} sa ${rem} dk" else "${m.coerceAtLeast(1)} dk"
    }
    private fun dailyText(s: HeaterUiState, now: Int) = if (isInsideWindow(now, s.dailyProgramStartMinutes, s.dailyProgramEndMinutes)) "PENCERE AKTİF • ${fmt(s.dailyProgramEndMinutes)} SON" else "BEKLİYOR • ${fmt(s.dailyProgramStartMinutes)} BAŞLANGIÇ"
    private fun weeklyText(s: HeaterUiState, now: Int, day: Int) = if (day in s.weeklyDays && isInsideWindow(now, s.weeklyStartMinutes, s.weeklyEndMinutes)) "BUGÜN AKTİF • ${fmt(s.weeklyEndMinutes)} SON" else "SEÇİLİ GÜN/SAAT BEKLENİYOR"
    private fun nightText(s: HeaterUiState, now: Int) = if (isInsideWindow(now, s.nightStartMinutes, s.nightEndMinutes)) "SESSİZ GECE AKTİF" else "BEKLİYOR • ${fmt(s.nightStartMinutes)} BAŞLANGIÇ"

    override fun onCleared() {
        stopLocationUpdates()
        bleManager.stopScan()
        bleManager.disconnect()
        super.onCleared()
    }

}
