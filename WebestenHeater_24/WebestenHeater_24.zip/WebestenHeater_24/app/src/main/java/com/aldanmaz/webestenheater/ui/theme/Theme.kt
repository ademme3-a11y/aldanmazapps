package com.aldanmaz.webestenheater.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val HeaterDarkColors = darkColorScheme(
    primary = Color(0xFF2F80ED),
    secondary = Color(0xFF64B5FF),
    background = Color(0xFF0A0D10),
    surface = Color(0xFF11161B),
    onPrimary = Color(0xFFFFFFFF),
    onBackground = Color(0xFFF2F5F7),
    onSurface = Color(0xFFF2F5F7)
)

@Composable
fun WebestenHeaterTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = HeaterDarkColors,
        content = content
    )
}
