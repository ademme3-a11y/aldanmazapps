package com.aldanmaz.webestenheater

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Keeps the app process (and with it the thermostat, programs and Bluetooth link) alive while the screen is off
 * or the app is in the background. Shows a persistent notification, as Android requires.
 */
class KeepAliveService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Arka planda çalışma", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Termostat ve Bluetooth bağlantısının kapalı ekranda sürmesi için"
                    setShowBadge(false)
                }
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val n = buildNotification("Termostat ve Bluetooth bağlantısı aktif")
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            else startForeground(NOTIF_ID, n)
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "klon:heater").apply { setReferenceCounted(false); acquire() }
        }
        // Makes sure the heater logic is running even when the screen was never opened after a restart.
        val vm = appHeaterViewModel(application)
        scope.launch {
            while (isActive) {
                delay(30_000)
                val s = vm.uiState.value
                val live = vm.bleState.value.liveStatus
                val text = when {
                    live == null -> "Bluetooth bağlı değil • yeniden bağlanıyor"
                    s.isFanMode -> "Fan modu çalışıyor"
                    s.isHeaterOn -> "Isıtıcı çalışıyor • ortam %.1f°C → hedef %d°C".format(s.ambientTemperatureC, s.targetTemperatureC)
                    s.thermostatEnabled -> "Termostat bekliyor • ortam %.1f°C • %d°C ve altında başlar".format(s.ambientTemperatureC, s.thermostatStartC)
                    else -> "Bağlı • ortam %.1f°C".format(s.ambientTemperatureC)
                }
                getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
            }
        }
        return START_STICKY
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Klon Dizel Isıtıcı")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(open)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
        wakeLock = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "klon_keepalive"
        private const val NOTIF_ID = 4107
        private const val ACTION_STOP = "com.aldanmaz.webestenheater.STOP_KEEPALIVE"

        fun start(context: Context) {
            if (Build.VERSION.SDK_INT >= 31 &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
            ) return
            runCatching { ContextCompat.startForegroundService(context, Intent(context, KeepAliveService::class.java)) }
        }

        fun stop(context: Context) {
            runCatching { context.startService(Intent(context, KeepAliveService::class.java).setAction(ACTION_STOP)) }
        }
    }
}
