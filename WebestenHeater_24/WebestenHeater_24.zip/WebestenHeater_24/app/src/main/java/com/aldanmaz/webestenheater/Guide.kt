package com.aldanmaz.webestenheater

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Bump when the guide / disclaimer changes materially: everybody has to accept again. */
internal const val LEGAL_VERSION = 2
internal const val APP_VERSION_TEXT = "36.1"
private const val LEGAL_PREFS = "klon_legal"

internal fun legalAccepted(ctx: Context): Boolean =
    ctx.getSharedPreferences(LEGAL_PREFS, Context.MODE_PRIVATE).getInt("accepted_version", 0) >= LEGAL_VERSION

internal fun saveLegalAccepted(ctx: Context) {
    val stamp = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr", "TR")).format(Date())
    ctx.getSharedPreferences(LEGAL_PREFS, Context.MODE_PRIVATE).edit()
        .putInt("accepted_version", LEGAL_VERSION).putString("accepted_at", stamp).apply()
}

private val gAccent = Color(0xFF58A6FF)
private val gSoft = Color(0xFFB2BEC7)
private val gCard = Color(0xFF0F151A)
private val gLine = Color(0xFF17466D)
private val gBad = Color(0xFFFF6B6B)

private class GuideSection(val title: String, val lines: List<String>, val danger: Boolean = false)

private val guideSections: List<GuideSection> = listOf(
    GuideSection(
        "ACİL DURUM: ISITICIYI NASIL DURDURURUM?",
        listOf(
            "1) Ana sayfada DURDUR düğmesine basın.",
            "2) Uygulama yanıt vermiyorsa veya Bluetooth yoksa ısıtıcının üzerindeki kendi düğmesini kullanın ya da ısıtıcının güç sigortasını çekin / akü bağlantısını kesin. Bu yolları önceden öğrenin.",
            "3) Duman, yakıt kokusu, alevin dışarı çıkması veya anormal ses varsa hemen gücü kesin, kapalı alandan çıkın, havalandırın, gerekirse 112'yi arayın.",
            "Not: Normal durdurmada ısıtıcı birkaç dakika soğutma fanı çalıştırır. Acil durum dışında bu sırada gücü kesmeyin."
        ),
        danger = true
    ),
    GuideSection(
        "TEHLİKELER VE RİSKLER (LÜTFEN OKUYUN)",
        listOf(
            "• Karbonmonoksit (CO) zehirlenmesi: Egzoz ve yanma havası girişi dışarıya açılmalı, kaçak olmamalı. Kapalı garajda, çadırda veya havasız yerde çalıştırmayın. Aracın / karavanın içinde CO alarmı bulundurun. Uyurken özellikle risklidir.",
            "• Yangın: Perde, yatak, yakıt kabı, gaz tüpü, elektronik eşya ve yanıcı maddeleri ısıtıcıdan ve egzoz borusundan uzak tutun. Egzoz ve gövde çok sıcak olur.",
            "• Yakıt: Yalnızca ısıtıcı üreticisinin önerdiği yakıtı (dizel) kullanın. Benzin ve diğer yakıtları kullanmayın. Yakıt sızıntısını düzenli kontrol edin. Depo doldururken ısıtıcı kapalı ve soğuk olmalı.",
            "• Gözetimsiz çalışma: Termostat, program ve Don koruma, siz yokken ısıtıcıyı kendiliğinden başlatabilir. Çocuk, hayvan, uyuyan kişi veya evde olmadığınız durumlarda riski siz üstlenirsiniz. İlk kullanımda ısıtıcıyı başında izleyin.",
            "• Bluetooth kopması: Bluetooth koptuğunda ısıtıcı kendiliğinden durmaz, çalışmaya devam eder (test edildi). Uygulama o sırada durdurma komutu gönderemez. Telefon kapanır, şarjı biter, menzil dışına çıkar veya Android uygulamayı kapatırsa hedefte durdurma ve termostat çalışmaz.",
            "• Yazılım sınırları: Uygulama hatalı çalışabilir. Sıcaklık ısıtıcının kendi sensöründen okunur ve gerçek oda sıcaklığından sapabilir. Yakıt, kW, maliyet, hava durumu ve harita değerleri tahmindir, kesin değildir. Yakıt tahminine güvenip yakıtsız kalmayın.",
            "• Akü: Isıtıcı ve pompa aküyü boşaltır. Düşük voltajda ısıtıcı hata verip durabilir. Motor kapalıyken uzun çalıştırmada akünüzü kontrol edin.",
            "• Hata kodları: Aynı hata tekrar tekrar çıkıyorsa ısıtıcıyı çalıştırmayı bırakın, Hata Kodları sayfasına bakın, gerekirse yetkili servise başvurun.",
            "• Deneysel özellikler (ısıtıcı mod testi, fan modu, güç kademesi, kalibrasyon): Isıtıcınızın modeline göre farklı davranabilir. Yalnızca başında ve güvenli ortamda deneyin.",
            "• Bu uygulama ısıtıcı üreticisinin resmi uygulaması değildir. Üreticinin kullanım kılavuzu ve güvenlik uyarıları her zaman önceliklidir."
        ),
        danger = true
    ),
    GuideSection(
        "BU UYGULAMA NE YAPAR?",
        listOf(
            "• Telefonunuzdan Bluetooth ile ısıtıcıyı başlatır, durdurur ve sıcaklık, akü, pompa, yakıt gibi değerleri gösterir.",
            "• Asıl işi ısıtıcının kendi kontrol ünitesi yapar. Uygulama ona komut gönderir ve izler. Isıtıcının kendi güvenlik korumalarının yerine geçmez."
        )
    ),
    GuideSection(
        "İLK KURULUM",
        listOf(
            "1) Telefonun Bluetooth'unu açın. Uygulamanın istediği Bluetooth, konum ve bildirim izinlerini verin.",
            "2) Ayarlar > BLUETOOTH / GERÇEK CİHAZ sayfasında ısıtıcıyı tarayıp seçin. Sonraki açılışlarda son cihaza kendiliğinden bağlanır.",
            "3) Ana sayfada sol üstteki BLUETOOTH kutusu 'Bağlı' yazınca hazırsınız.",
            "4) Ayarlar > YAKIT AYARLARI bölümünde depo büyüklüğünü ve depodaki yakıtı girin.",
            "5) Ayarlar'da 'Uygulama arka planda' seçeneğini açık tutun ve pil optimizasyonundan uygulamayı muaf tutun. Aksi halde Android uygulamayı kapatabilir."
        )
    ),
    GuideSection(
        "ANA SAYFA",
        listOf(
            "• BLUETOOTH: Bağlantı durumu. Dokununca Bluetooth sayfası açılır.",
            "• FAN MODU: Isıtıcı yanmazken yalnızca fan çalıştırır (havalandırma). Isıtıcı yanıyorsa anahtar kapalıdır.",
            "• DEPO: Kalan yakıt. 5 saniyede bir toplam çalışma süresi ve toplam yakıt da gösterilir. Kalan 1,5 Lt altına inince kırmızı yanıp söner. Dokununca Yakıt Analizi açılır.",
            "• UYG ARKA PLANDA: Yeşilse uygulama kapalıyken de ısıtıcıyı izler ve termostat çalışır. Kapalıyken gridir. Dokununca açılır / kapanır.",
            "• İÇ ORTAM SICAKLIĞI: Isıtıcının ölçtüğü sıcaklık. Köşelerde saat/tarih ve rakım yer alır. Karta dokununca bulunduğunuz yer uzaydan gösterilir. HEDEF SICAKLIK − ve + ile ayarlanır.",
            "• ISITICI DURUMU: BAŞLAT / DURDUR düğmesi ve ÜFLEME (kademe) kaydırıcısı.",
            "• AKÜ, POMPA, DIŞ SICAKLIK, KASA: Akü voltajı, yakıt pompası frekansı, dış sıcaklık (internetten konumunuza göre, sensör değildir) ve ısıtıcı gövde sıcaklığı."
        )
    ),
    GuideSection(
        "BAŞLAT / DURDUR VE HEDEFTE DURMA",
        listOf(
            "• BAŞLAT ısıtıcıyı çalıştırır. Önce ATEŞLEME aşaması gelir, normal yanma birkaç dakika sonra başlar.",
            "• DURDUR komutundan sonra ısıtıcı soğutma yapar, bu sırada fan çalışır.",
            "• 'Hedefte durdur' (Ayarlar'da, varsayılan açık): Elle başlattığınızda ortam sıcaklığı hedefe ulaşıp bir dakika boyunca hedefin altına inmezse ve ısıtıcı en az 2 dakikadır çalışıyorsa uygulama DURDUR komutu gönderir.",
            "• Bunun çalışması için Bluetooth bağlı olmalı ve uygulama çalışıyor olmalıdır.",
            "• Isıtıcının kendi 'Otomatik' modu hedefte kapanmaz, yalnızca gücü kısar. Hedefte durma bu yüzden uygulamaya bağlıdır."
        )
    ),
    GuideSection(
        "TERMOSTAT (KENDİLİĞİNDEN BAŞLA - DUR)",
        listOf(
            "• Termostat sayfasından açılır. Varsayılan olarak KAPALIDIR.",
            "• Ortam sıcaklığı başlatma eşiğine veya altına inince ısıtıcıyı başlatır, durdurma eşiğine ulaşınca durdurur.",
            "• Ana sayfadaki hedef sıcaklığı değiştirince durdurma eşiği hedef, başlatma eşiği hedeften 4°C aşağısı olur (başlatma farkı Ayarlar'dan değişir).",
            "• Minimum çalışma ve bekleme süreleri sık açıp kapatmayı önler.",
            "• Termostat yalnızca kendi başlattığı çalışmayı durdurur. Elle başlattığınız çalışmayı 'hedefte durdur' kuralı durdurur.",
            "• Çalışması için: Bluetooth bağlı, uygulama açık veya arka planda çalışıyor, telefon açık ve ısıtıcıya yakın olmalı.",
            "• Uzun süreli kesintisiz çalışma, bu sürümde cihaz üzerinde tam döngüyle uzun süre denenmemiştir. Gözetimsiz bırakmadan önce yakından izleyin."
        )
    ),
    GuideSection(
        "ÖZEL MODLAR VE PROGRAMLAR",
        listOf(
            "• Program: Günlük ve haftalık saat aralıklarında ısıtıcıyı sıcaklık eşiklerine göre çalıştırır.",
            "• Gece modu: Belirlediğiniz saat aralığında ayrı eşikler ve kademe kullanır.",
            "• Turbo: Belirli süre en yüksek kademede çalıştırır.",
            "• Don koruma: Ortam sıcaklığı belirlenen değere düşünce kendiliğinden ısıtır.",
            "• Fan modu: Yakıt yakmadan üfleme.",
            "Bu özelliklerin hepsi ısıtıcıyı sizin yerinize başlatabilir. 'Gözetimsiz çalışma' uyarısını okuyun."
        )
    ),
    GuideSection(
        "BLUETOOTH KOPARSA NE OLUR?",
        listOf(
            "• Isıtıcı çalışmaya devam eder, kendiliğinden durmaz (Bluetooth kapatılarak denendi).",
            "• Uygulama en geç yaklaşık 30 saniyede 'Bağlı değil' gösterir ve bağlantı gelene kadar sürekli yeniden bağlanmayı dener.",
            "• Bağlantı gelene kadar hiçbir komut, durdurma dahil, gönderilemez.",
            "• Gözetimsiz bırakırken telefonun yakında, Bluetooth'un açık ve telefonun şarjda olduğundan emin olun."
        )
    ),
    GuideSection(
        "YAKIT, KW VE MALİYET",
        listOf(
            "• Yakıt tüketimi ölçülmez, pompa frekansından hesaplanır (Hz × ml/vuruş). Bu bir tahmindir.",
            "• Depoyu doldurunca Ayarlar > YAKIT AYARLARI'nda DEPOYU DOLDUR'a basın. Doğruluk için gerçek tüketimle karşılaştırıp ml/vuruş değerini düzeltin.",
            "• Isıtma gücü (kW) ısıtıcıdan okunmaz. Pompa frekansından tahmin edilir. Ayarlar > ISITMA GÜCÜ kartında anma gücünü girip tam güçte kalibre edebilirsiniz.",
            "• Dizel fiyatı internetten alınır, alınamazsa elle girilir. Maliyetler yaklaşıktır."
        )
    ),
    GuideSection(
        "DİĞER SAYFALAR",
        listOf(
            "• Hava durumu: Uyarılar, 6 saat ve 5 günlük tahmin. Güneş paneli: Gündüz bulut ve güneşlenme.",
            "• Uzaydan görünüm: Konumunuzun uydu görüntüsü ve canlı bulut / yağış. İnternet gerekir.",
            "• Hata kodları ve çözümler: Isıtıcı hata verince nedenini ve ne yapacağınızı gösterir.",
            "• Yakıt analizi, Geçmiş: Günlük ve toplam çalışma, yakıt ve maliyet."
        )
    ),
    GuideSection(
        "SORUN GİDERME",
        listOf(
            "• Bağlanamıyor: Telefonun Bluetooth'u açık mı, izinler verilmiş mi, ısıtıcı başka bir telefona bağlı mı kontrol edin. Ayarlar > Bluetooth sayfasından yeniden tarayın.",
            "• Termostat başlatmıyor: Bluetooth bağlı mı, termostat açık mı, minimum bekleme süresi doldu mu bakın. Durum yazısı nedenini söyler.",
            "• Dış sıcaklık görünmüyor: Konum izni ve internet gerekir.",
            "• Yakıt değeri uymuyor: Depoyu doldurduğunuzu girin ve ml/vuruş değerini ayarlayın."
        )
    )
)

private const val DISCLAIMER_TEXT =
    "Bu uygulamayı kullanarak şunları kabul etmiş olursunuz:\n\n" +
        "1) Uygulama 'olduğu gibi' sunulur, hiçbir garanti verilmez. Hatasız, kesintisiz veya her ısıtıcı modelinde aynı çalışacağı vaat edilmez.\n\n" +
        "2) Isıtıcının montajı, egzoz ve hava girişi güvenliği, yakıt sistemi, bakımı, kullanım yeri ve gözetimi tamamen sizin sorumluluğunuzdadır.\n\n" +
        "3) Isıtıcıyı gözetimsiz veya otomatik çalıştırmanın (termostat, program, Don koruma) risklerini kabul edersiniz.\n\n" +
        "4) Geliştirici, uygulamanın kullanımından veya kullanılamamasından doğan her türlü yaralanma, ölüm, yangın, karbonmonoksit zehirlenmesi, araç, ısıtıcı veya mal hasarı, yakıt kaybı, akü boşalması ve diğer zararlardan, yasaların izin verdiği ölçüde sorumlu tutulamaz.\n\n" +
        "5) Üreticinin kullanım kılavuzu, güvenlik uyarıları ve yerel mevzuat bu uygulamanın her bilgisinden önceliklidir.\n\n" +
        "6) Bu uygulama ısıtıcı üreticisinin resmi uygulaması değildir; bağımsız olarak geliştirilmiştir.\n\n" +
        "7) Bu uygulama bireysel (kişisel) kullanım içindir. Geliştirici Mehmet Aldanmaz'ın yazılı izni olmadan ticari amaçla çoğaltılamaz, satılamaz, dağıtılamaz, değiştirilerek veya değiştirilmeden yeniden yayımlanamaz. Tüm hakları saklıdır. © 2026 Mehmet Aldanmaz.\n\n" +
        "8) 18 yaşından büyük olduğunuzu ve bu metni okuyup anladığınızı beyan edersiniz."

@Composable
private fun GuideCard(sec: GuideSection) {
    val border = if (sec.danger) gBad else gLine
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.fillMaxWidth().background(gCard, shape).border(1.dp, border, shape).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(sec.title, color = if (sec.danger) gBad else gAccent, fontWeight = FontWeight.Black, fontSize = 15.sp)
        sec.lines.forEach { Text(it, color = Color(0xFFE3EAF0), fontSize = 13.sp, lineHeight = 18.sp) }
    }
}

/** Settings item 1: user guide, risks and the accepted disclaimer. */
@Composable
internal fun GuideContent() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences(LEGAL_PREFS, Context.MODE_PRIVATE) }
    val at = prefs.getString("accepted_at", null)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Sürüm $APP_VERSION_TEXT", color = gSoft, fontSize = 12.sp)
        Text(
            if (at != null) "Sorumluluk beyanı onaylandı: $at" else "Sorumluluk beyanı henüz onaylanmadı",
            color = if (at != null) Color(0xFF4CD08A) else gBad, fontWeight = FontWeight.Bold, fontSize = 13.sp
        )
        guideSections.forEach { GuideCard(it) }
        GuideCard(GuideSection("SORUMLULUK BEYANI", DISCLAIMER_TEXT.split("\n\n"), danger = true))
    }
}

/** Shown on first launch (and whenever LEGAL_VERSION is raised); cannot be dismissed without a decision. */
@Composable
internal fun LegalDialog(onAccept: () -> Unit, onDecline: () -> Unit) {
    var checked by remember { mutableStateOf(false) }
    val maxH = (LocalConfiguration.current.screenHeightDp * 0.42f).dp
    AlertDialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
        title = { Text("GÜVENLİK VE SORUMLULUK BEYANI", fontWeight = FontWeight.Black, fontSize = 16.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.heightIn(max = maxH).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        "Dizel ısıtıcı yangın ve karbonmonoksit zehirlenmesi riski taşır. Bluetooth koparsa ısıtıcı kendiliğinden durmaz. " +
                            "Tam kılavuz: Ayarlar > 1. Kullanım kılavuzu.",
                        color = gBad, fontWeight = FontWeight.Bold, fontSize = 13.sp
                    )
                    Text(DISCLAIMER_TEXT, fontSize = 12.sp, lineHeight = 16.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = checked, onCheckedChange = { checked = it })
                    Text("Okudum, anladım, kabul ediyorum.", fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp))
                }
            }
        },
        confirmButton = { Button(onClick = onAccept, enabled = checked) { Text("KABUL EDİYORUM") } },
        dismissButton = { OutlinedButton(onClick = onDecline) { Text("KABUL ETMİYORUM (ÇIK)") } }
    )
}

// ---- Integrity: warn when the APK was re-signed by somebody else (cannot stop a determined attacker, but raises the bar) ----
private const val EXPECTED_CERT_SHA256 = "E42658365FD132D8FF56D3EADD388916F956445FDAC7B128C4956200B57BB520"

/** true = original signature, false = different signature, null = could not be determined. */
internal fun signatureOk(ctx: Context): Boolean? = try {
    val pm = ctx.packageManager
    val sigs = if (android.os.Build.VERSION.SDK_INT >= 28) {
        pm.getPackageInfo(ctx.packageName, android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES).signingInfo?.apkContentsSigners
    } else {
        @Suppress("DEPRECATION")
        pm.getPackageInfo(ctx.packageName, android.content.pm.PackageManager.GET_SIGNATURES).signatures
    }
    if (sigs.isNullOrEmpty()) null
    else sigs.all { s ->
        val hex = java.security.MessageDigest.getInstance("SHA-256").digest(s.toByteArray())
            .joinToString("") { "%02X".format(it.toInt() and 0xFF) }
        hex == EXPECTED_CERT_SHA256
    }
} catch (_: Exception) { null }

@Composable
internal fun TamperDialog(onContinue: () -> Unit, onExit: () -> Unit) {
    AlertDialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
        title = { Text("UYARI: ORİJİNAL OLMAYAN KOPYA", fontWeight = FontWeight.Black, fontSize = 16.sp, color = gBad) },
        text = {
            Text(
                "Bu uygulama geliştiricinin orijinal imzasıyla yüklenmemiş. Değiştirilmiş veya kötü niyetli bir kopya olabilir ve ısıtıcınızı tehlikeli komutlarla çalıştırabilir. " +
                    "Uygulamayı kaldırın ve yalnızca geliştiriciden aldığınız dosyayı yükleyin.",
                fontSize = 13.sp
            )
        },
        confirmButton = { Button(onClick = onExit) { Text("ÇIK") } },
        dismissButton = { OutlinedButton(onClick = onContinue) { Text("RİSKİ ANLADIM, DEVAM") } }
    )
}
