package com.aldanmaz.webestenheater

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.animation.core.animateFloat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aldanmaz.webestenheater.ble.HeaterLiveStatus
import com.aldanmaz.webestenheater.model.HeaterUiState
import com.aldanmaz.webestenheater.weather.AlertLevel
import com.aldanmaz.webestenheater.weather.SolarDay
import com.aldanmaz.webestenheater.weather.WeatherRepository
import com.aldanmaz.webestenheater.weather.WeatherUiState
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit

private val cardColor = Color(0xFF0F1A24)
private val lineColor = Color(0xFF17466D)
private val accent = Color(0xFF58A6FF)
private val soft = Color(0xFF9FB0BD)
private val good = Color(0xFF4CD08A)
private val warnColor = Color(0xFFFFB84D)
private val badColor = Color(0xFFFF6B6B)

@Composable
private fun Panel(modifier: Modifier = Modifier, border: Color = lineColor, bg: Color = cardColor, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .fillMaxWidth()
            .background(bg, shape)
            .border(1.dp, border, shape)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) { content() }
}

@Composable
private fun SectionTitle(text: String, sub: String? = null) {
    Column(Modifier.padding(top = 4.dp)) {
        Text(text, color = accent, fontWeight = FontWeight.Black, fontSize = 14.sp)
        if (sub != null) Text(sub, color = soft, fontSize = 11.sp)
    }
}

private fun hhmm(t: LocalDateTime) = "%02d:%02d".format(t.hour, t.minute)

// ---------------------------------------------------------------------------------------------- weather

@Composable
private fun WeatherStatusPanel(w: WeatherUiState, onRefresh: () -> Unit, onRequestLocation: () -> Unit) {
    Panel {
        when {
            w.loading && w.data == null -> Text("Hava durumu yükleniyor…", color = Color.White, fontSize = 14.sp)
            !w.locationKnown && w.data == null -> {
                Text("Konum bekleniyor", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(
                    "Bulunduğunuz yerin hava durumu için konum izni gerekir. Konum yalnızca hava verisi almak için kullanılır.",
                    color = soft, fontSize = 12.sp
                )
                Button(onClick = onRequestLocation) { Text("KONUMU AÇ") }
            }
            w.error != null && w.data == null -> {
                Text("Hava verisi alınamadı", color = badColor, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(w.error, color = soft, fontSize = 12.sp)
                Text("İnternet bağlantınızı kontrol edin.", color = soft, fontSize = 12.sp)
                Button(onClick = onRefresh) { Text("TEKRAR DENE") }
            }
        }
    }
}

@Composable
private fun AlertPanels(w: WeatherUiState) {
    if (w.data == null) return
    if (w.alerts.isEmpty()) {
        Panel(border = good) {
            Text("✔ Önümüzdeki 24 saatte uyarı yok", color = good, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Ani soğuma, don, fırtına veya şiddetli yağış beklenmiyor.", color = soft, fontSize = 12.sp)
        }
        return
    }
    w.alerts.forEach { a ->
        val c = if (a.level == AlertLevel.WARNING) badColor else warnColor
        Panel(border = c, bg = c.copy(alpha = 0.10f)) {
            Text((if (a.level == AlertLevel.WARNING) "⚠ " else "ℹ ") + a.title, color = c, fontWeight = FontWeight.Black, fontSize = 14.sp)
            Text(a.detail, color = Color.White, fontSize = 12.sp)
        }
    }
}

@Composable
internal fun WeatherContent(w: WeatherUiState, onRefresh: () -> Unit, onRequestLocation: () -> Unit) {
    WeatherStatusPanel(w, onRefresh, onRequestLocation)
    val data = w.data ?: return

    SectionTitle("UYARILAR", "Önümüzdeki 24 saat için hesaplanır")
    AlertPanels(w)

    val cur = data.current
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(WeatherRepository.icon(cur.code, cur.isDay), fontSize = 40.sp)
            Column(Modifier.weight(1f)) {
                Text("%.0f°C".format(cur.tempC), color = Color.White, fontWeight = FontWeight.Black, fontSize = 30.sp)
                Text("${WeatherRepository.describe(cur.code)} • hissedilen %.0f°C".format(cur.feelsC), color = soft, fontSize = 12.sp)
            }
        }
        Text(
            "Bulut %%${cur.cloud} • Nem %%${cur.humidity} • Yağış %.1f mm • Rüzgâr %.0f km/sa (hamle %.0f)".format(cur.precipMm, cur.windKmh, cur.gustKmh),
            color = soft, fontSize = 12.sp
        )
    }

    SectionTitle("ÖNÜMÜZDEKİ 6 SAAT", "Bulut katmanları ve yağış ayrıntısı")
    WeatherRepository.upcomingHours(data, 6).forEach { h ->
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(hhmm(h.time), color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp, modifier = Modifier.width(52.dp))
                Text(WeatherRepository.icon(h.code, h.isDay), fontSize = 24.sp)
                Text("%.0f°C".format(h.tempC), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Text(WeatherRepository.describe(h.code), color = soft, fontSize = 11.sp)
            }
            Text(
                "Bulut %${h.cloud}  (alçak %${h.cloudLow} • orta %${h.cloudMid} • yüksek %${h.cloudHigh})",
                color = soft, fontSize = 11.sp
            )
            val snow = if (h.snowCm > 0.05f) " • kar %.1f cm".format(h.snowCm) else ""
            Text(
                "Yağış ihtimali %%${h.precipProb} • %.1f mm$snow • rüzgâr %.0f km/sa (hamle %.0f)".format(h.precipMm, h.windKmh, h.gustKmh),
                color = soft, fontSize = 11.sp
            )
        }
    }

    SectionTitle("ÖNÜMÜZDEKİ 5 GÜN")
    WeatherRepository.nextDays(data, 5).forEach { d ->
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(WeatherRepository.dayName(d.date), color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    Text(WeatherRepository.describe(d.code), color = soft, fontSize = 11.sp)
                }
                Text(WeatherRepository.icon(d.code, true), fontSize = 24.sp)
                Text("%.0f° / %.0f°".format(d.tMaxC, d.tMinC), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
            Text(
                "Yağış %.1f mm (olasılık en çok %%${d.precipProbMax}) • rüzgâr hamlesi %.0f km/sa".format(d.precipMm, d.gustMaxKmh),
                color = soft, fontSize = 11.sp
            )
        }
    }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            (if (w.updatedAtLabel.isNotBlank()) "Güncelleme: ${w.updatedAtLabel}\n" else "") + "Veri: Open-Meteo.com",
            color = soft, fontSize = 11.sp, modifier = Modifier.weight(1f)
        )
        OutlinedButton(onClick = onRefresh) { Text(if (w.loading) "…" else "YENİLE") }
    }
    if (w.error != null) Text("Son yenileme başarısız: ${w.error}", color = warnColor, fontSize = 11.sp)
    Text(
        "Uyarılar yalnızca uygulama açıkken hesaplanır; arka planda bildirim gönderilmez.",
        color = soft, fontSize = 10.sp
    )
}

// ---------------------------------------------------------------------------------------------- solar

private fun ratingColor(rating: String): Color = when (rating) {
    "ÇOK İYİ" -> good
    "İYİ" -> Color(0xFF9BE15D)
    "ORTA" -> warnColor
    else -> badColor
}

@Composable
private fun ScoreBar(score: Int, color: Color) {
    val shape = RoundedCornerShape(5.dp)
    Box(Modifier.fillMaxWidth().height(8.dp).background(Color(0xFF1B2A38), shape)) {
        Box(Modifier.fillMaxWidth(score.coerceIn(2, 100) / 100f).height(8.dp).background(color, shape))
    }
}

@Composable
private fun SolarDayPanel(d: SolarDay, title: String) {
    val c = ratingColor(d.rating)
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Text("☀ ${hhmm(d.sunrise)} – ${hhmm(d.sunset)}  (%.1f saat gün ışığı)".format(d.daylightHours), color = soft, fontSize = 11.sp)
            }
            Text(d.rating, color = c, fontWeight = FontWeight.Black, fontSize = 14.sp)
        }
        ScoreBar(d.score, c)
        Text(
            "Ortalama bulut %%${d.meanCloud} • güneşlenme %.1f saat • ışınım %.1f kWh/m²".format(d.sunshineHours, d.radiationKwhM2),
            color = Color.White, fontSize = 12.sp
        )
        val snow = if (d.snowCm > 0.05f) " • kar %.1f cm".format(d.snowCm) else ""
        Text("Gündüz yağışı %.1f mm$snow".format(d.precipMm), color = Color.White, fontSize = 12.sp)
        Text(WeatherRepository.solarNote(d), color = soft, fontSize = 11.sp)
    }
}

@Composable
internal fun SolarContent(w: WeatherUiState, onRefresh: () -> Unit, onRequestLocation: () -> Unit) {
    WeatherStatusPanel(w, onRefresh, onRequestLocation)
    val data = w.data ?: return
    val days = WeatherRepository.solarDays(data)
    val now = data.current.time
    val today = days.firstOrNull { it.date == now.toLocalDate() }

    Panel {
        Text("Yalnızca gün doğumu ile batımı arası değerlendirilir; gece değeri gösterilmez.", color = soft, fontSize = 11.sp)
        val daylightNow = today != null && now.isAfter(today.sunrise) && now.isBefore(today.sunset)
        if (daylightNow && today != null) {
            val hourNow = WeatherRepository.upcomingHours(data, 1).firstOrNull()
            Text("ŞU AN: GÜNDÜZ", color = good, fontWeight = FontWeight.Black, fontSize = 14.sp)
            Text(
                "Bulut %%${data.current.cloud} • yağış %.1f mm".format(data.current.precipMm) +
                    (hourNow?.let { " • ışınım %.0f W/m² (${WeatherRepository.hourRating(it.radiationWm2)})".format(it.radiationWm2) } ?: ""),
                color = Color.White, fontSize = 13.sp
            )
            val left = ChronoUnit.MINUTES.between(now, today.sunset).coerceAtLeast(0)
            Text("Gün batımına ${left / 60} sa ${left % 60} dk kaldı.", color = soft, fontSize = 12.sp)
        } else {
            val nextSunrise = data.daily.map { it.sunrise }.firstOrNull { it.isAfter(now) }
            Text("ŞU AN: GECE — panel üretimi yok", color = warnColor, fontWeight = FontWeight.Black, fontSize = 14.sp)
            if (nextSunrise != null) Text("Gün doğumu: ${hhmm(nextSunrise)}", color = Color.White, fontSize = 13.sp)
        }
    }

    SectionTitle("ÖNÜMÜZDEKİ 6 GÜNDÜZ SAATİ", "Gece saatleri atlanır")
    val hours = WeatherRepository.nextDaylightHours(data, 6)
    if (hours.isEmpty()) {
        Panel { Text("Tahmin aralığında gündüz saati yok.", color = soft, fontSize = 12.sp) }
    }
    hours.forEach { h ->
        val rating = WeatherRepository.hourRating(h.radiationWm2)
        val c = when (rating) {
            "Güçlü" -> good
            "Orta" -> Color(0xFF9BE15D)
            "Zayıf" -> warnColor
            else -> badColor
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val dayTag = if (h.time.toLocalDate() == now.toLocalDate()) "" else " (yarın)"
                Text(hhmm(h.time) + dayTag, color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("%.0f W/m²".format(h.radiationWm2), color = Color.White, fontSize = 13.sp)
                Text(rating, color = c, fontWeight = FontWeight.Black, fontSize = 13.sp)
            }
            ScoreBar((h.radiationWm2 / 8f).toInt(), c)
            Text(
                "Bulut %%${h.cloud} (alçak %%${h.cloudLow} • orta %%${h.cloudMid} • yüksek %%${h.cloudHigh}) • yağış ihtimali %%${h.precipProb} • %.1f mm".format(h.precipMm),
                color = soft, fontSize = 11.sp
            )
        }
    }

    SectionTitle("5 GÜNLÜK GÜNEŞ DURUMU", "Gün doğumu – batımı aralığı")
    today?.let { SolarDayPanel(it, "Bugün") }
    days.filter { it.date.isAfter(now.toLocalDate()) }.take(5).forEach { d ->
        SolarDayPanel(d, WeatherRepository.dayName(d.date))
    }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            (if (w.updatedAtLabel.isNotBlank()) "Güncelleme: ${w.updatedAtLabel}\n" else "") + "Veri: Open-Meteo.com",
            color = soft, fontSize = 11.sp, modifier = Modifier.weight(1f)
        )
        OutlinedButton(onClick = onRefresh) { Text(if (w.loading) "…" else "YENİLE") }
    }
    Text(
        "Puan, güneşlenme süresinin gün ışığı süresine oranıdır. Panel eğimi, gölge ve kirlilik hesaba katılmaz.",
        color = soft, fontSize = 10.sp
    )
}

// ---------------------------------------------------------------------------------------------- faults

@Composable
private fun FaultCard(f: FaultInfo, active: Boolean, expandedByDefault: Boolean) {
    var open by rememberSaveable(f.code) { mutableStateOf(expandedByDefault) }
    val c = if (active) badColor else lineColor
    Panel(
        modifier = Modifier.clickable { open = !open },
        border = c,
        bg = if (active) badColor.copy(alpha = 0.10f) else cardColor
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(f.code, color = if (active) badColor else accent, fontWeight = FontWeight.Black, fontSize = 15.sp)
            Text(f.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(if (open) "▲" else "▼", color = soft, fontSize = 12.sp)
        }
        if (open) {
            Text(f.meaning, color = Color.White, fontSize = 12.sp)
            Text("ÇÖZÜM", color = good, fontWeight = FontWeight.Black, fontSize = 11.sp)
            f.solutions.forEachIndexed { i, step ->
                Text("${i + 1}. $step", color = soft, fontSize = 12.sp)
            }
        }
    }
}

@Composable
internal fun FaultsContent(s: HeaterUiState, live: HeaterLiveStatus?) {
    val mask = live?.errorMask ?: 0
    val plus = live?.errorPlus ?: 0
    val active = ErrorCatalog.active(mask, plus)

    when {
        live == null -> Panel {
            Text("Isıtıcı bağlı değil", color = warnColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Bağlandığında etkin hata kodları burada görünür. Aşağıda tüm hata kodları ve çözümleri var.", color = soft, fontSize = 12.sp)
        }
        mask == 0 -> Panel(border = good) {
            Text("✔ Etkin hata yok", color = good, fontWeight = FontWeight.Black, fontSize = 15.sp)
            Text("Isıtıcı hata bildirmiyor.", color = soft, fontSize = 12.sp)
        }
        else -> {
            Text("ETKİN HATA${if (active.size > 1) "LAR" else ""}", color = badColor, fontWeight = FontWeight.Black, fontSize = 14.sp)
            Text("Kod: 0x%04X • alt kod: %d".format(mask, plus), color = soft, fontSize = 11.sp)
            if (active.isEmpty()) {
                Panel(border = badColor) {
                    Text("Bilinmeyen hata kodu 0x%04X".format(mask), color = badColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Isıtıcıyı durdurun ve yetkili servise danışın.", color = soft, fontSize = 12.sp)
                }
            }
            active.forEach { FaultCard(it, active = true, expandedByDefault = true) }
        }
    }

    if (s.errorLog.isNotEmpty()) {
        SectionTitle("SON HATA KAYITLARI")
        s.errorLog.take(5).forEach { e ->
            Panel { Text("${e.timeLabel} • ${e.title}", color = Color.White, fontSize = 12.sp); Text(e.detail, color = soft, fontSize = 11.sp) }
        }
    }

    SectionTitle("TÜM HATA KODLARI", "Dokunarak açıp kapatın")
    val activeCodes = active.map { it.code }.toSet()
    ErrorCatalog.all.forEach { f ->
        if (f.code !in activeCodes) FaultCard(f, active = false, expandedByDefault = false)
    }

    SectionTitle("GENEL ÖNERİLER")
    Panel {
        ErrorCatalog.generalTips.forEach { Text("• $it", color = soft, fontSize = 12.sp) }
    }
}

// ---------------------------------------------------------------------------------------------- fan mode and alerts

@Composable
internal fun FanModeCard(s: HeaterUiState, connected: Boolean, onToggle: () -> Unit) {
    Panel(border = if (s.isFanMode) good else lineColor) {
        Text("FAN MODU (HAVALANDIRMA)", color = accent, fontWeight = FontWeight.Black, fontSize = 15.sp)
        Text(
            "Yakıt yakmadan yalnızca fanı çalıştırır. Yaz aylarında araç veya kabin içini havalandırmak için kullanın.",
            color = soft, fontSize = 12.sp
        )
        Text(
            when {
                s.isFanMode -> "DURUM: AKTİF • fan çalışıyor"
                !connected -> "DURUM: ısıtıcı bağlı değil"
                s.isHeaterOn -> "DURUM: ısıtıcı çalışıyor, önce durdurun"
                else -> "DURUM: kapalı"
            },
            color = if (s.isFanMode) good else Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp
        )
        Button(onClick = onToggle, enabled = connected && (s.isFanMode || !s.isHeaterOn)) {
            Text(if (s.isFanMode) "FAN MODUNU DURDUR" else "FAN MODUNU BAŞLAT")
        }
        if (s.fanModeMessage.isNotBlank()) Text(s.fanModeMessage, color = warnColor, fontSize = 11.sp)
        Text("Fan modu açıkken termostat ve programlar ısıtıcıyı başlatmaz.", color = soft, fontSize = 10.sp)
    }
}

@Composable
internal fun AlertSettingsCard(beepEnabled: Boolean, onBeepChange: (Boolean) -> Unit, onTestBeep: () -> Unit) {
    Panel {
        Text("DÜŞÜK VOLTAJ UYARISI", color = accent, fontWeight = FontWeight.Black, fontSize = 14.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Bip bip sesli uyarı", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("12 V: 11.8 V altı düşük, 11.0 V altı kritik. 24 V: 23.6 V / 22.0 V.", color = soft, fontSize = 11.sp)
            }
            Switch(checked = beepEnabled, onCheckedChange = onBeepChange)
        }
        OutlinedButton(onClick = onTestBeep) { Text("SESİ DENE") }
        Spacer(Modifier.height(2.dp))
    }
}

// ---------------------------------------------------------------------------------------------- sky backdrop (home)

internal data class SkyInfo(val cloud: Int, val raining: Boolean, val snowing: Boolean, val radiation: Float, val label: String)

/** Daylight-only sky state; null at night or without data (the panel then keeps its plain look). */
internal fun skyInfo(w: WeatherUiState): SkyInfo? {
    val d = w.data ?: return null
    val now = LocalDateTime.now()
    val day = d.daily.firstOrNull { it.date == now.toLocalDate() } ?: return null
    if (!(now.isAfter(day.sunrise) && now.isBefore(day.sunset))) return null
    val c = d.current
    val rad = WeatherRepository.upcomingHours(d, 1).firstOrNull()?.radiationWm2 ?: 0f
    val snow = c.code in setOf(71, 73, 75, 77, 85, 86)
    val rain = !snow && (c.precipMm > 0.1f || c.code in 51..67 || c.code in 80..82 || c.code >= 95)
    return SkyInfo(c.cloud, rain, snow, rad, WeatherRepository.hourRating(rad))
}

@Composable
internal fun Modifier.skyBackdrop(info: SkyInfo?, shape: androidx.compose.ui.graphics.Shape): Modifier {
    if (info == null) return this
    val tr = androidx.compose.animation.core.rememberInfiniteTransition(label = "sky")
    val t by tr.animateFloat(
        0f, 1f,
        androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(60000, easing = androidx.compose.animation.core.LinearEasing)),
        label = "skyT"
    )
    val pulse by tr.animateFloat(
        0.85f, 1f,
        androidx.compose.animation.core.infiniteRepeatable(
            androidx.compose.animation.core.tween(3000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "sunPulse"
    )
    val fall by tr.animateFloat(
        0f, 1f,
        androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(1100, easing = androidx.compose.animation.core.LinearEasing)),
        label = "fall"
    )
    return this.clip(shape).drawBehind {
        val w = size.width
        val h = size.height
        val cf = (info.cloud / 100f).coerceIn(0f, 1f)
        val wet = if (info.raining || info.snowing) 0.45f else 0f
        fun mix(a: Color, b: Color, f: Float) = androidx.compose.ui.graphics.lerp(a, b, f.coerceIn(0f, 1f))
        val top = mix(mix(Color(0xFF2E8BE0), Color(0xFF6C7A88), cf), Color(0xFF3A4550), wet)
        val bottom = mix(mix(Color(0xFF7CC4F5), Color(0xFF55616D), cf), Color(0xFF2E3842), wet)
        drawRect(Brush.verticalGradient(listOf(top, bottom)))

        // Sun with slowly turning rays; fades out as the sky closes up.
        if (cf < 0.9f && !info.raining) {
            val a = (1f - cf * 0.95f).coerceIn(0.1f, 1f)
            val center = Offset(w * 0.82f, h * 0.30f)
            val r = minOf(w, h) * 0.13f * pulse
            drawCircle(Color(0xFFFFE27A).copy(alpha = 0.35f * a), r * 2.6f, center)
            rotate(t * 360f * 2f, center) {
                for (i in 0 until 10) {
                    val ang = Math.toRadians(i * 36.0)
                    val s0 = Offset(center.x + (r * 1.25f * kotlin.math.cos(ang)).toFloat(), center.y + (r * 1.25f * kotlin.math.sin(ang)).toFloat())
                    val s1 = Offset(center.x + (r * 1.85f * kotlin.math.cos(ang)).toFloat(), center.y + (r * 1.85f * kotlin.math.sin(ang)).toFloat())
                    drawLine(Color(0xFFFFE27A).copy(alpha = 0.8f * a), s0, s1, strokeWidth = r * 0.12f, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                }
            }
            drawCircle(Color(0xFFFFD84D).copy(alpha = a), r, center)
        }

        // Drifting clouds, count follows the real cloud cover.
        val n = if (info.cloud < 10) 0 else (cf * 5f).toInt().coerceIn(1, 5)
        val cloudColor = mix(Color.White, Color(0xFFC9D1D8), cf).copy(alpha = 0.55f + 0.25f * cf)
        for (i in 0 until n) {
            val x = ((t * (1f + i * 0.15f) + i / n.toFloat()) % 1f) * (w * 1.6f) - w * 0.3f
            val y = h * (0.12f + 0.55f * (((i * 37) % 100) / 100f))
            val u = minOf(w, h) * (0.16f + 0.03f * (i % 3))
            drawCircle(cloudColor, u * 0.55f, Offset(x, y))
            drawCircle(cloudColor, u * 0.7f, Offset(x + u * 0.6f, y - u * 0.15f))
            drawCircle(cloudColor, u * 0.5f, Offset(x + u * 1.2f, y))
            drawRoundRect(cloudColor, Offset(x - u * 0.3f, y), androidx.compose.ui.geometry.Size(u * 1.8f, u * 0.55f), androidx.compose.ui.geometry.CornerRadius(u * 0.27f))
        }

        // Rain streaks / snow flakes.
        if (info.raining) {
            for (k in 0 until 30) {
                val x = (((k * 53) % 100) / 100f) * w
                val y = ((fall + k * 0.071f) % 1f) * h
                drawLine(Color(0xFFB5D8FF).copy(alpha = 0.65f), Offset(x, y), Offset(x - 4f, y + 14f), strokeWidth = 1.6f)
            }
        } else if (info.snowing) {
            for (k in 0 until 24) {
                val x = (((k * 53) % 100) / 100f) * w + kotlin.math.sin((fall + k) * 6.28f).toFloat() * 6f
                val y = ((fall * 0.6f + k * 0.083f) % 1f) * h
                drawCircle(Color.White.copy(alpha = 0.85f), 2.2f, Offset(x, y))
            }
        }
        // Keep the foreground text readable.
        drawRect(Color(0xFF041220).copy(alpha = 0.38f))
    }
}

@Composable
internal fun SkyChip(info: SkyInfo, modifier: Modifier = Modifier) {
    val text = when {
        info.raining -> "🌧 Yağış • bulut %${info.cloud}"
        info.snowing -> "❄ Kar • bulut %${info.cloud}"
        else -> "☀ Güneş: ${info.label} • bulut %${info.cloud}"
    }
    Text(
        text, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = modifier
            .background(Color(0x66000000), RoundedCornerShape(8.dp))
            .padding(horizontal = 5.dp, vertical = 2.dp)
    )
}
