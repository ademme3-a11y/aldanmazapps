package com.aldanmaz.webestenheater

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aldanmaz.webestenheater.ble.HeaterLiveStatus
import com.aldanmaz.webestenheater.model.HeaterUiState
import com.aldanmaz.webestenheater.weather.AlertLevel
import com.aldanmaz.webestenheater.weather.SolarDay
import com.aldanmaz.webestenheater.weather.WeatherRepository
import com.aldanmaz.webestenheater.weather.WeatherUiState
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit

private val cardColor = Color(0xFF0F1A24)
private val lineColor = Color(0xFF17466D)
private val accent = Color(0xFF58A6FF)
private val soft = Color(0xFF9FB0BD)
private val good = Color(0xFF4CD08A)
private val warnColor = Color(0xFFFFB84D)
private val badColor = Color(0xFFFF6B6B)

@Composable
private fun Panel(modifier: Modifier = Modifier, border: Color = lineColor, bg: Color = cardColor, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .fillMaxWidth()
            .background(bg, shape)
            .border(1.dp, border, shape)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) { content() }
}

@Composable
private fun SectionTitle(text: String, sub: String? = null) {
    Column(Modifier.padding(top = 4.dp)) {
        Text(text, color = accent, fontWeight = FontWeight.Black, fontSize = 14.sp)
        if (sub != null) Text(sub, color = soft, fontSize = 11.sp)
    }
}

private fun hhmm(t: LocalDateTime) = "%02d:%02d".format(t.hour, t.minute)

// ---------------------------------------------------------------------------------------------- weather

@Composable
private fun WeatherStatusPanel(w: WeatherUiState, onRefresh: () -> Unit, onRequestLocation: () -> Unit) {
    Panel {
        when {
            w.loading && w.data == null -> Text("Hava durumu yükleniyor…", color = Color.White, fontSize = 14.sp)
            !w.locationKnown && w.data == null -> {
                Text("Konum bekleniyor", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(
                    "Bulunduğunuz yerin hava durumu için konum izni gerekir. Konum yalnızca hava verisi almak için kullanılır.",
                    color = soft, fontSize = 12.sp
                )
                Button(onClick = onRequestLocation) { Text("KONUMU AÇ") }
            }
            w.error != null && w.data == null -> {
                Text("Hava verisi alınamadı", color = badColor, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(w.error, color = soft, fontSize = 12.sp)
                Text("İnternet bağlantınızı kontrol edin.", color = soft, fontSize = 12.sp)
                Button(onClick = onRefresh) { Text("TEKRAR DENE") }
            }
        }
    }
}

@Composable
private fun AlertPanels(w: WeatherUiState) {
    if (w.data == null) return
    if (w.alerts.isEmpty()) {
        Panel(border = good) {
            Text("✔ Önümüzdeki 24 saatte uyarı yok", color = good, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Ani soğuma, don, fırtına veya şiddetli yağış beklenmiyor.", color = soft, fontSize = 12.sp)
        }
        return
    }
    w.alerts.forEach { a ->
        val c = if (a.level == AlertLevel.WARNING) badColor else warnColor
        Panel(border = c, bg = c.copy(alpha = 0.10f)) {
            Text((if (a.level == AlertLevel.WARNING) "⚠ " else "ℹ ") + a.title, color = c, fontWeight = FontWeight.Black, fontSize = 14.sp)
            Text(a.detail, color = Color.White, fontSize = 12.sp)
        }
    }
}

@Composable
internal fun WeatherContent(w: WeatherUiState, onRefresh: () -> Unit, onRequestLocation: () -> Unit) {
    WeatherStatusPanel(w, onRefresh, onRequestLocation)
    val data = w.data ?: return

    SectionTitle("UYARILAR", "Önümüzdeki 24 saat için hesaplanır")
    AlertPanels(w)

    val cur = data.current
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(WeatherRepository.icon(cur.code, cur.isDay), fontSize = 40.sp)
            Column(Modifier.weight(1f)) {
                Text("%.0f°C".format(cur.tempC), color = Color.White, fontWeight = FontWeight.Black, fontSize = 30.sp)
                Text("${WeatherRepository.describe(cur.code)} • hissedilen %.0f°C".format(cur.feelsC), color = soft, fontSize = 12.sp)
            }
        }
        Text(
            "Bulut %%${cur.cloud} • Nem %%${cur.humidity} • Yağış %.1f mm • Rüzgâr %.0f km/sa (hamle %.0f)".format(cur.precipMm, cur.windKmh, cur.gustKmh),
            color = soft, fontSize = 12.sp
        )
    }

    SectionTitle("ÖNÜMÜZDEKİ 6 SAAT", "Bulut katmanları ve yağış ayrıntısı")
    WeatherRepository.upcomingHours(data, 6).forEach { h ->
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(hhmm(h.time), color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp, modifier = Modifier.width(52.dp))
                Text(WeatherRepository.icon(h.code, h.isDay), fontSize = 24.sp)
                Text("%.0f°C".format(h.tempC), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Text(WeatherRepository.describe(h.code), color = soft, fontSize = 11.sp)
            }
            Text(
                "Bulut %${h.cloud}  (alçak %${h.cloudLow} • orta %${h.cloudMid} • yüksek %${h.cloudHigh})",
                color = soft, fontSize = 11.sp
            )
            val snow = if (h.snowCm > 0.05f) " • kar %.1f cm".format(h.snowCm) else ""
            Text(
                "Yağış ihtimali %%${h.precipProb} • %.1f mm$snow • rüzgâr %.0f km/sa (hamle %.0f)".format(h.precipMm, h.windKmh, h.gustKmh),
                color = soft, fontSize = 11.sp
            )
        }
    }

    SectionTitle("ÖNÜMÜZDEKİ 5 GÜN")
    WeatherRepository.nextDays(data, 5).forEach { d ->
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(WeatherRepository.dayName(d.date), color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    Text(WeatherRepository.describe(d.code), color = soft, fontSize = 11.sp)
                }
                Text(WeatherRepository.icon(d.code, true), fontSize = 24.sp)
                Text("%.0f° / %.0f°".format(d.tMaxC, d.tMinC), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
            Text(
                "Yağış %.1f mm (olasılık en çok %%${d.precipProbMax}) • rüzgâr hamlesi %.0f km/sa".format(d.precipMm, d.gustMaxKmh),
                color = soft, fontSize = 11.sp
            )
        }
    }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            (if (w.updatedAtLabel.isNotBlank()) "Güncelleme: ${w.updatedAtLabel}\n" else "") + "Veri: Open-Meteo.com",
            color = soft, fontSize = 11.sp, modifier = Modifier.weight(1f)
        )
        OutlinedButton(onClick = onRefresh) { Text(if (w.loading) "…" else "YENİLE") }
    }
    if (w.error != null) Text("Son yenileme başarısız: ${w.error}", color = warnColor, fontSize = 11.sp)
    Text(
        "Uyarılar yalnızca uygulama açıkken hesaplanır; arka planda bildirim gönderilmez.",
        color = soft, fontSize = 10.sp
    )
}

// ---------------------------------------------------------------------------------------------- solar

private fun ratingColor(rating: String): Color = when (rating) {
    "ÇOK İYİ" -> good
    "İYİ" -> Color(0xFF9BE15D)
    "ORTA" -> warnColor
    else -> badColor
}

@Composable
private fun ScoreBar(score: Int, color: Color) {
    val shape = RoundedCornerShape(5.dp)
    Box(Modifier.fillMaxWidth().height(8.dp).background(Color(0xFF1B2A38), shape)) {
        Box(Modifier.fillMaxWidth(score.coerceIn(2, 100) / 100f).height(8.dp).background(color, shape))
    }
}

@Composable
private fun SolarDayPanel(d: SolarDay, title: String) {
    val c = ratingColor(d.rating)
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Text("☀ ${hhmm(d.sunrise)} – ${hhmm(d.sunset)}  (%.1f saat gün ışığı)".format(d.daylightHours), color = soft, fontSize = 11.sp)
            }
            Text(d.rating, color = c, fontWeight = FontWeight.Black, fontSize = 14.sp)
        }
        ScoreBar(d.score, c)
        Text(
            "Ortalama bulut %%${d.meanCloud} • güneşlenme %.1f saat • ışınım %.1f kWh/m²".format(d.sunshineHours, d.radiationKwhM2),
            color = Color.White, fontSize = 12.sp
        )
        val snow = if (d.snowCm > 0.05f) " • kar %.1f cm".format(d.snowCm) else ""
        Text("Gündüz yağışı %.1f mm$snow".format(d.precipMm), color = Color.White, fontSize = 12.sp)
        Text(WeatherRepository.solarNote(d), color = soft, fontSize = 11.sp)
    }
}

@Composable
internal fun SolarContent(w: WeatherUiState, onRefresh: () -> Unit, onRequestLocation: () -> Unit) {
    WeatherStatusPanel(w, onRefresh, onRequestLocation)
    val data = w.data ?: return
    val days = WeatherRepository.solarDays(data)
    val now = data.current.time
    val today = days.firstOrNull { it.date == now.toLocalDate() }

    Panel {
        Text("Yalnızca gün doğumu ile batımı arası değerlendirilir; gece değeri gösterilmez.", color = soft, fontSize = 11.sp)
        val daylightNow = today != null && now.isAfter(today.sunrise) && now.isBefore(today.sunset)
        if (daylightNow && today != null) {
            val hourNow = WeatherRepository.upcomingHours(data, 1).firstOrNull()
            Text("ŞU AN: GÜNDÜZ", color = good, fontWeight = FontWeight.Black, fontSize = 14.sp)
            Text(
                "Bulut %%${data.current.cloud} • yağış %.1f mm".format(data.current.precipMm) +
                    (hourNow?.let { " • ışınım %.0f W/m² (${WeatherRepository.hourRating(it.radiationWm2)})".format(it.radiationWm2) } ?: ""),
                color = Color.White, fontSize = 13.sp
            )
            val left = ChronoUnit.MINUTES.between(now, today.sunset).coerceAtLeast(0)
            Text("Gün batımına ${left / 60} sa ${left % 60} dk kaldı.", color = soft, fontSize = 12.sp)
        } else {
            val nextSunrise = data.daily.map { it.sunrise }.firstOrNull { it.isAfter(now) }
            Text("ŞU AN: GECE — panel üretimi yok", color = warnColor, fontWeight = FontWeight.Black, fontSize = 14.sp)
            if (nextSunrise != null) Text("Gün doğumu: ${hhmm(nextSunrise)}", color = Color.White, fontSize = 13.sp)
        }
    }

    SectionTitle("ÖNÜMÜZDEKİ 6 GÜNDÜZ SAATİ", "Gece saatleri atlanır")
    val hours = WeatherRepository.nextDaylightHours(data, 6)
    if (hours.isEmpty()) {
        Panel { Text("Tahmin aralığında gündüz saati yok.", color = soft, fontSize = 12.sp) }
    }
    hours.forEach { h ->
        val rating = WeatherRepository.hourRating(h.radiationWm2)
        val c = when (rating) {
            "Güçlü" -> good
            "Orta" -> Color(0xFF9BE15D)
            "Zayıf" -> warnColor
            else -> badColor
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val dayTag = if (h.time.toLocalDate() == now.toLocalDate()) "" else " (yarın)"
                Text(hhmm(h.time) + dayTag, color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("%.0f W/m²".format(h.radiationWm2), color = Color.White, fontSize = 13.sp)
                Text(rating, color = c, fontWeight = FontWeight.Black, fontSize = 13.sp)
            }
            ScoreBar((h.radiationWm2 / 8f).toInt(), c)
            Text(
                "Bulut %%${h.cloud} (alçak %%${h.cloudLow} • orta %%${h.cloudMid} • yüksek %%${h.cloudHigh}) • yağış ihtimali %%${h.precipProb} • %.1f mm".format(h.precipMm),
                color = soft, fontSize = 11.sp
            )
        }
    }

    SectionTitle("5 GÜNLÜK GÜNEŞ DURUMU", "Gün doğumu – batımı aralığı")
    today?.let { SolarDayPanel(it, "Bugün") }
    days.filter { it.date.isAfter(now.toLocalDate()) }.take(5).forEach { d ->
        SolarDayPanel(d, WeatherRepository.dayName(d.date))
    }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            (if (w.updatedAtLabel.isNotBlank()) "Güncelleme: ${w.updatedAtLabel}\n" else "") + "Veri: Open-Meteo.com",
            color = soft, fontSize = 11.sp, modifier = Modifier.weight(1f)
        )
        OutlinedButton(onClick = onRefresh) { Text(if (w.loading) "…" else "YENİLE") }
    }
    Text(
        "Puan, güneşlenme süresinin gün ışığı süresine oranıdır. Panel eğimi, gölge ve kirlilik hesaba katılmaz.",
        color = soft, fontSize = 10.sp
    )
}

// ---------------------------------------------------------------------------------------------- faults

@Composable
private fun FaultCard(f: FaultInfo, active: Boolean, expandedByDefault: Boolean) {
    var open by rememberSaveable(f.code) { mutableStateOf(expandedByDefault) }
    val c = if (active) badColor else lineColor
    Panel(
        modifier = Modifier.clickable { open = !open },
        border = c,
        bg = if (active) badColor.copy(alpha = 0.10f) else cardColor
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(f.code, color = if (active) badColor else accent, fontWeight = FontWeight.Black, fontSize = 15.sp)
            Text(f.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(if (open) "▲" else "▼", color = soft, fontSize = 12.sp)
        }
        if (open) {
            Text(f.meaning, color = Color.White, fontSize = 12.sp)
            Text("ÇÖZÜM", color = good, fontWeight = FontWeight.Black, fontSize = 11.sp)
            f.solutions.forEachIndexed { i, step ->
                Text("${i + 1}. $step", color = soft, fontSize = 12.sp)
            }
        }
    }
}

@Composable
internal fun FaultsContent(s: HeaterUiState, live: HeaterLiveStatus?) {
    val mask = live?.errorMask ?: 0
    val plus = live?.errorPlus ?: 0
    val active = ErrorCatalog.active(mask, plus)

    when {
        live == null -> Panel {
            Text("Isıtıcı bağlı değil", color = warnColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Bağlandığında etkin hata kodları burada görünür. Aşağıda tüm hata kodları ve çözümleri var.", color = soft, fontSize = 12.sp)
        }
        mask == 0 -> Panel(border = good) {
            Text("✔ Etkin hata yok", color = good, fontWeight = FontWeight.Black, fontSize = 15.sp)
            Text("Isıtıcı hata bildirmiyor.", color = soft, fontSize = 12.sp)
        }
        else -> {
            Text("ETKİN HATA${if (active.size > 1) "LAR" else ""}", color = badColor, fontWeight = FontWeight.Black, fontSize = 14.sp)
            Text("Kod: 0x%04X • alt kod: %d".format(mask, plus), color = soft, fontSize = 11.sp)
            if (active.isEmpty()) {
                Panel(border = badColor) {
                    Text("Bilinmeyen hata kodu 0x%04X".format(mask), color = badColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Isıtıcıyı durdurun ve yetkili servise danışın.", color = soft, fontSize = 12.sp)
                }
            }
            active.forEach { FaultCard(it, active = true, expandedByDefault = true) }
        }
    }

    if (s.errorLog.isNotEmpty()) {
        SectionTitle("SON HATA KAYITLARI")
        s.errorLog.take(5).forEach { e ->
            Panel { Text("${e.timeLabel} • ${e.title}", color = Color.White, fontSize = 12.sp); Text(e.detail, color = soft, fontSize = 11.sp) }
        }
    }

    SectionTitle("TÜM HATA KODLARI", "Dokunarak açıp kapatın")
    val activeCodes = active.map { it.code }.toSet()
    ErrorCatalog.all.forEach { f ->
        if (f.code !in activeCodes) FaultCard(f, active = false, expandedByDefault = false)
    }

    SectionTitle("GENEL ÖNERİLER")
    Panel {
        ErrorCatalog.generalTips.forEach { Text("• $it", color = soft, fontSize = 12.sp) }
    }
}

// ---------------------------------------------------------------------------------------------- fan mode and alerts

@Composable
internal fun FanModeCard(s: HeaterUiState, connected: Boolean, onToggle: () -> Unit) {
    Panel(border = if (s.isFanMode) good else lineColor) {
        Text("FAN MODU (HAVALANDIRMA)", color = accent, fontWeight = FontWeight.Black, fontSize = 15.sp)
        Text(
            "Yakıt yakmadan yalnızca fanı çalıştırır. Yaz aylarında araç veya kabin içini havalandırmak için kullanın.",
            color = soft, fontSize = 12.sp
        )
        Text(
            when {
                s.isFanMode -> "DURUM: AKTİF • fan çalışıyor"
                !connected -> "DURUM: ısıtıcı bağlı değil"
                s.isHeaterOn -> "DURUM: ısıtıcı çalışıyor, önce durdurun"
                else -> "DURUM: kapalı"
            },
            color = if (s.isFanMode) good else Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp
        )
        Button(onClick = onToggle, enabled = connected && (s.isFanMode || !s.isHeaterOn)) {
            Text(if (s.isFanMode) "FAN MODUNU DURDUR" else "FAN MODUNU BAŞLAT")
        }
        if (s.fanModeMessage.isNotBlank()) Text(s.fanModeMessage, color = warnColor, fontSize = 11.sp)
        Text("Fan modu açıkken termostat ve programlar ısıtıcıyı başlatmaz.", color = soft, fontSize = 10.sp)
    }
}

@Composable
internal fun AlertSettingsCard(beepEnabled: Boolean, onBeepChange: (Boolean) -> Unit, onTestBeep: () -> Unit) {
    Panel {
        Text("DÜŞÜK VOLTAJ UYARISI", color = accent, fontWeight = FontWeight.Black, fontSize = 14.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Bip bip sesli uyarı", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("12 V: 11.8 V altı düşük, 11.0 V altı kritik. 24 V: 23.6 V / 22.0 V.", color = soft, fontSize = 11.sp)
            }
            Switch(checked = beepEnabled, onCheckedChange = onBeepChange)
        }
        OutlinedButton(onClick = onTestBeep) { Text("SESİ DENE") }
        Spacer(Modifier.height(2.dp))
    }
}
