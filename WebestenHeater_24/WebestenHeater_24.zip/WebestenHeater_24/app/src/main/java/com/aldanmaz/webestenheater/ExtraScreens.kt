package com.aldanmaz.webestenheater

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import com.aldanmaz.webestenheater.fuel.FuelState
import com.aldanmaz.webestenheater.fuel.formatRun
import com.aldanmaz.webestenheater.fuel.formatTl
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.animation.core.animateFloat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aldanmaz.webestenheater.ble.HeaterLiveStatus
import com.aldanmaz.webestenheater.model.HeaterUiState
import com.aldanmaz.webestenheater.weather.AlertLevel
import com.aldanmaz.webestenheater.weather.SolarDay
import com.aldanmaz.webestenheater.weather.WeatherRepository
import com.aldanmaz.webestenheater.weather.WeatherUiState
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit

private val cardColor = Color(0xFF0F1A24)
private val lineColor = Color(0xFF17466D)
private val accent = Color(0xFF58A6FF)
private val soft = Color(0xFF9FB0BD)
private val good = Color(0xFF4CD08A)
private val warnColor = Color(0xFFFFB84D)
private val badColor = Color(0xFFFF6B6B)

@Composable
private fun Panel(modifier: Modifier = Modifier, border: Color = lineColor, bg: Color = cardColor, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .fillMaxWidth()
            .background(bg, shape)
            .border(1.dp, border, shape)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) { content() }
}

@Composable
private fun SectionTitle(text: String, sub: String? = null) {
    Column(Modifier.padding(top = 4.dp)) {
        Text(text, color = accent, fontWeight = FontWeight.Black, fontSize = 14.sp)
        if (sub != null) Text(sub, color = soft, fontSize = 11.sp)
    }
}

private fun hhmm(t: LocalDateTime) = "%02d:%02d".format(t.hour, t.minute)

// ---------------------------------------------------------------------------------------------- weather

@Composable
private fun WeatherStatusPanel(w: WeatherUiState, onRefresh: () -> Unit, onRequestLocation: () -> Unit) {
    Panel {
        when {
            w.loading && w.data == null -> Text("Hava durumu yükleniyor…", color = Color.White, fontSize = 14.sp)
            !w.locationKnown && w.data == null -> {
                Text("Konum bekleniyor", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(
                    "Bulunduğunuz yerin hava durumu için konum izni gerekir. Konum yalnızca hava verisi almak için kullanılır.",
                    color = soft, fontSize = 12.sp
                )
                Button(onClick = onRequestLocation) { Text("KONUMU AÇ") }
            }
            w.error != null && w.data == null -> {
                Text("Hava verisi alınamadı", color = badColor, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(w.error, color = soft, fontSize = 12.sp)
                Text("İnternet bağlantınızı kontrol edin.", color = soft, fontSize = 12.sp)
                Button(onClick = onRefresh) { Text("TEKRAR DENE") }
            }
        }
    }
}

@Composable
private fun AlertPanels(w: WeatherUiState) {
    if (w.data == null) return
    if (w.alerts.isEmpty()) {
        Panel(border = good) {
            Text("✔ Önümüzdeki 24 saatte uyarı yok", color = good, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Ani soğuma, don, fırtına veya şiddetli yağış beklenmiyor.", color = soft, fontSize = 12.sp)
        }
        return
    }
    w.alerts.forEach { a ->
        val c = if (a.level == AlertLevel.WARNING) badColor else warnColor
        Panel(border = c, bg = c.copy(alpha = 0.10f)) {
            Text((if (a.level == AlertLevel.WARNING) "⚠ " else "ℹ ") + a.title, color = c, fontWeight = FontWeight.Black, fontSize = 14.sp)
            Text(a.detail, color = Color.White, fontSize = 12.sp)
        }
    }
}

@Composable
internal fun WeatherContent(w: WeatherUiState, onRefresh: () -> Unit, onRequestLocation: () -> Unit) {
    WeatherStatusPanel(w, onRefresh, onRequestLocation)
    val data = w.data ?: return

    SectionTitle("UYARILAR", "Önümüzdeki 24 saat için hesaplanır")
    AlertPanels(w)

    val cur = data.current
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(WeatherRepository.icon(cur.code, cur.isDay), fontSize = 40.sp)
            Column(Modifier.weight(1f)) {
                Text("%.0f°C".format(cur.tempC), color = Color.White, fontWeight = FontWeight.Black, fontSize = 30.sp)
                Text("${WeatherRepository.describe(cur.code)} • hissedilen %.0f°C".format(cur.feelsC), color = soft, fontSize = 12.sp)
            }
        }
        Text(
            "Bulut %%${cur.cloud} • Nem %%${cur.humidity} • Yağış %.1f mm • Rüzgâr %.0f km/sa (hamle %.0f)".format(cur.precipMm, cur.windKmh, cur.gustKmh),
            color = soft, fontSize = 12.sp
        )
    }

    SectionTitle("ÖNÜMÜZDEKİ 6 SAAT", "Bulut katmanları ve yağış ayrıntısı")
    WeatherRepository.upcomingHours(data, 6).forEach { h ->
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(hhmm(h.time), color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp, modifier = Modifier.width(52.dp))
                Text(WeatherRepository.icon(h.code, h.isDay), fontSize = 24.sp)
                Text("%.0f°C".format(h.tempC), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Text(WeatherRepository.describe(h.code), color = soft, fontSize = 11.sp)
            }
            Text(
                "Bulut %${h.cloud}  (alçak %${h.cloudLow} • orta %${h.cloudMid} • yüksek %${h.cloudHigh})",
                color = soft, fontSize = 11.sp
            )
            val snow = if (h.snowCm > 0.05f) " • kar %.1f cm".format(h.snowCm) else ""
            Text(
                "Yağış ihtimali %%${h.precipProb} • %.1f mm$snow • rüzgâr %.0f km/sa (hamle %.0f)".format(h.precipMm, h.windKmh, h.gustKmh),
                color = soft, fontSize = 11.sp
            )
        }
    }

    SectionTitle("ÖNÜMÜZDEKİ 5 GÜN")
    WeatherRepository.nextDays(data, 5).forEach { d ->
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(WeatherRepository.dayName(d.date), color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    Text(WeatherRepository.describe(d.code), color = soft, fontSize = 11.sp)
                }
                Text(WeatherRepository.icon(d.code, true), fontSize = 24.sp)
                Text("%.0f° / %.0f°".format(d.tMaxC, d.tMinC), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
            Text(
                "Yağış %.1f mm (olasılık en çok %%${d.precipProbMax}) • rüzgâr hamlesi %.0f km/sa".format(d.precipMm, d.gustMaxKmh),
                color = soft, fontSize = 11.sp
            )
        }
    }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            (if (w.updatedAtLabel.isNotBlank()) "Güncelleme: ${w.updatedAtLabel}\n" else "") + "Veri: Open-Meteo.com",
            color = soft, fontSize = 11.sp, modifier = Modifier.weight(1f)
        )
        OutlinedButton(onClick = onRefresh) { Text(if (w.loading) "…" else "YENİLE") }
    }
    if (w.error != null) Text("Son yenileme başarısız: ${w.error}", color = warnColor, fontSize = 11.sp)
    Text(
        "Uyarılar yalnızca uygulama açıkken hesaplanır; arka planda bildirim gönderilmez.",
        color = soft, fontSize = 10.sp
    )
}

// ---------------------------------------------------------------------------------------------- solar

private fun ratingColor(rating: String): Color = when (rating) {
    "ÇOK İYİ" -> good
    "İYİ" -> Color(0xFF9BE15D)
    "ORTA" -> warnColor
    else -> badColor
}

@Composable
private fun ScoreBar(score: Int, color: Color) {
    val shape = RoundedCornerShape(5.dp)
    Box(Modifier.fillMaxWidth().height(8.dp).background(Color(0xFF1B2A38), shape)) {
        Box(Modifier.fillMaxWidth(score.coerceIn(2, 100) / 100f).height(8.dp).background(color, shape))
    }
}

@Composable
private fun SolarDayPanel(d: SolarDay, title: String) {
    val c = ratingColor(d.rating)
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Text("☀ ${hhmm(d.sunrise)} – ${hhmm(d.sunset)}  (%.1f saat gün ışığı)".format(d.daylightHours), color = soft, fontSize = 11.sp)
            }
            Text(d.rating, color = c, fontWeight = FontWeight.Black, fontSize = 14.sp)
        }
        ScoreBar(d.score, c)
        Text(
            "Ortalama bulut %%${d.meanCloud} • güneşlenme %.1f saat • ışınım %.1f kWh/m²".format(d.sunshineHours, d.radiationKwhM2),
            color = Color.White, fontSize = 12.sp
        )
        val snow = if (d.snowCm > 0.05f) " • kar %.1f cm".format(d.snowCm) else ""
        Text("Gündüz yağışı %.1f mm$snow".format(d.precipMm), color = Color.White, fontSize = 12.sp)
        Text(WeatherRepository.solarNote(d), color = soft, fontSize = 11.sp)
    }
}

@Composable
internal fun SolarContent(w: WeatherUiState, onRefresh: () -> Unit, onRequestLocation: () -> Unit) {
    WeatherStatusPanel(w, onRefresh, onRequestLocation)
    val data = w.data ?: return
    val days = WeatherRepository.solarDays(data)
    val now = data.current.time
    val today = days.firstOrNull { it.date == now.toLocalDate() }

    Panel {
        Text("Yalnızca gün doğumu ile batımı arası değerlendirilir; gece değeri gösterilmez.", color = soft, fontSize = 11.sp)
        val daylightNow = today != null && now.isAfter(today.sunrise) && now.isBefore(today.sunset)
        if (daylightNow && today != null) {
            val hourNow = WeatherRepository.upcomingHours(data, 1).firstOrNull()
            Text("ŞU AN: GÜNDÜZ", color = good, fontWeight = FontWeight.Black, fontSize = 14.sp)
            Text(
                "Bulut %%${data.current.cloud} • yağış %.1f mm".format(data.current.precipMm) +
                    (hourNow?.let { " • ışınım %.0f W/m² (${WeatherRepository.hourRating(it.radiationWm2)})".format(it.radiationWm2) } ?: ""),
                color = Color.White, fontSize = 13.sp
            )
            val left = ChronoUnit.MINUTES.between(now, today.sunset).coerceAtLeast(0)
            Text("Gün batımına ${left / 60} sa ${left % 60} dk kaldı.", color = soft, fontSize = 12.sp)
        } else {
            val nextSunrise = data.daily.map { it.sunrise }.firstOrNull { it.isAfter(now) }
            Text("ŞU AN: GECE — panel üretimi yok", color = warnColor, fontWeight = FontWeight.Black, fontSize = 14.sp)
            if (nextSunrise != null) Text("Gün doğumu: ${hhmm(nextSunrise)}", color = Color.White, fontSize = 13.sp)
        }
    }

    SectionTitle("ÖNÜMÜZDEKİ 6 GÜNDÜZ SAATİ", "Gece saatleri atlanır")
    val hours = WeatherRepository.nextDaylightHours(data, 6)
    if (hours.isEmpty()) {
        Panel { Text("Tahmin aralığında gündüz saati yok.", color = soft, fontSize = 12.sp) }
    }
    hours.forEach { h ->
        val rating = WeatherRepository.hourRating(h.radiationWm2)
        val c = when (rating) {
            "Güçlü" -> good
            "Orta" -> Color(0xFF9BE15D)
            "Zayıf" -> warnColor
            else -> badColor
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val dayTag = if (h.time.toLocalDate() == now.toLocalDate()) "" else " (yarın)"
                Text(hhmm(h.time) + dayTag, color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("%.0f W/m²".format(h.radiationWm2), color = Color.White, fontSize = 13.sp)
                Text(rating, color = c, fontWeight = FontWeight.Black, fontSize = 13.sp)
            }
            ScoreBar((h.radiationWm2 / 8f).toInt(), c)
            Text(
                "Bulut %%${h.cloud} (alçak %%${h.cloudLow} • orta %%${h.cloudMid} • yüksek %%${h.cloudHigh}) • yağış ihtimali %%${h.precipProb} • %.1f mm".format(h.precipMm),
                color = soft, fontSize = 11.sp
            )
        }
    }

    SectionTitle("5 GÜNLÜK GÜNEŞ DURUMU", "Gün doğumu – batımı aralığı")
    today?.let { SolarDayPanel(it, "Bugün") }
    days.filter { it.date.isAfter(now.toLocalDate()) }.take(5).forEach { d ->
        SolarDayPanel(d, WeatherRepository.dayName(d.date))
    }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            (if (w.updatedAtLabel.isNotBlank()) "Güncelleme: ${w.updatedAtLabel}\n" else "") + "Veri: Open-Meteo.com",
            color = soft, fontSize = 11.sp, modifier = Modifier.weight(1f)
        )
        OutlinedButton(onClick = onRefresh) { Text(if (w.loading) "…" else "YENİLE") }
    }
    Text(
        "Puan, güneşlenme süresinin gün ışığı süresine oranıdır. Panel eğimi, gölge ve kirlilik hesaba katılmaz.",
        color = soft, fontSize = 10.sp
    )
}

// ---------------------------------------------------------------------------------------------- faults

@Composable
private fun FaultCard(f: FaultInfo, active: Boolean, expandedByDefault: Boolean) {
    var open by rememberSaveable(f.code) { mutableStateOf(expandedByDefault) }
    val c = if (active) badColor else lineColor
    Panel(
        modifier = Modifier.clickable { open = !open },
        border = c,
        bg = if (active) badColor.copy(alpha = 0.10f) else cardColor
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(f.code, color = if (active) badColor else accent, fontWeight = FontWeight.Black, fontSize = 15.sp)
            Text(f.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(if (open) "▲" else "▼", color = soft, fontSize = 12.sp)
        }
        if (open) {
            Text(f.meaning, color = Color.White, fontSize = 12.sp)
            Text("ÇÖZÜM", color = good, fontWeight = FontWeight.Black, fontSize = 11.sp)
            f.solutions.forEachIndexed { i, step ->
                Text("${i + 1}. $step", color = soft, fontSize = 12.sp)
            }
        }
    }
}

@Composable
internal fun FaultsContent(s: HeaterUiState, live: HeaterLiveStatus?) {
    val mask = live?.errorMask ?: 0
    val plus = live?.errorPlus ?: 0
    val active = ErrorCatalog.active(mask, plus)

    when {
        live == null -> Panel {
            Text("Isıtıcı bağlı değil", color = warnColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Bağlandığında etkin hata kodları burada görünür. Aşağıda tüm hata kodları ve çözümleri var.", color = soft, fontSize = 12.sp)
        }
        mask == 0 -> Panel(border = good) {
            Text("✔ Etkin hata yok", color = good, fontWeight = FontWeight.Black, fontSize = 15.sp)
            Text("Isıtıcı hata bildirmiyor.", color = soft, fontSize = 12.sp)
        }
        else -> {
            Text("ETKİN HATA${if (active.size > 1) "LAR" else ""}", color = badColor, fontWeight = FontWeight.Black, fontSize = 14.sp)
            Text("Kod: 0x%04X • alt kod: %d".format(mask, plus), color = soft, fontSize = 11.sp)
            if (active.isEmpty()) {
                Panel(border = badColor) {
                    Text("Bilinmeyen hata kodu 0x%04X".format(mask), color = badColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Isıtıcıyı durdurun ve yetkili servise danışın.", color = soft, fontSize = 12.sp)
                }
            }
            active.forEach { FaultCard(it, active = true, expandedByDefault = true) }
        }
    }

    if (s.errorLog.isNotEmpty()) {
        SectionTitle("SON HATA KAYITLARI")
        s.errorLog.take(5).forEach { e ->
            Panel { Text("${e.timeLabel} • ${e.title}", color = Color.White, fontSize = 12.sp); Text(e.detail, color = soft, fontSize = 11.sp) }
        }
    }

    SectionTitle("TÜM HATA KODLARI", "Dokunarak açıp kapatın")
    val activeCodes = active.map { it.code }.toSet()
    ErrorCatalog.all.forEach { f ->
        if (f.code !in activeCodes) FaultCard(f, active = false, expandedByDefault = false)
    }

    SectionTitle("GENEL ÖNERİLER")
    Panel {
        ErrorCatalog.generalTips.forEach { Text("• $it", color = soft, fontSize = 12.sp) }
    }
}

// ---------------------------------------------------------------------------------------------- fan mode and alerts

@Composable
internal fun FanModeCard(s: HeaterUiState, connected: Boolean, onToggle: () -> Unit) {
    Panel(border = if (s.isFanMode) good else lineColor) {
        Text("FAN MODU (HAVALANDIRMA)", color = accent, fontWeight = FontWeight.Black, fontSize = 15.sp)
        Text(
            "Yakıt yakmadan yalnızca fanı çalıştırır. Yaz aylarında araç veya kabin içini havalandırmak için kullanın.",
            color = soft, fontSize = 12.sp
        )
        Text(
            when {
                s.isFanMode -> "DURUM: AKTİF • fan çalışıyor"
                !connected -> "DURUM: ısıtıcı bağlı değil"
                s.isHeaterOn -> "DURUM: ısıtıcı çalışıyor, önce durdurun"
                else -> "DURUM: kapalı"
            },
            color = if (s.isFanMode) good else Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp
        )
        Button(onClick = onToggle, enabled = connected && (s.isFanMode || !s.isHeaterOn)) {
            Text(if (s.isFanMode) "FAN MODUNU DURDUR" else "FAN MODUNU BAŞLAT")
        }
        if (s.fanModeMessage.isNotBlank()) Text(s.fanModeMessage, color = warnColor, fontSize = 11.sp)
        Text("Fan modu açıkken termostat ve programlar ısıtıcıyı başlatmaz.", color = soft, fontSize = 10.sp)
    }
}

@Composable
internal fun AlertSettingsCard(beepEnabled: Boolean, onBeepChange: (Boolean) -> Unit, onTestBeep: () -> Unit) {
    Panel {
        Text("DÜŞÜK VOLTAJ UYARISI", color = accent, fontWeight = FontWeight.Black, fontSize = 14.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Bip bip sesli uyarı", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("12 V: 11.8 V altı düşük, 11.0 V altı kritik. 24 V: 23.6 V / 22.0 V.", color = soft, fontSize = 11.sp)
            }
            Switch(checked = beepEnabled, onCheckedChange = onBeepChange)
        }
        OutlinedButton(onClick = onTestBeep) { Text("SESİ DENE") }
        Spacer(Modifier.height(2.dp))
    }
}

// ---------------------------------------------------------------------------------------------- sky backdrop (home)

internal data class SkyInfo(
    val cloud: Int,
    val low: Int,
    val high: Int,
    val raining: Boolean,
    val snowing: Boolean,
    val radiation: Float,
    val label: String,
    /** 0 at sunrise ... 1 at sunset. */
    val progress: Float
)

/** Daylight-only sky state; null at night or without data (the panel then keeps its plain look). */
internal fun skyInfo(w: WeatherUiState): SkyInfo? {
    val d = w.data ?: return null
    val now = LocalDateTime.now()
    val day = d.daily.firstOrNull { it.date == now.toLocalDate() } ?: return null
    if (!(now.isAfter(day.sunrise) && now.isBefore(day.sunset))) return null
    val c = d.current
    val hour = WeatherRepository.upcomingHours(d, 1).firstOrNull()
    val rad = hour?.radiationWm2 ?: 0f
    val total = ChronoUnit.SECONDS.between(day.sunrise, day.sunset).coerceAtLeast(1)
    val passed = ChronoUnit.SECONDS.between(day.sunrise, now).coerceIn(0, total)
    val snow = c.code in setOf(71, 73, 75, 77, 85, 86)
    val rain = !snow && (c.precipMm > 0.1f || c.code in 51..67 || c.code in 80..82 || c.code >= 95)
    return SkyInfo(
        cloud = c.cloud,
        low = hour?.cloudLow ?: c.cloud,
        high = hour?.cloudHigh ?: 0,
        raining = rain,
        snowing = snow,
        radiation = rad,
        label = WeatherRepository.hourRating(rad),
        progress = passed.toFloat() / total.toFloat()
    )
}

private fun mixC(a: Color, b: Color, f: Float) = androidx.compose.ui.graphics.lerp(a, b, f.coerceIn(0f, 1f))

private fun rnd(i: Int, k: Int): Float {
    val v = kotlin.math.sin((i * 12.9898 + k * 78.233)) * 43758.5453
    return (v - kotlin.math.floor(v)).toFloat()
}

/** One soft, volumetric cloud: overlapping radial puffs with a flat, darker base. */
private fun DrawScope.drawCloud(cx: Float, cy: Float, u: Float, shade: Float, alpha: Float) {
    val puffs = arrayOf(
        floatArrayOf(-1.25f, 0.18f, 0.55f), floatArrayOf(-0.65f, -0.08f, 0.78f), floatArrayOf(0.05f, -0.32f, 0.95f),
        floatArrayOf(0.75f, -0.08f, 0.78f), floatArrayOf(1.3f, 0.18f, 0.55f), floatArrayOf(0.35f, 0.22f, 0.72f),
        floatArrayOf(-0.45f, 0.26f, 0.68f)
    )
    val light = Color(0xFFFFFFFF)
    val dark = Color(0xFF8D9AA8)
    for (p in puffs) {
        val center = Offset(cx + p[0] * u, cy + p[1] * u)
        val r = p[2] * u
        val low = ((p[1] + 0.32f) / 0.6f).coerceIn(0f, 1f)
        val col = mixC(light, dark, shade * (0.25f + 0.75f * low))
        drawCircle(
            Brush.radialGradient(
                colorStops = arrayOf(0f to col.copy(alpha = alpha), 0.55f to col.copy(alpha = alpha * 0.65f), 1f to Color.Transparent),
                center = center, radius = r
            ),
            r, center
        )
    }
}

@Composable
internal fun Modifier.skyBackdrop(info: SkyInfo?, shape: androidx.compose.ui.graphics.Shape): Modifier {
    if (info == null) return this
    val tr = androidx.compose.animation.core.rememberInfiniteTransition(label = "sky")
    val t by tr.animateFloat(
        0f, 1f,
        androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(120_000, easing = androidx.compose.animation.core.LinearEasing)),
        label = "skyT"
    )
    val shimmer by tr.animateFloat(
        0f, 1f,
        androidx.compose.animation.core.infiniteRepeatable(
            androidx.compose.animation.core.tween(5000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "sunShimmer"
    )
    val fall by tr.animateFloat(
        0f, 1f,
        androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(1200, easing = androidx.compose.animation.core.LinearEasing)),
        label = "fall"
    )
    return this.clip(shape).drawBehind {
        val w = size.width
        val h = size.height
        val cf = (info.cloud / 100f).coerceIn(0f, 1f)
        val wet = if (info.raining || info.snowing) 1f else 0f
        val elev = kotlin.math.sin(Math.PI * info.progress).toFloat().coerceIn(0f, 1f)
        val warm = (1f - elev).let { it * it }

        // Sky: deep blue overhead, pale (or warm at sunrise/sunset) horizon, greyed by cloud cover and rain.
        var top = mixC(Color(0xFF2B4F86), Color(0xFF1E74D6), elev)
        var horizon = mixC(Color(0xFFBFE4FB), Color(0xFFFFB57F), warm)
        top = mixC(top, Color(0xFF6A7886), cf * 0.85f)
        horizon = mixC(horizon, Color(0xFFA9B4BE), cf * 0.8f)
        top = mixC(top, Color(0xFF38424D), wet * 0.55f)
        horizon = mixC(horizon, Color(0xFF59646F), wet * 0.5f)
        drawRect(Brush.verticalGradient(listOf(top, horizon)))

        // Sun travels along an arc between sunrise and sunset.
        val sunVisible = (1f - cf * cf * 0.97f) * (1f - wet * 0.8f)
        val sunC = Offset(w * (0.14f + 0.72f * info.progress), h * (0.80f - 0.58f * elev))
        val sr = minOf(w, h) * 0.075f
        if (sunVisible > 0.04f) {
            val glowCol = mixC(Color(0xFFFFF3C4), Color(0xFFFFB066), warm)
            val gr = minOf(w, h) * (0.55f + 0.04f * shimmer)
            drawCircle(
                Brush.radialGradient(
                    colorStops = arrayOf(0f to glowCol.copy(alpha = 0.75f * sunVisible), 0.25f to glowCol.copy(alpha = 0.32f * sunVisible), 1f to Color.Transparent),
                    center = sunC, radius = gr
                ),
                gr, sunC
            )
            // Soft light shafts, only in fairly clear weather.
            if (cf < 0.6f) {
                for (k in 0 until 5) {
                    val ang = Math.toRadians(35.0 + k * 22.0 + shimmer * 4.0)
                    val len = h * 1.5f
                    val spread = Math.toRadians(4.0)
                    val path = Path().apply {
                        moveTo(sunC.x, sunC.y)
                        lineTo(sunC.x + (len * kotlin.math.cos(ang - spread)).toFloat(), sunC.y + (len * kotlin.math.sin(ang - spread)).toFloat())
                        lineTo(sunC.x + (len * kotlin.math.cos(ang + spread)).toFloat(), sunC.y + (len * kotlin.math.sin(ang + spread)).toFloat())
                        close()
                    }
                    drawPath(path, glowCol.copy(alpha = (0.05f + 0.05f * rnd(k, 3) * (0.5f + shimmer)) * sunVisible))
                }
            }
            drawCircle(
                Brush.radialGradient(
                    colorStops = arrayOf(0f to Color.White.copy(alpha = sunVisible), 0.55f to Color(0xFFFFF0A8).copy(alpha = sunVisible), 1f to Color(0xFFFFD54A).copy(alpha = 0f)),
                    center = sunC, radius = sr * 1.35f
                ),
                sr * 1.35f, sunC
            )
            // Faint lens flare along the line to the centre of the card.
            if (cf < 0.35f) {
                val mid = Offset(w * 0.5f, h * 0.5f)
                for ((k, f) in listOf(0.35f, 0.6f, 0.9f).withIndex()) {
                    val pt = Offset(sunC.x + (mid.x - sunC.x) * f, sunC.y + (mid.y - sunC.y) * f)
                    drawCircle(glowCol.copy(alpha = 0.10f * sunVisible), sr * (0.5f + 0.25f * k), pt)
                }
            }
        }

        // Thin high cloud streaks (cirrus).
        if (info.high > 15) {
            val a = (info.high / 100f) * 0.35f
            for (k in 0 until 3) {
                val x = ((t * 1f + rnd(k, 5)) % 1f) * (w * 1.6f) - w * 0.3f
                val y = h * (0.08f + 0.12f * k)
                drawRoundRect(
                    Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = a), Color.Transparent), x, x + w * 0.7f),
                    Offset(x, y), androidx.compose.ui.geometry.Size(w * 0.7f, h * 0.025f),
                    androidx.compose.ui.geometry.CornerRadius(h * 0.02f)
                )
            }
        }

        // Cumulus layers: far ones small and slow, near ones larger and faster; count follows real cloud cover.
        val count = if (info.cloud < 8) 0 else (cf * 8f).toInt().coerceIn(1, 8)
        val shade = (0.15f + cf * 0.55f + wet * 0.3f).coerceIn(0f, 1f)
        for (i in 0 until count) {
            val depth = rnd(i, 1)               // 0 far ... 1 near
            val laps = if (depth < 0.34f) 1 else if (depth < 0.67f) 2 else 3
            val u = minOf(w, h) * (0.10f + 0.12f * depth)
            val cw = u * 3.2f
            val x = ((t * laps + rnd(i, 2)) % 1f) * (w + 2f * cw) - cw
            val y = h * (0.10f + 0.50f * rnd(i, 4)) + u * 0.2f
            drawCloud(x, y, u, shade, 0.55f + 0.4f * depth)
        }

        // Overcast veil.
        if (cf > 0.7f) {
            drawRect(
                Brush.verticalGradient(listOf(Color(0xFF6E7B88).copy(alpha = (cf - 0.7f) * 1.5f), Color.Transparent)),
                size = androidx.compose.ui.geometry.Size(w, h * 0.7f)
            )
        }

        // Rain: three depth layers, slanted by wind, with ripples at the bottom.
        if (info.raining) {
            for (k in 0 until 46) {
                val layer = k % 3
                val speed = 1f + layer * 0.35f
                val x = rnd(k, 7) * (w + 40f)
                val y = ((fall * speed + rnd(k, 8)) % 1f) * (h + 30f) - 15f
                val len = 8f + layer * 6f
                drawLine(
                    Color(0xFFCFE6FF).copy(alpha = 0.30f + 0.18f * layer),
                    Offset(x, y), Offset(x - len * 0.3f, y + len), strokeWidth = 1f + 0.5f * layer
                )
            }
            for (k in 0 until 6) {
                val ph = (fall * 1.5f + rnd(k, 9)) % 1f
                val cx = rnd(k, 10) * w
                drawOval(
                    Color(0xFFCFE6FF).copy(alpha = 0.35f * (1f - ph)),
                    Offset(cx - 14f * ph, h - 8f), androidx.compose.ui.geometry.Size(28f * ph, 6f * ph),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(1f)
                )
            }
        } else if (info.snowing) {
            for (k in 0 until 36) {
                val layer = k % 3
                val x = rnd(k, 7) * w + kotlin.math.sin((fall * 6.2831 + k)).toFloat() * (6f + 3f * layer)
                val y = ((fall * (0.4f + 0.15f * layer) + rnd(k, 8)) % 1f) * h
                drawCircle(Color.White.copy(alpha = 0.55f + 0.15f * layer), 1.4f + layer * 0.8f, Offset(x, y))
            }
        }

        // Keep the foreground text readable.
        drawRect(Color(0xFF041220).copy(alpha = 0.30f))
    }
}

@Composable
internal fun SkyChip(info: SkyInfo, fontSize: androidx.compose.ui.unit.TextUnit = 9.sp, modifier: Modifier = Modifier) {
    val text = when {
        info.raining -> "🌧 Yağış • bulut %${info.cloud}"
        info.snowing -> "❄ Kar • bulut %${info.cloud}"
        else -> "☀ Güneş: ${info.label} • bulut %${info.cloud}"
    }
    Text(
        text, color = Color.White, fontSize = fontSize, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = modifier
            .background(Color(0x66000000), RoundedCornerShape(8.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    )
}

// ---------------------------------------------------------------------------------------------- space view

@Composable
internal fun MapContent(
    w: WeatherUiState,
    sat: HeaterViewModel.SatelliteState,
    onReload: () -> Unit,
    onRequestLocation: () -> Unit,
    onOpenWeather: () -> Unit
) {
    val img = sat.image
    val live = sat.live
    val data = w.data
    val sky = skyInfo(w)
    var showCloud by rememberSaveable { mutableStateOf(true) }
    var showRadar by rememberSaveable { mutableStateOf(true) }
    var showLines by rememberSaveable { mutableStateOf(true) }

    if (!w.locationKnown) {
        Panel {
            Text("Konum bekleniyor", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text("Uzaydan görünüm için konum izni gerekir.", color = soft, fontSize = 12.sp)
            Button(onClick = onRequestLocation) { Text("KONUMU AÇ") }
        }
    } else {
        val tr = androidx.compose.animation.core.rememberInfiniteTransition(label = "mapPulse")
        val pulse by tr.animateFloat(
            0f, 1f,
            androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(1800, easing = androidx.compose.animation.core.LinearEasing)),
            label = "pin"
        )
        val rain by tr.animateFloat(
            0f, 1f,
            androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(1200, easing = androidx.compose.animation.core.LinearEasing)),
            label = "mapRain"
        )
        val span = img?.spanKm ?: (data?.let { com.aldanmaz.webestenheater.weather.SatelliteMap.spanKm(it.latitude) } ?: 500)
        val shape = RoundedCornerShape(16.dp)
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .androidx_clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xFF0B2540), Color(0xFF123B5E))))
                .border(1.dp, lineColor, shape)
        ) {
            if (img != null) {
                Image(
                    bitmap = img.bitmap.asImageBitmap(),
                    contentDescription = "Uydu görüntüsü",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().aspectRatio(1f)
                )
            }
            Canvas(Modifier.fillMaxWidth().aspectRatio(1f)) {
                val c = Offset(size.width / 2f, size.height / 2f)
                val dst = androidx.compose.ui.unit.IntSize(size.width.toInt(), size.height.toInt())
                if (showCloud && live?.cloud != null) {
                    drawImage(
                        live.cloud.asImageBitmap(),
                        srcSize = androidx.compose.ui.unit.IntSize(live.cloud.width, live.cloud.height),
                        dstSize = dst,
                        alpha = 0.9f,
                        filterQuality = androidx.compose.ui.graphics.FilterQuality.High
                    )
                }
                if (showRadar && live?.radar != null) {
                    drawImage(
                        live.radar.asImageBitmap(),
                        dstSize = dst,
                        alpha = 0.9f,
                        filterQuality = androidx.compose.ui.graphics.FilterQuality.Medium
                    )
                }
                // Coastlines, borders and place names stay on top so they remain visible through clouds.
                if (showLines && sat.reference != null) {
                    drawImage(
                        sat.reference.asImageBitmap(),
                        dstSize = dst,
                        filterQuality = androidx.compose.ui.graphics.FilterQuality.Medium
                    )
                }
                // Night: the picture is a daytime capture, so dim it between sunset and sunrise.
                if (data != null && sky == null) drawRect(Color(0xFF020B16).copy(alpha = 0.40f))
                if (sky?.raining == true) {
                    for (k in 0 until 50) {
                        val x = rnd2(k, 1) * size.width
                        val y = ((rain * (1f + (k % 3) * 0.3f) + rnd2(k, 2)) % 1f) * size.height
                        drawLine(Color(0xFFCFE6FF).copy(alpha = 0.35f), Offset(x, y), Offset(x - 5f, y + 16f), strokeWidth = 1.5f)
                    }
                }
                // Location marker with a pulsing ring.
                val r = size.minDimension * 0.02f
                drawCircle(Color(0xFFFF4D4D).copy(alpha = 0.5f * (1f - pulse)), r * (1.5f + 4f * pulse), c)
                drawCircle(Color.White, r * 1.35f, c)
                drawCircle(Color(0xFFFF4D4D), r, c)
                // Scale bar: a quarter of the picture width.
                val barKm = (span / 4f).let { if (it >= 50f) (it / 50f).toInt() * 50 else (it / 10f).toInt().coerceAtLeast(1) * 10 }
                val barPx = size.width * barKm / span.coerceAtLeast(1)
                val y0 = size.height - 18f
                drawLine(Color.White, Offset(14f, y0), Offset(14f + barPx, y0), strokeWidth = 3f)
                drawLine(Color.White, Offset(14f, y0 - 5f), Offset(14f, y0 + 5f), strokeWidth = 2f)
                drawLine(Color.White, Offset(14f + barPx, y0 - 5f), Offset(14f + barPx, y0 + 5f), strokeWidth = 2f)
                drawContext.canvas.nativeCanvas.drawText(
                    "$barKm km", 14f, y0 - 10f,
                    android.graphics.Paint().apply { color = android.graphics.Color.WHITE; textSize = 26f; isAntiAlias = true; setShadowLayer(4f, 0f, 0f, android.graphics.Color.BLACK) }
                )
            }
            if (sky != null) SkyChip(sky, 10.sp, Modifier.align(Alignment.TopEnd).padding(8.dp))
            else if (data != null) Text(
                "🌙 Gece", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).background(Color(0x88000000), RoundedCornerShape(8.dp)).padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }

        Panel {
            Text("CANLI KATMANLAR", color = accent, fontWeight = FontWeight.Black, fontSize = 13.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = showLines, onCheckedChange = { showLines = it })
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("Kıyı, sınır ve yer adları", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (sat.reference != null) "NASA GIBS referans katmanı" else if (sat.loading) "Yükleniyor…" else "Alınamadı" + (if (sat.referenceError.isNotBlank()) " (${sat.referenceError})" else ""),
                        color = soft, fontSize = 11.sp
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = showCloud, onCheckedChange = { showCloud = it })
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("Bulut örtüsü", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (live?.cloud != null) "Hava modeli, ${live.cloudLabel} itibarıyla (saatlik)" else if (sat.liveLoading) "Yükleniyor…" else "Alınamadı",
                        color = soft, fontSize = 11.sp
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = showRadar, onCheckedChange = { showRadar = it })
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("Yağış radarı", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (live?.radar != null) "RainViewer, ${live.radarLabel} (10 dk'da bir); radar kapsamı olmayan yerde boş kalır" else if (sat.liveLoading) "Yükleniyor…" else "Alınamadı",
                        color = soft, fontSize = 11.sp
                    )
                }
            }
            if (live != null && live.error.isNotBlank()) Text(live.error, color = warnColor, fontSize = 10.sp)
        }
        if (img == null) {
            Panel(border = warnColor) {
                Text(
                    if (sat.loading) "Uydu fotoğrafı yükleniyor…" else (sat.error ?: "Uydu fotoğrafı yüklenmedi."),
                    color = warnColor, fontSize = 12.sp
                )
                if (!sat.loading) Button(onClick = onReload) { Text("TEKRAR DENE") }
            }
        }
    }

    if (data != null) {
        val today = data.daily.firstOrNull { it.date == data.current.time.toLocalDate() }
        Panel {
            Text("ŞU ANKİ DURUM", color = accent, fontWeight = FontWeight.Black, fontSize = 13.sp)
            Text(
                "${WeatherRepository.icon(data.current.code, data.current.isDay)} ${WeatherRepository.describe(data.current.code)} • %.0f°C".format(data.current.tempC),
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp
            )
            Text(
                "Bulut %%${data.current.cloud} • yağış %.1f mm • rüzgâr %.0f km/sa".format(data.current.precipMm, data.current.windKmh),
                color = soft, fontSize = 12.sp
            )
            if (today != null) Text("☀ Gün doğumu ${hhmm(today.sunrise)} • batımı ${hhmm(today.sunset)}", color = soft, fontSize = 12.sp)
            Text("Konum: %.3f, %.3f".format(data.latitude, data.longitude), color = soft, fontSize = 11.sp)
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { onReload() }) { Text(if (sat.loading || sat.liveLoading) "…" else "YENİLE") }
        OutlinedButton(onClick = onOpenWeather) { Text("HAVA DURUMU") }
    }
    Text(
        "Altlık: NASA GIBS • VIIRS/MODIS gerçek renkli uydu fotoğrafı" + (img?.let { " (${it.dateLabel})" } ?: "") +
            ", günde bir kez güncellenir. Canlı katmanlar her 10 dakikada yenilenir. Konum değişince harita da değişir.",
        color = soft, fontSize = 10.sp
    )
}

private fun rnd2(i: Int, k: Int): Float {
    val v = kotlin.math.sin((i * 12.9898 + k * 78.233)) * 43758.5453
    return (v - kotlin.math.floor(v)).toFloat()
}

private fun Modifier.androidx_clip(shape: androidx.compose.ui.graphics.Shape): Modifier = this.clip(shape)

// ---------------------------------------------------------------------------------------------- fan + fuel on the home page

private fun shortRun(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    return if (h > 0) "%ds%02ddk".format(h, m) else "%ddk".format(m)
}

private fun shortTl(v: Float, known: Boolean): String = if (known) "%.0f₺".format(v) else "--₺"

/** Compact FAN switch for the top bar. */
@Composable
internal fun TopFanTile(s: HeaterUiState, connected: Boolean, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    val dense = androidx.compose.ui.platform.LocalConfiguration.current.let { minOf(it.screenWidthDp, it.screenHeightDp) < 600 }
    val shape = RoundedCornerShape(if (dense) 12.dp else 16.dp)
    Row(
        modifier
            .background(Color(0xFF061827), shape)
            .border(1.dp, if (s.isFanMode) good else Color(0xFF17517F), shape)
            .padding(horizontal = if (dense) 4.dp else 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text("FAN", color = if (s.isFanMode) good else Color.White, fontWeight = FontWeight.Black, fontSize = if (dense) 11.sp else 16.sp, maxLines = 1)
            Text(
                when {
                    s.isFanMode -> "Açık"
                    !connected -> "BT yok"
                    s.isHeaterOn -> "Isıtıcı"
                    else -> "Kapalı"
                },
                color = soft, fontSize = if (dense) 8.sp else 11.sp, maxLines = 1
            )
        }
        Switch(
            checked = s.isFanMode,
            onCheckedChange = { onToggle() },
            enabled = connected && (s.isFanMode || !s.isHeaterOn),
            modifier = Modifier.graphicsLayer(scaleX = if (dense) 0.6f else 0.8f, scaleY = if (dense) 0.6f else 0.8f)
        )
    }
}

/** Compact fuel summary for the top bar; red and blinking when 1.5 L or less is left. Tap opens the fuel page. */
@Composable
internal fun TopFuelTile(f: FuelState, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val dense = androidx.compose.ui.platform.LocalConfiguration.current.let { minOf(it.screenWidthDp, it.screenHeightDp) < 600 }
    val shape = RoundedCornerShape(if (dense) 12.dp else 16.dp)
    val critical = f.remainingL <= 1.5f
    val blink = if (critical) {
        val tr = androidx.compose.animation.core.rememberInfiniteTransition(label = "fuelBlink")
        val a by tr.animateFloat(
            1f, 0.15f,
            androidx.compose.animation.core.infiniteRepeatable(
                androidx.compose.animation.core.tween(500, easing = androidx.compose.animation.core.LinearEasing),
                androidx.compose.animation.core.RepeatMode.Reverse
            ),
            label = "fuelBlinkAlpha"
        )
        a
    } else 1f
    val red = Color(0xFFFF3B3B)
    // One centred line that rotates every 5 s: tank level, today's run time, today's litres and cost.
    var page by remember { mutableStateOf(0) }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(5000)
            page = (page + 1) % 3
        }
    }
    val text = when (page) {
        0 -> "DEPO %.1f Lt".format(f.remainingL)
        1 -> "Bugün ${formatRun(f.todayRunSeconds)}"
        else -> "%.1f Lt • ${shortTl(f.cost(f.todayL), f.priceKnown)}".format(f.todayL)
    }
    Box(
        modifier
            .background(Color(0xFF061827), shape)
            .border(1.dp, if (critical) red else Color(0xFF17517F), shape)
            .clip(shape)
            .clickable { onClick() }
            .padding(horizontal = if (dense) 3.dp else 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (critical) red else Color.White, fontWeight = FontWeight.Black,
            fontSize = if (dense) 12.sp else 16.sp, maxLines = 1, softWrap = false,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.fillMaxWidth().graphicsLayer { alpha = blink }
        )
    }
}

private fun Modifier.androidx_scale(f: Float): Modifier = this.then(Modifier.graphicsLayer(scaleX = f, scaleY = f))

// ---------------------------------------------------------------------------------------------- fuel analysis page

@Composable
internal fun FuelContent(f: FuelState, onRefreshPrice: () -> Unit, onOpenSettings: () -> Unit) {
    val low = f.tankL > 0f && f.remainingL / f.tankL < 0.15f
    Panel(border = if (low) badColor else lineColor) {
        Text("DEPO", color = accent, fontWeight = FontWeight.Black, fontSize = 13.sp)
        Text(
            "Depo %.1f L • Harcanan %.2f L • Kalan %.2f L".format(f.tankL, f.usedL, f.remainingL),
            color = if (low) badColor else Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp
        )
        ScoreBar(if (f.tankL > 0f) (f.remainingL / f.tankL * 100f).toInt() else 0, if (low) badColor else good)
        Text(
            "Depo %.1f L = ${formatTl(f.cost(f.tankL), f.priceKnown)} • Harcanan %.2f L = ${formatTl(f.cost(f.usedL), f.priceKnown)} • Kalan %.2f L = ${formatTl(f.cost(f.remainingL), f.priceKnown)}"
                .format(f.tankL, f.usedL, f.remainingL),
            color = soft, fontSize = 12.sp
        )
        if (low) Text("⚠ Yakıt azalıyor, depoyu doldurun.", color = badColor, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        if (f.avgLitersPerHour > 0f) {
            val hoursLeft = f.remainingL / f.avgLitersPerHour
            Text("Ortalama %.2f L/saat • kalan yakıtla yaklaşık %.1f saat".format(f.avgLitersPerHour, hoursLeft), color = soft, fontSize = 12.sp)
        }
    }

    Panel {
        Text("BUGÜN", color = accent, fontWeight = FontWeight.Black, fontSize = 13.sp)
        Text(
            "${formatRun(f.todayRunSeconds)} çalıştı • %.2f L yaktı • ${formatTl(f.cost(f.todayL), f.priceKnown)}".format(f.todayL),
            color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp
        )
    }

    Panel {
        Text("TOPLAM", color = accent, fontWeight = FontWeight.Black, fontSize = 13.sp)
        Text(
            "${formatRun(f.totalRunSeconds)} • %.2f L • ${formatTl(f.cost(f.totalL), f.priceKnown)}".format(f.totalL),
            color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp
        )
    }

    SectionTitle("SON GÜNLER", "Litre / çalışma süresi")
    val days = (f.history + com.aldanmaz.webestenheater.fuel.DayFuel(f.todayDate, f.todayRunSeconds, f.todayL)).takeLast(7)
    val maxL = days.maxOfOrNull { it.liters }?.coerceAtLeast(0.1f) ?: 0.1f
    Panel {
        days.reversed().forEach { d ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(d.date.takeLast(5), color = soft, fontSize = 11.sp, modifier = Modifier.width(44.dp))
                Box(Modifier.weight(1f).height(10.dp).background(Color(0xFF1B2A38), RoundedCornerShape(5.dp))) {
                    Box(Modifier.fillMaxWidth((d.liters / maxL).coerceIn(0.02f, 1f)).height(10.dp).background(accent, RoundedCornerShape(5.dp)))
                }
                Text("%.2f L • ${formatRun(d.runSeconds)} • ${formatTl(f.cost(d.liters), f.priceKnown)}".format(d.liters), color = Color.White, fontSize = 11.sp)
            }
        }
    }

    Panel {
        Text("DİZEL FİYATI", color = accent, fontWeight = FontWeight.Black, fontSize = 13.sp)
        Text(
            if (f.priceKnown) "%.2f TL/L".format(f.priceTl) else "Fiyat yok: Ayarlar > Yakıt ayarlarından elle girin",
            color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp
        )
        Text(f.priceStatus, color = soft, fontSize = 11.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onRefreshPrice) { Text("FİYATI YENİLE") }
            OutlinedButton(onClick = onOpenSettings) { Text("YAKIT AYARLARI") }
        }
    }
    Text(
        "Tüketim, ısıtıcının yakıt pompası frekansından tahmin edilir (pompa hacmi: %.3f ml/darbe). Gerçek tüketimle karşılaştırıp Ayarlar'dan pompa hacmini düzeltebilirsiniz.".format(f.mlPerStroke),
        color = soft, fontSize = 10.sp
    )
}

// ---------------------------------------------------------------------------------------------- settings cards

private fun parseDec(s: String): Float? = s.trim().replace(',', '.').toFloatOrNull()

@Composable
private fun NumField(label: String, initial: String, key: Any, onValue: (String) -> Unit, modifier: Modifier = Modifier) {
    var text by remember(key) { mutableStateOf(initial) }
    OutlinedTextField(
        value = text,
        onValueChange = { text = it; onValue(it) },
        label = { Text(label, fontSize = 11.sp) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier
    )
}

@Composable
internal fun FuelSettingsCard(
    f: FuelState,
    onTank: (Float) -> Unit,
    onInTank: (Float) -> Unit,
    onRefill: () -> Unit,
    onManualPrice: (Float) -> Unit,
    onAutoPrice: (Boolean) -> Unit,
    onMl: (Float) -> Unit,
    onRefreshPrice: () -> Unit,
    onResetStats: () -> Unit
) {
    var tank by remember(f.tankL) { mutableStateOf("%.1f".format(f.tankL)) }
    var inTank by remember(f.usedL, f.tankL) { mutableStateOf("%.1f".format(f.remainingL)) }
    var price by remember(f.manualPriceTl) { mutableStateOf(if (f.manualPriceTl > 0f) "%.2f".format(f.manualPriceTl) else "") }
    var ml by remember(f.mlPerStroke) { mutableStateOf("%.3f".format(f.mlPerStroke)) }
    Panel {
        Text("YAKIT AYARLARI", color = accent, fontWeight = FontWeight.Black, fontSize = 14.sp)
        Text("Depo ${"%.1f".format(f.tankL)} L • harcanan ${"%.2f".format(f.usedL)} L • kalan ${"%.2f".format(f.remainingL)} L", color = soft, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = tank, onValueChange = { tank = it }, label = { Text("Depo (L)", fontSize = 11.sp) }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = inTank, onValueChange = { inTank = it }, label = { Text("Depodaki yakıt (L)", fontSize = 11.sp) }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                parseDec(tank)?.let(onTank)
                parseDec(inTank)?.let(onInTank)
            }) { Text("KAYDET") }
            OutlinedButton(onClick = onRefill) { Text("DEPOYU DOLDUR") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Dizel fiyatı otomatik gelsin", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(f.priceStatus, color = soft, fontSize = 11.sp)
            }
            Switch(checked = f.autoPriceEnabled, onCheckedChange = onAutoPrice)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = price, onValueChange = { price = it }, label = { Text("Elle fiyat (TL/L)", fontSize = 11.sp) }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f)
            )
            Button(onClick = { parseDec(price)?.let(onManualPrice) }) { Text("KAYDET") }
        }
        Text("İnternet yoksa veya otomatik fiyat alınamazsa elle girilen fiyat kullanılır.", color = soft, fontSize = 10.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = ml, onValueChange = { ml = it }, label = { Text("Pompa hacmi (ml/darbe)", fontSize = 11.sp) }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f)
            )
            Button(onClick = { parseDec(ml)?.let(onMl) }) { Text("KAYDET") }
        }
        Text("Tüketim bu değerle hesaplanır. 2 kW sınıfı pompalar için tipik 0.022 ml; gerçek harcamaya göre ayarlayın.", color = soft, fontSize = 10.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onRefreshPrice) { Text("FİYATI YENİLE") }
            OutlinedButton(onClick = onResetStats) { Text("İSTATİSTİĞİ SIFIRLA") }
        }
    }
}

@Composable
internal fun TargetStopCard(enabled: Boolean, onChange: (Boolean) -> Unit) {
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("HEDEFTE DURDUR", color = accent, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Text(
                    "Elle başlatılan ısıtıcı, ortam sıcaklığı hedef sıcaklığa ulaşıp 1 dakika orada kalırsa kendiliğinden durur (en az 2 dakika çalıştıktan sonra).",
                    color = soft, fontSize = 11.sp
                )
            }
            Switch(checked = enabled, onCheckedChange = onChange)
        }
    }
}


@Composable
internal fun ThermostatInfo(s: HeaterUiState) {
    var open by rememberSaveable { mutableStateOf(false) }
    Panel(modifier = Modifier.clickable { open = !open }) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("ⓘ", color = accent, fontWeight = FontWeight.Black, fontSize = 20.sp)
            Text("Termostat nasıl çalışır?", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(if (open) "▲" else "▼", color = soft, fontSize = 12.sp)
        }
        Text(
            "Şu an: hedef ${s.thermostatStopC}°C • başlama ${s.thermostatStartC}°C (hedef − ${s.startOffsetC}).",
            color = accent, fontWeight = FontWeight.Bold, fontSize = 12.sp
        )
        if (open) {
            val lines = listOf(
                "Tek ayar: Ana sayfadaki HEDEF SICAKLIK (+/−) ile bu sayfadaki HEDEF aynıdır. Birini değiştirince diğeri de değişir.",
                "Durdurma: Ortam sıcaklığı hedefe ulaşınca ısıtıcı durur (soğutmaya geçer).",
                "Başlama: Ortam sıcaklığı \"hedef − başlama farkı\" değerine veya altına inince ısıtıcı kendiliğinden başlar. Örnek: hedef 22, fark 4 → 18°C ve altında başlar, 22°C'de durur.",
                "Başlama farkı, ısıtıcının sürekli aç-kapa yapmasını önler. Fark büyüdükçe daha geç başlar, daha az sık çalışır.",
                "Elle başlatma: START ile başlattığınız ısıtıcı da hedefe ulaşıp 1 dakika orada kalırsa durur (Ayarlar > Hedefte durdur ile kapatılabilir).",
                "Otomatik başlamanın şartları: termostat AÇIK, Bluetooth bağlı, uygulama çalışıyor ve minimum bekleme süresi dolmuş olmalı. Ayrıca fan modu açıkken başlatmaz.",
                "Ölçülen sıcaklık ısıtıcının kendi ortam sensöründen gelir; sensör ısıtıcının yakınındaysa gerçek oda sıcaklığından yüksek okuyabilir."
            )
            lines.forEach { Text("• $it", color = soft, fontSize = 12.sp) }
        }
    }
}


@Composable
internal fun BackgroundRunCard(enabled: Boolean, onChange: (Boolean) -> Unit, ignoringBattery: Boolean, onBatterySettings: () -> Unit) {
    Panel(border = if (enabled && ignoringBattery) good else lineColor) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ARKA PLANDA ÇALIŞ", color = accent, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Text(
                    "Ekran kapalıyken veya uygulama arka plandayken termostat, programlar ve Bluetooth bağlantısı çalışmaya devam eder. " +
                        "Bildirim çubuğunda sürekli bir bildirim görünür; Android bunu zorunlu kılar.",
                    color = soft, fontSize = 11.sp
                )
            }
            Switch(checked = enabled, onCheckedChange = onChange)
        }
        Text(
            if (ignoringBattery) "✔ Pil optimizasyonu bu uygulama için kapalı" else "⚠ Pil optimizasyonu açık: bazı telefonlar uygulamayı yine de uyutabilir",
            color = if (ignoringBattery) good else warnColor, fontSize = 11.sp, fontWeight = FontWeight.Bold
        )
        if (!ignoringBattery) OutlinedButton(onClick = onBatterySettings) { Text("PİL OPTİMİZASYONUNU KAPAT") }
        Text(
            "Bu özellik pili biraz daha fazla kullanır. Gece boyu çalıştıracaksanız telefonu şarja takmanız önerilir.",
            color = soft, fontSize = 10.sp
        )
    }
}


/** Home-screen switch: keep the thermostat and Bluetooth link running in the background (on) or stop that (off). */
@Composable
internal fun BackgroundRunPill(enabled: Boolean, onChange: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier
            .background(Color(0xCC061827), shape)
            .border(1.dp, if (enabled) good else lineColor, shape)
            .clip(shape)
            .clickable { onChange(!enabled) }
            .padding(start = 10.dp, end = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("ARKA PLAN", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp, maxLines = 1)
            Text(if (enabled) "Çalışır" else "Durur", color = if (enabled) good else soft, fontSize = 9.sp, maxLines = 1)
        }
        Switch(
            checked = enabled,
            onCheckedChange = onChange,
            modifier = Modifier.graphicsLayer(scaleX = 0.7f, scaleY = 0.7f)
        )
    }
}
