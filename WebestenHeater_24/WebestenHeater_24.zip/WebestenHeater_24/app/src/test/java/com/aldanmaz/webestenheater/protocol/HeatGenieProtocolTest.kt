package com.aldanmaz.webestenheater.protocol

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HeatGenieProtocolTest {
    @Test fun target22FrameMatchesHeatGenie() {
        assertArrayEquals(
            byteArrayOf(0xAA.toByte(), 0x00, 0x66, 0x01, 0x00, 0x16, 0x5C, 0xA6.toByte()),
            HeatGenieProtocol.targetTemperatureFrame(22)
        )
    }

    @Test fun gear5FrameMatchesHeatGenie() {
        assertArrayEquals(
            byteArrayOf(0xAA.toByte(), 0x00, 0x66, 0x02, 0x00, 0x05, 0x27, 0xA4.toByte()),
            HeatGenieProtocol.targetGearFrame(5)
        )
    }

    @Test fun startStatusReportIsValidEightByteFrame() {
        val frame = HeatGenieProtocol.autoUpdateFrame(true)
        assertEquals(8, frame.size)
        assertEquals(0x65, frame[2].toInt() and 0xFF)
        assertEquals(0x02, frame[3].toInt() and 0xFF)
        assertEquals(10, frame[4].toInt() and 0xFF)
        assertEquals(0, frame[5].toInt() and 0xFF)
        assertTrue(HeatGenieProtocol.isValidFrame(frame))
    }

    @Test fun powerOnFrameIsValid() {
        val frame = HeatGenieProtocol.powerFrame(true, 1)
        assertArrayEquals(
            byteArrayOf(0xAA.toByte(), 0x00, 0x61, 0x01, 0x01, 0x00, 0x4C, 0x4D),
            frame
        )
        assertTrue(HeatGenieProtocol.isValidFrame(frame))
    }

    @Test fun powerOffFrameIsValid() {
        val frame = HeatGenieProtocol.powerFrame(false, 2)
        assertArrayEquals(
            byteArrayOf(0xAA.toByte(), 0x00, 0x61, 0x02, 0x02, 0x00, 0x40, 0x4E),
            frame
        )
        assertTrue(HeatGenieProtocol.isValidFrame(frame))
    }
}
